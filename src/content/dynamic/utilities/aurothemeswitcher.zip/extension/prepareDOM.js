// --------------------------------------------------
// This script is run on load, and does some prep
// work for the theme switcher.
// --------------------------------------------------

// ADD CODE HERE IF NEEDED!

// eslint-disable-next-line no-console
console.log('prepareDOM.js loaded');
