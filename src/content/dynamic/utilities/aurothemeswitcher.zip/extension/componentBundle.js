/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t$4=window,e$8=t$4.ShadowRoot&&(void 0===t$4.ShadyCSS||t$4.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,s$9=Symbol(),n$8=new WeakMap;let o$9 = class o{constructor(t,e,n){if(this._$cssResult$=!0,n!==s$9)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e;}get styleSheet(){let t=this.o;const s=this.t;if(e$8&&void 0===t){const e=void 0!==s&&1===s.length;e&&(t=n$8.get(s)),void 0===t&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),e&&n$8.set(s,t));}return t}toString(){return this.cssText}};const r$a=t=>new o$9("string"==typeof t?t:t+"",void 0,s$9),S$3=(s,n)=>{e$8?s.adoptedStyleSheets=n.map((t=>t instanceof CSSStyleSheet?t:t.styleSheet)):n.forEach((e=>{const n=document.createElement("style"),o=t$4.litNonce;void 0!==o&&n.setAttribute("nonce",o),n.textContent=e.cssText,s.appendChild(n);}));},c$4=e$8?t=>t:t=>t instanceof CSSStyleSheet?(t=>{let e="";for(const s of t.cssRules)e+=s.cssText;return r$a(e)})(t):t;

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var s$8;const e$7=window,r$9=e$7.trustedTypes,h$3=r$9?r$9.emptyScript:"",o$8=e$7.reactiveElementPolyfillSupport,n$7={toAttribute(t,i){switch(i){case Boolean:t=t?h$3:null;break;case Object:case Array:t=null==t?t:JSON.stringify(t);}return t},fromAttribute(t,i){let s=t;switch(i){case Boolean:s=null!==t;break;case Number:s=null===t?null:Number(t);break;case Object:case Array:try{s=JSON.parse(t);}catch(t){s=null;}}return s}},a$5=(t,i)=>i!==t&&(i==i||t==t),l$6={attribute:!0,type:String,converter:n$7,reflect:!1,hasChanged:a$5},d$3="finalized";let u$4 = class u extends HTMLElement{constructor(){super(),this._$Ei=new Map,this.isUpdatePending=!1,this.hasUpdated=!1,this._$El=null,this._$Eu();}static addInitializer(t){var i;this.finalize(),(null!==(i=this.h)&&void 0!==i?i:this.h=[]).push(t);}static get observedAttributes(){this.finalize();const t=[];return this.elementProperties.forEach(((i,s)=>{const e=this._$Ep(s,i);void 0!==e&&(this._$Ev.set(e,s),t.push(e));})),t}static createProperty(t,i=l$6){if(i.state&&(i.attribute=!1),this.finalize(),this.elementProperties.set(t,i),!i.noAccessor&&!this.prototype.hasOwnProperty(t)){const s="symbol"==typeof t?Symbol():"__"+t,e=this.getPropertyDescriptor(t,s,i);void 0!==e&&Object.defineProperty(this.prototype,t,e);}}static getPropertyDescriptor(t,i,s){return {get(){return this[i]},set(e){const r=this[t];this[i]=e,this.requestUpdate(t,r,s);},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)||l$6}static finalize(){if(this.hasOwnProperty(d$3))return !1;this[d$3]=!0;const t=Object.getPrototypeOf(this);if(t.finalize(),void 0!==t.h&&(this.h=[...t.h]),this.elementProperties=new Map(t.elementProperties),this._$Ev=new Map,this.hasOwnProperty("properties")){const t=this.properties,i=[...Object.getOwnPropertyNames(t),...Object.getOwnPropertySymbols(t)];for(const s of i)this.createProperty(s,t[s]);}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(i){const s=[];if(Array.isArray(i)){const e=new Set(i.flat(1/0).reverse());for(const i of e)s.unshift(c$4(i));}else void 0!==i&&s.push(c$4(i));return s}static _$Ep(t,i){const s=i.attribute;return !1===s?void 0:"string"==typeof s?s:"string"==typeof t?t.toLowerCase():void 0}_$Eu(){var t;this._$E_=new Promise((t=>this.enableUpdating=t)),this._$AL=new Map,this._$Eg(),this.requestUpdate(),null===(t=this.constructor.h)||void 0===t||t.forEach((t=>t(this)));}addController(t){var i,s;(null!==(i=this._$ES)&&void 0!==i?i:this._$ES=[]).push(t),void 0!==this.renderRoot&&this.isConnected&&(null===(s=t.hostConnected)||void 0===s||s.call(t));}removeController(t){var i;null===(i=this._$ES)||void 0===i||i.splice(this._$ES.indexOf(t)>>>0,1);}_$Eg(){this.constructor.elementProperties.forEach(((t,i)=>{this.hasOwnProperty(i)&&(this._$Ei.set(i,this[i]),delete this[i]);}));}createRenderRoot(){var t;const s=null!==(t=this.shadowRoot)&&void 0!==t?t:this.attachShadow(this.constructor.shadowRootOptions);return S$3(s,this.constructor.elementStyles),s}connectedCallback(){var t;void 0===this.renderRoot&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),null===(t=this._$ES)||void 0===t||t.forEach((t=>{var i;return null===(i=t.hostConnected)||void 0===i?void 0:i.call(t)}));}enableUpdating(t){}disconnectedCallback(){var t;null===(t=this._$ES)||void 0===t||t.forEach((t=>{var i;return null===(i=t.hostDisconnected)||void 0===i?void 0:i.call(t)}));}attributeChangedCallback(t,i,s){this._$AK(t,s);}_$EO(t,i,s=l$6){var e;const r=this.constructor._$Ep(t,s);if(void 0!==r&&!0===s.reflect){const h=(void 0!==(null===(e=s.converter)||void 0===e?void 0:e.toAttribute)?s.converter:n$7).toAttribute(i,s.type);this._$El=t,null==h?this.removeAttribute(r):this.setAttribute(r,h),this._$El=null;}}_$AK(t,i){var s;const e=this.constructor,r=e._$Ev.get(t);if(void 0!==r&&this._$El!==r){const t=e.getPropertyOptions(r),h="function"==typeof t.converter?{fromAttribute:t.converter}:void 0!==(null===(s=t.converter)||void 0===s?void 0:s.fromAttribute)?t.converter:n$7;this._$El=r,this[r]=h.fromAttribute(i,t.type),this._$El=null;}}requestUpdate(t,i,s){let e=!0;void 0!==t&&(((s=s||this.constructor.getPropertyOptions(t)).hasChanged||a$5)(this[t],i)?(this._$AL.has(t)||this._$AL.set(t,i),!0===s.reflect&&this._$El!==t&&(void 0===this._$EC&&(this._$EC=new Map),this._$EC.set(t,s))):e=!1),!this.isUpdatePending&&e&&(this._$E_=this._$Ej());}async _$Ej(){this.isUpdatePending=!0;try{await this._$E_;}catch(t){Promise.reject(t);}const t=this.scheduleUpdate();return null!=t&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var t;if(!this.isUpdatePending)return;this.hasUpdated,this._$Ei&&(this._$Ei.forEach(((t,i)=>this[i]=t)),this._$Ei=void 0);let i=!1;const s=this._$AL;try{i=this.shouldUpdate(s),i?(this.willUpdate(s),null===(t=this._$ES)||void 0===t||t.forEach((t=>{var i;return null===(i=t.hostUpdate)||void 0===i?void 0:i.call(t)})),this.update(s)):this._$Ek();}catch(t){throw i=!1,this._$Ek(),t}i&&this._$AE(s);}willUpdate(t){}_$AE(t){var i;null===(i=this._$ES)||void 0===i||i.forEach((t=>{var i;return null===(i=t.hostUpdated)||void 0===i?void 0:i.call(t)})),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t);}_$Ek(){this._$AL=new Map,this.isUpdatePending=!1;}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$E_}shouldUpdate(t){return !0}update(t){void 0!==this._$EC&&(this._$EC.forEach(((t,i)=>this._$EO(i,this[i],t))),this._$EC=void 0),this._$Ek();}updated(t){}firstUpdated(t){}};u$4[d$3]=!0,u$4.elementProperties=new Map,u$4.elementStyles=[],u$4.shadowRootOptions={mode:"open"},null==o$8||o$8({ReactiveElement:u$4}),(null!==(s$8=e$7.reactiveElementVersions)&&void 0!==s$8?s$8:e$7.reactiveElementVersions=[]).push("1.6.3");

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var t$3;const i$7=window,s$7=i$7.trustedTypes,e$6=s$7?s$7.createPolicy("lit-html",{createHTML:t=>t}):void 0,o$7="$lit$",n$6=`lit$${(Math.random()+"").slice(9)}$`,l$5="?"+n$6,h$2=`<${l$5}>`,r$8=document,u$3=()=>r$8.createComment(""),d$2=t=>null===t||"object"!=typeof t&&"function"!=typeof t,c$3=Array.isArray,v$1=t=>c$3(t)||"function"==typeof(null==t?void 0:t[Symbol.iterator]),a$4="[ \t\n\f\r]",f$2=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,_$1=/-->/g,m$1=/>/g,p$2=RegExp(`>|${a$4}(?:([^\\s"'>=/]+)(${a$4}*=${a$4}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),g$1=/'/g,$$1=/"/g,y$2=/^(?:script|style|textarea|title)$/i,w=t=>(i,...s)=>({_$litType$:t,strings:i,values:s}),x$1=w(1),T$1=Symbol.for("lit-noChange"),A$1=Symbol.for("lit-nothing"),E$1=new WeakMap,C$1=r$8.createTreeWalker(r$8,129,null,!1);function P$1(t,i){if(!Array.isArray(t)||!t.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==e$6?e$6.createHTML(i):i}const V$1=(t,i)=>{const s=t.length-1,e=[];let l,r=2===i?"<svg>":"",u=f$2;for(let i=0;i<s;i++){const s=t[i];let d,c,v=-1,a=0;for(;a<s.length&&(u.lastIndex=a,c=u.exec(s),null!==c);)a=u.lastIndex,u===f$2?"!--"===c[1]?u=_$1:void 0!==c[1]?u=m$1:void 0!==c[2]?(y$2.test(c[2])&&(l=RegExp("</"+c[2],"g")),u=p$2):void 0!==c[3]&&(u=p$2):u===p$2?">"===c[0]?(u=null!=l?l:f$2,v=-1):void 0===c[1]?v=-2:(v=u.lastIndex-c[2].length,d=c[1],u=void 0===c[3]?p$2:'"'===c[3]?$$1:g$1):u===$$1||u===g$1?u=p$2:u===_$1||u===m$1?u=f$2:(u=p$2,l=void 0);const w=u===p$2&&t[i+1].startsWith("/>")?" ":"";r+=u===f$2?s+h$2:v>=0?(e.push(d),s.slice(0,v)+o$7+s.slice(v)+n$6+w):s+n$6+(-2===v?(e.push(void 0),i):w);}return [P$1(t,r+(t[s]||"<?>")+(2===i?"</svg>":"")),e]};let N$1 = class N{constructor({strings:t,_$litType$:i},e){let h;this.parts=[];let r=0,d=0;const c=t.length-1,v=this.parts,[a,f]=V$1(t,i);if(this.el=N.createElement(a,e),C$1.currentNode=this.el.content,2===i){const t=this.el.content,i=t.firstChild;i.remove(),t.append(...i.childNodes);}for(;null!==(h=C$1.nextNode())&&v.length<c;){if(1===h.nodeType){if(h.hasAttributes()){const t=[];for(const i of h.getAttributeNames())if(i.endsWith(o$7)||i.startsWith(n$6)){const s=f[d++];if(t.push(i),void 0!==s){const t=h.getAttribute(s.toLowerCase()+o$7).split(n$6),i=/([.?@])?(.*)/.exec(s);v.push({type:1,index:r,name:i[2],strings:t,ctor:"."===i[1]?H$1:"?"===i[1]?L$1:"@"===i[1]?z$1:k$1});}else v.push({type:6,index:r});}for(const i of t)h.removeAttribute(i);}if(y$2.test(h.tagName)){const t=h.textContent.split(n$6),i=t.length-1;if(i>0){h.textContent=s$7?s$7.emptyScript:"";for(let s=0;s<i;s++)h.append(t[s],u$3()),C$1.nextNode(),v.push({type:2,index:++r});h.append(t[i],u$3());}}}else if(8===h.nodeType)if(h.data===l$5)v.push({type:2,index:r});else {let t=-1;for(;-1!==(t=h.data.indexOf(n$6,t+1));)v.push({type:7,index:r}),t+=n$6.length-1;}r++;}}static createElement(t,i){const s=r$8.createElement("template");return s.innerHTML=t,s}};function S$2(t,i,s=t,e){var o,n,l,h;if(i===T$1)return i;let r=void 0!==e?null===(o=s._$Co)||void 0===o?void 0:o[e]:s._$Cl;const u=d$2(i)?void 0:i._$litDirective$;return (null==r?void 0:r.constructor)!==u&&(null===(n=null==r?void 0:r._$AO)||void 0===n||n.call(r,!1),void 0===u?r=void 0:(r=new u(t),r._$AT(t,s,e)),void 0!==e?(null!==(l=(h=s)._$Co)&&void 0!==l?l:h._$Co=[])[e]=r:s._$Cl=r),void 0!==r&&(i=S$2(t,r._$AS(t,i.values),r,e)),i}let M$1 = class M{constructor(t,i){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=i;}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){var i;const{el:{content:s},parts:e}=this._$AD,o=(null!==(i=null==t?void 0:t.creationScope)&&void 0!==i?i:r$8).importNode(s,!0);C$1.currentNode=o;let n=C$1.nextNode(),l=0,h=0,u=e[0];for(;void 0!==u;){if(l===u.index){let i;2===u.type?i=new R$1(n,n.nextSibling,this,t):1===u.type?i=new u.ctor(n,u.name,u.strings,this,t):6===u.type&&(i=new Z(n,this,t)),this._$AV.push(i),u=e[++h];}l!==(null==u?void 0:u.index)&&(n=C$1.nextNode(),l++);}return C$1.currentNode=r$8,o}v(t){let i=0;for(const s of this._$AV)void 0!==s&&(void 0!==s.strings?(s._$AI(t,s,i),i+=s.strings.length-2):s._$AI(t[i])),i++;}};let R$1 = class R{constructor(t,i,s,e){var o;this.type=2,this._$AH=A$1,this._$AN=void 0,this._$AA=t,this._$AB=i,this._$AM=s,this.options=e,this._$Cp=null===(o=null==e?void 0:e.isConnected)||void 0===o||o;}get _$AU(){var t,i;return null!==(i=null===(t=this._$AM)||void 0===t?void 0:t._$AU)&&void 0!==i?i:this._$Cp}get parentNode(){let t=this._$AA.parentNode;const i=this._$AM;return void 0!==i&&11===(null==t?void 0:t.nodeType)&&(t=i.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,i=this){t=S$2(this,t,i),d$2(t)?t===A$1||null==t||""===t?(this._$AH!==A$1&&this._$AR(),this._$AH=A$1):t!==this._$AH&&t!==T$1&&this._(t):void 0!==t._$litType$?this.g(t):void 0!==t.nodeType?this.$(t):v$1(t)?this.T(t):this._(t);}k(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}$(t){this._$AH!==t&&(this._$AR(),this._$AH=this.k(t));}_(t){this._$AH!==A$1&&d$2(this._$AH)?this._$AA.nextSibling.data=t:this.$(r$8.createTextNode(t)),this._$AH=t;}g(t){var i;const{values:s,_$litType$:e}=t,o="number"==typeof e?this._$AC(t):(void 0===e.el&&(e.el=N$1.createElement(P$1(e.h,e.h[0]),this.options)),e);if((null===(i=this._$AH)||void 0===i?void 0:i._$AD)===o)this._$AH.v(s);else {const t=new M$1(o,this),i=t.u(this.options);t.v(s),this.$(i),this._$AH=t;}}_$AC(t){let i=E$1.get(t.strings);return void 0===i&&E$1.set(t.strings,i=new N$1(t)),i}T(t){c$3(this._$AH)||(this._$AH=[],this._$AR());const i=this._$AH;let s,e=0;for(const o of t)e===i.length?i.push(s=new R(this.k(u$3()),this.k(u$3()),this,this.options)):s=i[e],s._$AI(o),e++;e<i.length&&(this._$AR(s&&s._$AB.nextSibling,e),i.length=e);}_$AR(t=this._$AA.nextSibling,i){var s;for(null===(s=this._$AP)||void 0===s||s.call(this,!1,!0,i);t&&t!==this._$AB;){const i=t.nextSibling;t.remove(),t=i;}}setConnected(t){var i;void 0===this._$AM&&(this._$Cp=t,null===(i=this._$AP)||void 0===i||i.call(this,t));}};let k$1 = class k{constructor(t,i,s,e,o){this.type=1,this._$AH=A$1,this._$AN=void 0,this.element=t,this.name=i,this._$AM=e,this.options=o,s.length>2||""!==s[0]||""!==s[1]?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=A$1;}get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}_$AI(t,i=this,s,e){const o=this.strings;let n=!1;if(void 0===o)t=S$2(this,t,i,0),n=!d$2(t)||t!==this._$AH&&t!==T$1,n&&(this._$AH=t);else {const e=t;let l,h;for(t=o[0],l=0;l<o.length-1;l++)h=S$2(this,e[s+l],i,l),h===T$1&&(h=this._$AH[l]),n||(n=!d$2(h)||h!==this._$AH[l]),h===A$1?t=A$1:t!==A$1&&(t+=(null!=h?h:"")+o[l+1]),this._$AH[l]=h;}n&&!e&&this.j(t);}j(t){t===A$1?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,null!=t?t:"");}};let H$1 = class H extends k$1{constructor(){super(...arguments),this.type=3;}j(t){this.element[this.name]=t===A$1?void 0:t;}};const I$1=s$7?s$7.emptyScript:"";let L$1 = class L extends k$1{constructor(){super(...arguments),this.type=4;}j(t){t&&t!==A$1?this.element.setAttribute(this.name,I$1):this.element.removeAttribute(this.name);}};let z$1 = class z extends k$1{constructor(t,i,s,e,o){super(t,i,s,e,o),this.type=5;}_$AI(t,i=this){var s;if((t=null!==(s=S$2(this,t,i,0))&&void 0!==s?s:A$1)===T$1)return;const e=this._$AH,o=t===A$1&&e!==A$1||t.capture!==e.capture||t.once!==e.once||t.passive!==e.passive,n=t!==A$1&&(e===A$1||o);o&&this.element.removeEventListener(this.name,this,e),n&&this.element.addEventListener(this.name,this,t),this._$AH=t;}handleEvent(t){var i,s;"function"==typeof this._$AH?this._$AH.call(null!==(s=null===(i=this.options)||void 0===i?void 0:i.host)&&void 0!==s?s:this.element,t):this._$AH.handleEvent(t);}};class Z{constructor(t,i,s){this.element=t,this.type=6,this._$AN=void 0,this._$AM=i,this.options=s;}get _$AU(){return this._$AM._$AU}_$AI(t){S$2(this,t);}}const B$1=i$7.litHtmlPolyfillSupport;null==B$1||B$1(N$1,R$1),(null!==(t$3=i$7.litHtmlVersions)&&void 0!==t$3?t$3:i$7.litHtmlVersions=[]).push("2.8.0");const D=(t,i,s)=>{var e,o;const n=null!==(e=null==s?void 0:s.renderBefore)&&void 0!==e?e:i;let l=n._$litPart$;if(void 0===l){const t=null!==(o=null==s?void 0:s.renderBefore)&&void 0!==o?o:null;n._$litPart$=l=new R$1(i.insertBefore(u$3(),t),t,void 0,null!=s?s:{});}return l._$AI(t),l};

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var l$4,o$6;let s$6 = class s extends u$4{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0;}createRenderRoot(){var t,e;const i=super.createRenderRoot();return null!==(t=(e=this.renderOptions).renderBefore)&&void 0!==t||(e.renderBefore=i.firstChild),i}update(t){const i=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=D(i,this.renderRoot,this.renderOptions);}connectedCallback(){var t;super.connectedCallback(),null===(t=this._$Do)||void 0===t||t.setConnected(!0);}disconnectedCallback(){var t;super.disconnectedCallback(),null===(t=this._$Do)||void 0===t||t.setConnected(!1);}render(){return T$1}};s$6.finalized=!0,s$6._$litElement$=!0,null===(l$4=globalThis.litElementHydrateSupport)||void 0===l$4||l$4.call(globalThis,{LitElement:s$6});const n$5=globalThis.litElementPolyfillSupport;null==n$5||n$5({LitElement:s$6});(null!==(o$6=globalThis.litElementVersions)&&void 0!==o$6?o$6:globalThis.litElementVersions=[]).push("3.3.3");

/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const e$5=Symbol.for(""),l$3=t=>{if((null==t?void 0:t.r)===e$5)return null==t?void 0:t._$litStatic$},o$5=t=>({_$litStatic$:t,r:e$5}),i$6=(t,...r)=>({_$litStatic$:r.reduce(((r,e,l)=>r+(t=>{if(void 0!==t._$litStatic$)return t._$litStatic$;throw Error(`Value passed to 'literal' function must be a 'literal' result: ${t}. Use 'unsafeStatic' to pass non-literal values, but\n            take care to ensure page security.`)})(e)+t[l+1]),t[0]),r:e$5}),s$5=new Map,a$3=t=>(r,...e)=>{const o=e.length;let i,a;const n=[],u=[];let c,$=0,f=!1;for(;$<o;){for(c=r[$];$<o&&void 0!==(a=e[$],i=l$3(a));)c+=i+r[++$],f=!0;$!==o&&u.push(a),n.push(c),$++;}if($===o&&n.push(r[o]),f){const t=n.join("$$lit$$");void 0===(r=s$5.get(t))&&(n.raw=n,s$5.set(t,r=n)),e=u;}return t(r,...e)},n$4=a$3(x$1);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * True if the custom elements polyfill is in use.
 */
const isCEPolyfill = typeof window !== 'undefined' &&
    window.customElements != null &&
    window.customElements.polyfillWrapFlushCallback !==
        undefined;
/**
 * Removes nodes, starting from `start` (inclusive) to `end` (exclusive), from
 * `container`.
 */
const removeNodes = (container, start, end = null) => {
    while (start !== end) {
        const n = start.nextSibling;
        container.removeChild(start);
        start = n;
    }
};

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * An expression marker with embedded unique key to avoid collision with
 * possible text in templates.
 */
const marker = `{{lit-${String(Math.random()).slice(2)}}}`;
/**
 * An expression marker used text-positions, multi-binding attributes, and
 * attributes with markup-like text values.
 */
const nodeMarker = `<!--${marker}-->`;
const markerRegex = new RegExp(`${marker}|${nodeMarker}`);
/**
 * Suffix appended to all bound attribute names.
 */
const boundAttributeSuffix = '$lit$';
/**
 * An updatable Template that tracks the location of dynamic parts.
 */
class Template {
    constructor(result, element) {
        this.parts = [];
        this.element = element;
        const nodesToRemove = [];
        const stack = [];
        // Edge needs all 4 parameters present; IE11 needs 3rd parameter to be null
        const walker = document.createTreeWalker(element.content, 133 /* NodeFilter.SHOW_{ELEMENT|COMMENT|TEXT} */, null, false);
        // Keeps track of the last index associated with a part. We try to delete
        // unnecessary nodes, but we never want to associate two different parts
        // to the same index. They must have a constant node between.
        let lastPartIndex = 0;
        let index = -1;
        let partIndex = 0;
        const { strings, values: { length } } = result;
        while (partIndex < length) {
            const node = walker.nextNode();
            if (node === null) {
                // We've exhausted the content inside a nested template element.
                // Because we still have parts (the outer for-loop), we know:
                // - There is a template in the stack
                // - The walker will find a nextNode outside the template
                walker.currentNode = stack.pop();
                continue;
            }
            index++;
            if (node.nodeType === 1 /* Node.ELEMENT_NODE */) {
                if (node.hasAttributes()) {
                    const attributes = node.attributes;
                    const { length } = attributes;
                    // Per
                    // https://developer.mozilla.org/en-US/docs/Web/API/NamedNodeMap,
                    // attributes are not guaranteed to be returned in document order.
                    // In particular, Edge/IE can return them out of order, so we cannot
                    // assume a correspondence between part index and attribute index.
                    let count = 0;
                    for (let i = 0; i < length; i++) {
                        if (endsWith(attributes[i].name, boundAttributeSuffix)) {
                            count++;
                        }
                    }
                    while (count-- > 0) {
                        // Get the template literal section leading up to the first
                        // expression in this attribute
                        const stringForPart = strings[partIndex];
                        // Find the attribute name
                        const name = lastAttributeNameRegex.exec(stringForPart)[2];
                        // Find the corresponding attribute
                        // All bound attributes have had a suffix added in
                        // TemplateResult#getHTML to opt out of special attribute
                        // handling. To look up the attribute value we also need to add
                        // the suffix.
                        const attributeLookupName = name.toLowerCase() + boundAttributeSuffix;
                        const attributeValue = node.getAttribute(attributeLookupName);
                        node.removeAttribute(attributeLookupName);
                        const statics = attributeValue.split(markerRegex);
                        this.parts.push({ type: 'attribute', index, name, strings: statics });
                        partIndex += statics.length - 1;
                    }
                }
                if (node.tagName === 'TEMPLATE') {
                    stack.push(node);
                    walker.currentNode = node.content;
                }
            }
            else if (node.nodeType === 3 /* Node.TEXT_NODE */) {
                const data = node.data;
                if (data.indexOf(marker) >= 0) {
                    const parent = node.parentNode;
                    const strings = data.split(markerRegex);
                    const lastIndex = strings.length - 1;
                    // Generate a new text node for each literal section
                    // These nodes are also used as the markers for node parts
                    for (let i = 0; i < lastIndex; i++) {
                        let insert;
                        let s = strings[i];
                        if (s === '') {
                            insert = createMarker();
                        }
                        else {
                            const match = lastAttributeNameRegex.exec(s);
                            if (match !== null && endsWith(match[2], boundAttributeSuffix)) {
                                s = s.slice(0, match.index) + match[1] +
                                    match[2].slice(0, -boundAttributeSuffix.length) + match[3];
                            }
                            insert = document.createTextNode(s);
                        }
                        parent.insertBefore(insert, node);
                        this.parts.push({ type: 'node', index: ++index });
                    }
                    // If there's no text, we must insert a comment to mark our place.
                    // Else, we can trust it will stick around after cloning.
                    if (strings[lastIndex] === '') {
                        parent.insertBefore(createMarker(), node);
                        nodesToRemove.push(node);
                    }
                    else {
                        node.data = strings[lastIndex];
                    }
                    // We have a part for each match found
                    partIndex += lastIndex;
                }
            }
            else if (node.nodeType === 8 /* Node.COMMENT_NODE */) {
                if (node.data === marker) {
                    const parent = node.parentNode;
                    // Add a new marker node to be the startNode of the Part if any of
                    // the following are true:
                    //  * We don't have a previousSibling
                    //  * The previousSibling is already the start of a previous part
                    if (node.previousSibling === null || index === lastPartIndex) {
                        index++;
                        parent.insertBefore(createMarker(), node);
                    }
                    lastPartIndex = index;
                    this.parts.push({ type: 'node', index });
                    // If we don't have a nextSibling, keep this node so we have an end.
                    // Else, we can remove it to save future costs.
                    if (node.nextSibling === null) {
                        node.data = '';
                    }
                    else {
                        nodesToRemove.push(node);
                        index--;
                    }
                    partIndex++;
                }
                else {
                    let i = -1;
                    while ((i = node.data.indexOf(marker, i + 1)) !== -1) {
                        // Comment node has a binding marker inside, make an inactive part
                        // The binding won't work, but subsequent bindings will
                        // TODO (justinfagnani): consider whether it's even worth it to
                        // make bindings in comments work
                        this.parts.push({ type: 'node', index: -1 });
                        partIndex++;
                    }
                }
            }
        }
        // Remove text binding nodes after the walk to not disturb the TreeWalker
        for (const n of nodesToRemove) {
            n.parentNode.removeChild(n);
        }
    }
}
const endsWith = (str, suffix) => {
    const index = str.length - suffix.length;
    return index >= 0 && str.slice(index) === suffix;
};
const isTemplatePartActive = (part) => part.index !== -1;
// Allows `document.createComment('')` to be renamed for a
// small manual size-savings.
const createMarker = () => document.createComment('');
/**
 * This regex extracts the attribute name preceding an attribute-position
 * expression. It does this by matching the syntax allowed for attributes
 * against the string literal directly preceding the expression, assuming that
 * the expression is in an attribute-value position.
 *
 * See attributes in the HTML spec:
 * https://www.w3.org/TR/html5/syntax.html#elements-attributes
 *
 * " \x09\x0a\x0c\x0d" are HTML space characters:
 * https://www.w3.org/TR/html5/infrastructure.html#space-characters
 *
 * "\0-\x1F\x7F-\x9F" are Unicode control characters, which includes every
 * space character except " ".
 *
 * So an attribute is:
 *  * The name: any character except a control character, space character, ('),
 *    ("), ">", "=", or "/"
 *  * Followed by zero or more space characters
 *  * Followed by "="
 *  * Followed by zero or more space characters
 *  * Followed by:
 *    * Any character except space, ('), ("), "<", ">", "=", (`), or
 *    * (") then any non-("), or
 *    * (') then any non-(')
 */
const lastAttributeNameRegex = 
// eslint-disable-next-line no-control-regex
/([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F "'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/;

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const walkerNodeFilter = 133 /* NodeFilter.SHOW_{ELEMENT|COMMENT|TEXT} */;
/**
 * Removes the list of nodes from a Template safely. In addition to removing
 * nodes from the Template, the Template part indices are updated to match
 * the mutated Template DOM.
 *
 * As the template is walked the removal state is tracked and
 * part indices are adjusted as needed.
 *
 * div
 *   div#1 (remove) <-- start removing (removing node is div#1)
 *     div
 *       div#2 (remove)  <-- continue removing (removing node is still div#1)
 *         div
 * div <-- stop removing since previous sibling is the removing node (div#1,
 * removed 4 nodes)
 */
function removeNodesFromTemplate(template, nodesToRemove) {
    const { element: { content }, parts } = template;
    const walker = document.createTreeWalker(content, walkerNodeFilter, null, false);
    let partIndex = nextActiveIndexInTemplateParts(parts);
    let part = parts[partIndex];
    let nodeIndex = -1;
    let removeCount = 0;
    const nodesToRemoveInTemplate = [];
    let currentRemovingNode = null;
    while (walker.nextNode()) {
        nodeIndex++;
        const node = walker.currentNode;
        // End removal if stepped past the removing node
        if (node.previousSibling === currentRemovingNode) {
            currentRemovingNode = null;
        }
        // A node to remove was found in the template
        if (nodesToRemove.has(node)) {
            nodesToRemoveInTemplate.push(node);
            // Track node we're removing
            if (currentRemovingNode === null) {
                currentRemovingNode = node;
            }
        }
        // When removing, increment count by which to adjust subsequent part indices
        if (currentRemovingNode !== null) {
            removeCount++;
        }
        while (part !== undefined && part.index === nodeIndex) {
            // If part is in a removed node deactivate it by setting index to -1 or
            // adjust the index as needed.
            part.index = currentRemovingNode !== null ? -1 : part.index - removeCount;
            // go to the next active part.
            partIndex = nextActiveIndexInTemplateParts(parts, partIndex);
            part = parts[partIndex];
        }
    }
    nodesToRemoveInTemplate.forEach((n) => n.parentNode.removeChild(n));
}
const countNodes = (node) => {
    let count = (node.nodeType === 11 /* Node.DOCUMENT_FRAGMENT_NODE */) ? 0 : 1;
    const walker = document.createTreeWalker(node, walkerNodeFilter, null, false);
    while (walker.nextNode()) {
        count++;
    }
    return count;
};
const nextActiveIndexInTemplateParts = (parts, startIndex = -1) => {
    for (let i = startIndex + 1; i < parts.length; i++) {
        const part = parts[i];
        if (isTemplatePartActive(part)) {
            return i;
        }
    }
    return -1;
};
/**
 * Inserts the given node into the Template, optionally before the given
 * refNode. In addition to inserting the node into the Template, the Template
 * part indices are updated to match the mutated Template DOM.
 */
function insertNodeIntoTemplate(template, node, refNode = null) {
    const { element: { content }, parts } = template;
    // If there's no refNode, then put node at end of template.
    // No part indices need to be shifted in this case.
    if (refNode === null || refNode === undefined) {
        content.appendChild(node);
        return;
    }
    const walker = document.createTreeWalker(content, walkerNodeFilter, null, false);
    let partIndex = nextActiveIndexInTemplateParts(parts);
    let insertCount = 0;
    let walkerIndex = -1;
    while (walker.nextNode()) {
        walkerIndex++;
        const walkerNode = walker.currentNode;
        if (walkerNode === refNode) {
            insertCount = countNodes(node);
            refNode.parentNode.insertBefore(node, refNode);
        }
        while (partIndex !== -1 && parts[partIndex].index === walkerIndex) {
            // If we've inserted the node, simply adjust all subsequent parts
            if (insertCount > 0) {
                while (partIndex !== -1) {
                    parts[partIndex].index += insertCount;
                    partIndex = nextActiveIndexInTemplateParts(parts, partIndex);
                }
                return;
            }
            partIndex = nextActiveIndexInTemplateParts(parts, partIndex);
        }
    }
}

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const directives = new WeakMap();
const isDirective = (o) => {
    return typeof o === 'function' && directives.has(o);
};

/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * A sentinel value that signals that a value was handled by a directive and
 * should not be written to the DOM.
 */
const noChange = {};
/**
 * A sentinel value that signals a NodePart to fully clear its content.
 */
const nothing = {};

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * An instance of a `Template` that can be attached to the DOM and updated
 * with new values.
 */
class TemplateInstance {
    constructor(template, processor, options) {
        this.__parts = [];
        this.template = template;
        this.processor = processor;
        this.options = options;
    }
    update(values) {
        let i = 0;
        for (const part of this.__parts) {
            if (part !== undefined) {
                part.setValue(values[i]);
            }
            i++;
        }
        for (const part of this.__parts) {
            if (part !== undefined) {
                part.commit();
            }
        }
    }
    _clone() {
        // There are a number of steps in the lifecycle of a template instance's
        // DOM fragment:
        //  1. Clone - create the instance fragment
        //  2. Adopt - adopt into the main document
        //  3. Process - find part markers and create parts
        //  4. Upgrade - upgrade custom elements
        //  5. Update - set node, attribute, property, etc., values
        //  6. Connect - connect to the document. Optional and outside of this
        //     method.
        //
        // We have a few constraints on the ordering of these steps:
        //  * We need to upgrade before updating, so that property values will pass
        //    through any property setters.
        //  * We would like to process before upgrading so that we're sure that the
        //    cloned fragment is inert and not disturbed by self-modifying DOM.
        //  * We want custom elements to upgrade even in disconnected fragments.
        //
        // Given these constraints, with full custom elements support we would
        // prefer the order: Clone, Process, Adopt, Upgrade, Update, Connect
        //
        // But Safari does not implement CustomElementRegistry#upgrade, so we
        // can not implement that order and still have upgrade-before-update and
        // upgrade disconnected fragments. So we instead sacrifice the
        // process-before-upgrade constraint, since in Custom Elements v1 elements
        // must not modify their light DOM in the constructor. We still have issues
        // when co-existing with CEv0 elements like Polymer 1, and with polyfills
        // that don't strictly adhere to the no-modification rule because shadow
        // DOM, which may be created in the constructor, is emulated by being placed
        // in the light DOM.
        //
        // The resulting order is on native is: Clone, Adopt, Upgrade, Process,
        // Update, Connect. document.importNode() performs Clone, Adopt, and Upgrade
        // in one step.
        //
        // The Custom Elements v1 polyfill supports upgrade(), so the order when
        // polyfilled is the more ideal: Clone, Process, Adopt, Upgrade, Update,
        // Connect.
        const fragment = isCEPolyfill ?
            this.template.element.content.cloneNode(true) :
            document.importNode(this.template.element.content, true);
        const stack = [];
        const parts = this.template.parts;
        // Edge needs all 4 parameters present; IE11 needs 3rd parameter to be null
        const walker = document.createTreeWalker(fragment, 133 /* NodeFilter.SHOW_{ELEMENT|COMMENT|TEXT} */, null, false);
        let partIndex = 0;
        let nodeIndex = 0;
        let part;
        let node = walker.nextNode();
        // Loop through all the nodes and parts of a template
        while (partIndex < parts.length) {
            part = parts[partIndex];
            if (!isTemplatePartActive(part)) {
                this.__parts.push(undefined);
                partIndex++;
                continue;
            }
            // Progress the tree walker until we find our next part's node.
            // Note that multiple parts may share the same node (attribute parts
            // on a single element), so this loop may not run at all.
            while (nodeIndex < part.index) {
                nodeIndex++;
                if (node.nodeName === 'TEMPLATE') {
                    stack.push(node);
                    walker.currentNode = node.content;
                }
                if ((node = walker.nextNode()) === null) {
                    // We've exhausted the content inside a nested template element.
                    // Because we still have parts (the outer for-loop), we know:
                    // - There is a template in the stack
                    // - The walker will find a nextNode outside the template
                    walker.currentNode = stack.pop();
                    node = walker.nextNode();
                }
            }
            // We've arrived at our part's node.
            if (part.type === 'node') {
                const part = this.processor.handleTextExpression(this.options);
                part.insertAfterNode(node.previousSibling);
                this.__parts.push(part);
            }
            else {
                this.__parts.push(...this.processor.handleAttributeExpressions(node, part.name, part.strings, this.options));
            }
            partIndex++;
        }
        if (isCEPolyfill) {
            document.adoptNode(fragment);
            customElements.upgrade(fragment);
        }
        return fragment;
    }
}

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * @module lit-html
 */
/**
 * Our TrustedTypePolicy for HTML which is declared using the html template
 * tag function.
 *
 * That HTML is a developer-authored constant, and is parsed with innerHTML
 * before any untrusted expressions have been mixed in. Therefor it is
 * considered safe by construction.
 */
const policy = window.trustedTypes &&
    trustedTypes.createPolicy('lit-html', { createHTML: (s) => s });
const commentMarker = ` ${marker} `;
/**
 * The return type of `html`, which holds a Template and the values from
 * interpolated expressions.
 */
class TemplateResult {
    constructor(strings, values, type, processor) {
        this.strings = strings;
        this.values = values;
        this.type = type;
        this.processor = processor;
    }
    /**
     * Returns a string of HTML used to create a `<template>` element.
     */
    getHTML() {
        const l = this.strings.length - 1;
        let html = '';
        let isCommentBinding = false;
        for (let i = 0; i < l; i++) {
            const s = this.strings[i];
            // For each binding we want to determine the kind of marker to insert
            // into the template source before it's parsed by the browser's HTML
            // parser. The marker type is based on whether the expression is in an
            // attribute, text, or comment position.
            //   * For node-position bindings we insert a comment with the marker
            //     sentinel as its text content, like <!--{{lit-guid}}-->.
            //   * For attribute bindings we insert just the marker sentinel for the
            //     first binding, so that we support unquoted attribute bindings.
            //     Subsequent bindings can use a comment marker because multi-binding
            //     attributes must be quoted.
            //   * For comment bindings we insert just the marker sentinel so we don't
            //     close the comment.
            //
            // The following code scans the template source, but is *not* an HTML
            // parser. We don't need to track the tree structure of the HTML, only
            // whether a binding is inside a comment, and if not, if it appears to be
            // the first binding in an attribute.
            const commentOpen = s.lastIndexOf('<!--');
            // We're in comment position if we have a comment open with no following
            // comment close. Because <-- can appear in an attribute value there can
            // be false positives.
            isCommentBinding = (commentOpen > -1 || isCommentBinding) &&
                s.indexOf('-->', commentOpen + 1) === -1;
            // Check to see if we have an attribute-like sequence preceding the
            // expression. This can match "name=value" like structures in text,
            // comments, and attribute values, so there can be false-positives.
            const attributeMatch = lastAttributeNameRegex.exec(s);
            if (attributeMatch === null) {
                // We're only in this branch if we don't have a attribute-like
                // preceding sequence. For comments, this guards against unusual
                // attribute values like <div foo="<!--${'bar'}">. Cases like
                // <!-- foo=${'bar'}--> are handled correctly in the attribute branch
                // below.
                html += s + (isCommentBinding ? commentMarker : nodeMarker);
            }
            else {
                // For attributes we use just a marker sentinel, and also append a
                // $lit$ suffix to the name to opt-out of attribute-specific parsing
                // that IE and Edge do for style and certain SVG attributes.
                html += s.substr(0, attributeMatch.index) + attributeMatch[1] +
                    attributeMatch[2] + boundAttributeSuffix + attributeMatch[3] +
                    marker;
            }
        }
        html += this.strings[l];
        return html;
    }
    getTemplateElement() {
        const template = document.createElement('template');
        let value = this.getHTML();
        if (policy !== undefined) {
            // this is secure because `this.strings` is a TemplateStringsArray.
            // TODO: validate this when
            // https://github.com/tc39/proposal-array-is-template-object is
            // implemented.
            value = policy.createHTML(value);
        }
        template.innerHTML = value;
        return template;
    }
}

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const isPrimitive = (value) => {
    return (value === null ||
        !(typeof value === 'object' || typeof value === 'function'));
};
const isIterable = (value) => {
    return Array.isArray(value) ||
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        !!(value && value[Symbol.iterator]);
};
/**
 * A Part that controls a location within a Node tree. Like a Range, NodePart
 * has start and end locations and can set and update the Nodes between those
 * locations.
 *
 * NodeParts support several value types: primitives, Nodes, TemplateResults,
 * as well as arrays and iterables of those types.
 */
class NodePart {
    constructor(options) {
        this.value = undefined;
        this.__pendingValue = undefined;
        this.options = options;
    }
    /**
     * Appends this part into a container.
     *
     * This part must be empty, as its contents are not automatically moved.
     */
    appendInto(container) {
        this.startNode = container.appendChild(createMarker());
        this.endNode = container.appendChild(createMarker());
    }
    /**
     * Inserts this part after the `ref` node (between `ref` and `ref`'s next
     * sibling). Both `ref` and its next sibling must be static, unchanging nodes
     * such as those that appear in a literal section of a template.
     *
     * This part must be empty, as its contents are not automatically moved.
     */
    insertAfterNode(ref) {
        this.startNode = ref;
        this.endNode = ref.nextSibling;
    }
    /**
     * Appends this part into a parent part.
     *
     * This part must be empty, as its contents are not automatically moved.
     */
    appendIntoPart(part) {
        part.__insert(this.startNode = createMarker());
        part.__insert(this.endNode = createMarker());
    }
    /**
     * Inserts this part after the `ref` part.
     *
     * This part must be empty, as its contents are not automatically moved.
     */
    insertAfterPart(ref) {
        ref.__insert(this.startNode = createMarker());
        this.endNode = ref.endNode;
        ref.endNode = this.startNode;
    }
    setValue(value) {
        this.__pendingValue = value;
    }
    commit() {
        if (this.startNode.parentNode === null) {
            return;
        }
        while (isDirective(this.__pendingValue)) {
            const directive = this.__pendingValue;
            this.__pendingValue = noChange;
            directive(this);
        }
        const value = this.__pendingValue;
        if (value === noChange) {
            return;
        }
        if (isPrimitive(value)) {
            if (value !== this.value) {
                this.__commitText(value);
            }
        }
        else if (value instanceof TemplateResult) {
            this.__commitTemplateResult(value);
        }
        else if (value instanceof Node) {
            this.__commitNode(value);
        }
        else if (isIterable(value)) {
            this.__commitIterable(value);
        }
        else if (value === nothing) {
            this.value = nothing;
            this.clear();
        }
        else {
            // Fallback, will render the string representation
            this.__commitText(value);
        }
    }
    __insert(node) {
        this.endNode.parentNode.insertBefore(node, this.endNode);
    }
    __commitNode(value) {
        if (this.value === value) {
            return;
        }
        this.clear();
        this.__insert(value);
        this.value = value;
    }
    __commitText(value) {
        const node = this.startNode.nextSibling;
        value = value == null ? '' : value;
        // If `value` isn't already a string, we explicitly convert it here in case
        // it can't be implicitly converted - i.e. it's a symbol.
        const valueAsString = typeof value === 'string' ? value : String(value);
        if (node === this.endNode.previousSibling &&
            node.nodeType === 3 /* Node.TEXT_NODE */) {
            // If we only have a single text node between the markers, we can just
            // set its value, rather than replacing it.
            // TODO(justinfagnani): Can we just check if this.value is primitive?
            node.data = valueAsString;
        }
        else {
            this.__commitNode(document.createTextNode(valueAsString));
        }
        this.value = value;
    }
    __commitTemplateResult(value) {
        const template = this.options.templateFactory(value);
        if (this.value instanceof TemplateInstance &&
            this.value.template === template) {
            this.value.update(value.values);
        }
        else {
            // Make sure we propagate the template processor from the TemplateResult
            // so that we use its syntax extension, etc. The template factory comes
            // from the render function options so that it can control template
            // caching and preprocessing.
            const instance = new TemplateInstance(template, value.processor, this.options);
            const fragment = instance._clone();
            instance.update(value.values);
            this.__commitNode(fragment);
            this.value = instance;
        }
    }
    __commitIterable(value) {
        // For an Iterable, we create a new InstancePart per item, then set its
        // value to the item. This is a little bit of overhead for every item in
        // an Iterable, but it lets us recurse easily and efficiently update Arrays
        // of TemplateResults that will be commonly returned from expressions like:
        // array.map((i) => html`${i}`), by reusing existing TemplateInstances.
        // If _value is an array, then the previous render was of an
        // iterable and _value will contain the NodeParts from the previous
        // render. If _value is not an array, clear this part and make a new
        // array for NodeParts.
        if (!Array.isArray(this.value)) {
            this.value = [];
            this.clear();
        }
        // Lets us keep track of how many items we stamped so we can clear leftover
        // items from a previous render
        const itemParts = this.value;
        let partIndex = 0;
        let itemPart;
        for (const item of value) {
            // Try to reuse an existing part
            itemPart = itemParts[partIndex];
            // If no existing part, create a new one
            if (itemPart === undefined) {
                itemPart = new NodePart(this.options);
                itemParts.push(itemPart);
                if (partIndex === 0) {
                    itemPart.appendIntoPart(this);
                }
                else {
                    itemPart.insertAfterPart(itemParts[partIndex - 1]);
                }
            }
            itemPart.setValue(item);
            itemPart.commit();
            partIndex++;
        }
        if (partIndex < itemParts.length) {
            // Truncate the parts array so _value reflects the current state
            itemParts.length = partIndex;
            this.clear(itemPart && itemPart.endNode);
        }
    }
    clear(startNode = this.startNode) {
        removeNodes(this.startNode.parentNode, startNode.nextSibling, this.endNode);
    }
}
// Detect event listener options support. If the `capture` property is read
// from the options object, then options are supported. If not, then the third
// argument to add/removeEventListener is interpreted as the boolean capture
// value so we should only pass the `capture` property.
let eventOptionsSupported = false;
// Wrap into an IIFE because MS Edge <= v41 does not support having try/catch
// blocks right into the body of a module
(() => {
    try {
        const options = {
            get capture() {
                eventOptionsSupported = true;
                return false;
            }
        };
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        window.addEventListener('test', options, options);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        window.removeEventListener('test', options, options);
    }
    catch (_e) {
        // event options not supported
    }
})();

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * The default TemplateFactory which caches Templates keyed on
 * result.type and result.strings.
 */
function templateFactory(result) {
    let templateCache = templateCaches.get(result.type);
    if (templateCache === undefined) {
        templateCache = {
            stringsArray: new WeakMap(),
            keyString: new Map()
        };
        templateCaches.set(result.type, templateCache);
    }
    let template = templateCache.stringsArray.get(result.strings);
    if (template !== undefined) {
        return template;
    }
    // If the TemplateStringsArray is new, generate a key from the strings
    // This key is shared between all templates with identical content
    const key = result.strings.join(marker);
    // Check if we already have a Template for this key
    template = templateCache.keyString.get(key);
    if (template === undefined) {
        // If we have not seen this key before, create a new Template
        template = new Template(result, result.getTemplateElement());
        // Cache the Template for this key
        templateCache.keyString.set(key, template);
    }
    // Cache all future queries for this TemplateStringsArray
    templateCache.stringsArray.set(result.strings, template);
    return template;
}
const templateCaches = new Map();

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const parts = new WeakMap();
/**
 * Renders a template result or other value to a container.
 *
 * To update a container with new values, reevaluate the template literal and
 * call `render` with the new result.
 *
 * @param result Any value renderable by NodePart - typically a TemplateResult
 *     created by evaluating a template tag like `html` or `svg`.
 * @param container A DOM parent to render to. The entire contents are either
 *     replaced, or efficiently updated if the same result type was previous
 *     rendered there.
 * @param options RenderOptions for the entire render tree rendered to this
 *     container. Render options must *not* change between renders to the same
 *     container, as those changes will not effect previously rendered DOM.
 */
const render$1 = (result, container, options) => {
    let part = parts.get(container);
    if (part === undefined) {
        removeNodes(container, container.firstChild);
        parts.set(container, part = new NodePart(Object.assign({ templateFactory }, options)));
        part.appendInto(container);
    }
    part.setValue(result);
    part.commit();
};

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 *
 * Main lit-html module.
 *
 * Main exports:
 *
 * -  [[html]]
 * -  [[svg]]
 * -  [[render]]
 *
 * @packageDocumentation
 */
/**
 * Do not remove this comment; it keeps typedoc from misplacing the module
 * docs.
 */
// IMPORTANT: do not change the property name or the assignment expression.
// This line will be used in regexes to search for lit-html usage.
// TODO(justinfagnani): inject version number at build time
if (typeof window !== 'undefined') {
    (window['litHtmlVersions'] || (window['litHtmlVersions'] = [])).push('1.4.1');
}

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * Module to add shady DOM/shady CSS polyfill support to lit-html template
 * rendering. See the [[render]] method for details.
 *
 * @packageDocumentation
 */
/**
 * Do not remove this comment; it keeps typedoc from misplacing the module
 * docs.
 */
// Get a key to lookup in `templateCaches`.
const getTemplateCacheKey = (type, scopeName) => `${type}--${scopeName}`;
let compatibleShadyCSSVersion = true;
if (typeof window.ShadyCSS === 'undefined') {
    compatibleShadyCSSVersion = false;
}
else if (typeof window.ShadyCSS.prepareTemplateDom === 'undefined') {
    console.warn(`Incompatible ShadyCSS version detected. ` +
        `Please update to at least @webcomponents/webcomponentsjs@2.0.2 and ` +
        `@webcomponents/shadycss@1.3.1.`);
    compatibleShadyCSSVersion = false;
}
/**
 * Template factory which scopes template DOM using ShadyCSS.
 * @param scopeName {string}
 */
const shadyTemplateFactory = (scopeName) => (result) => {
    const cacheKey = getTemplateCacheKey(result.type, scopeName);
    let templateCache = templateCaches.get(cacheKey);
    if (templateCache === undefined) {
        templateCache = {
            stringsArray: new WeakMap(),
            keyString: new Map()
        };
        templateCaches.set(cacheKey, templateCache);
    }
    let template = templateCache.stringsArray.get(result.strings);
    if (template !== undefined) {
        return template;
    }
    const key = result.strings.join(marker);
    template = templateCache.keyString.get(key);
    if (template === undefined) {
        const element = result.getTemplateElement();
        if (compatibleShadyCSSVersion) {
            window.ShadyCSS.prepareTemplateDom(element, scopeName);
        }
        template = new Template(result, element);
        templateCache.keyString.set(key, template);
    }
    templateCache.stringsArray.set(result.strings, template);
    return template;
};
const TEMPLATE_TYPES = ['html', 'svg'];
/**
 * Removes all style elements from Templates for the given scopeName.
 */
const removeStylesFromLitTemplates = (scopeName) => {
    TEMPLATE_TYPES.forEach((type) => {
        const templates = templateCaches.get(getTemplateCacheKey(type, scopeName));
        if (templates !== undefined) {
            templates.keyString.forEach((template) => {
                const { element: { content } } = template;
                // IE 11 doesn't support the iterable param Set constructor
                const styles = new Set();
                Array.from(content.querySelectorAll('style')).forEach((s) => {
                    styles.add(s);
                });
                removeNodesFromTemplate(template, styles);
            });
        }
    });
};
const shadyRenderSet = new Set();
/**
 * For the given scope name, ensures that ShadyCSS style scoping is performed.
 * This is done just once per scope name so the fragment and template cannot
 * be modified.
 * (1) extracts styles from the rendered fragment and hands them to ShadyCSS
 * to be scoped and appended to the document
 * (2) removes style elements from all lit-html Templates for this scope name.
 *
 * Note, <style> elements can only be placed into templates for the
 * initial rendering of the scope. If <style> elements are included in templates
 * dynamically rendered to the scope (after the first scope render), they will
 * not be scoped and the <style> will be left in the template and rendered
 * output.
 */
const prepareTemplateStyles = (scopeName, renderedDOM, template) => {
    shadyRenderSet.add(scopeName);
    // If `renderedDOM` is stamped from a Template, then we need to edit that
    // Template's underlying template element. Otherwise, we create one here
    // to give to ShadyCSS, which still requires one while scoping.
    const templateElement = !!template ? template.element : document.createElement('template');
    // Move styles out of rendered DOM and store.
    const styles = renderedDOM.querySelectorAll('style');
    const { length } = styles;
    // If there are no styles, skip unnecessary work
    if (length === 0) {
        // Ensure prepareTemplateStyles is called to support adding
        // styles via `prepareAdoptedCssText` since that requires that
        // `prepareTemplateStyles` is called.
        //
        // ShadyCSS will only update styles containing @apply in the template
        // given to `prepareTemplateStyles`. If no lit Template was given,
        // ShadyCSS will not be able to update uses of @apply in any relevant
        // template. However, this is not a problem because we only create the
        // template for the purpose of supporting `prepareAdoptedCssText`,
        // which doesn't support @apply at all.
        window.ShadyCSS.prepareTemplateStyles(templateElement, scopeName);
        return;
    }
    const condensedStyle = document.createElement('style');
    // Collect styles into a single style. This helps us make sure ShadyCSS
    // manipulations will not prevent us from being able to fix up template
    // part indices.
    // NOTE: collecting styles is inefficient for browsers but ShadyCSS
    // currently does this anyway. When it does not, this should be changed.
    for (let i = 0; i < length; i++) {
        const style = styles[i];
        style.parentNode.removeChild(style);
        condensedStyle.textContent += style.textContent;
    }
    // Remove styles from nested templates in this scope.
    removeStylesFromLitTemplates(scopeName);
    // And then put the condensed style into the "root" template passed in as
    // `template`.
    const content = templateElement.content;
    if (!!template) {
        insertNodeIntoTemplate(template, condensedStyle, content.firstChild);
    }
    else {
        content.insertBefore(condensedStyle, content.firstChild);
    }
    // Note, it's important that ShadyCSS gets the template that `lit-html`
    // will actually render so that it can update the style inside when
    // needed (e.g. @apply native Shadow DOM case).
    window.ShadyCSS.prepareTemplateStyles(templateElement, scopeName);
    const style = content.querySelector('style');
    if (window.ShadyCSS.nativeShadow && style !== null) {
        // When in native Shadow DOM, ensure the style created by ShadyCSS is
        // included in initially rendered output (`renderedDOM`).
        renderedDOM.insertBefore(style.cloneNode(true), renderedDOM.firstChild);
    }
    else if (!!template) {
        // When no style is left in the template, parts will be broken as a
        // result. To fix this, we put back the style node ShadyCSS removed
        // and then tell lit to remove that node from the template.
        // There can be no style in the template in 2 cases (1) when Shady DOM
        // is in use, ShadyCSS removes all styles, (2) when native Shadow DOM
        // is in use ShadyCSS removes the style if it contains no content.
        // NOTE, ShadyCSS creates its own style so we can safely add/remove
        // `condensedStyle` here.
        content.insertBefore(condensedStyle, content.firstChild);
        const removes = new Set();
        removes.add(condensedStyle);
        removeNodesFromTemplate(template, removes);
    }
};
/**
 * Extension to the standard `render` method which supports rendering
 * to ShadowRoots when the ShadyDOM (https://github.com/webcomponents/shadydom)
 * and ShadyCSS (https://github.com/webcomponents/shadycss) polyfills are used
 * or when the webcomponentsjs
 * (https://github.com/webcomponents/webcomponentsjs) polyfill is used.
 *
 * Adds a `scopeName` option which is used to scope element DOM and stylesheets
 * when native ShadowDOM is unavailable. The `scopeName` will be added to
 * the class attribute of all rendered DOM. In addition, any style elements will
 * be automatically re-written with this `scopeName` selector and moved out
 * of the rendered DOM and into the document `<head>`.
 *
 * It is common to use this render method in conjunction with a custom element
 * which renders a shadowRoot. When this is done, typically the element's
 * `localName` should be used as the `scopeName`.
 *
 * In addition to DOM scoping, ShadyCSS also supports a basic shim for css
 * custom properties (needed only on older browsers like IE11) and a shim for
 * a deprecated feature called `@apply` that supports applying a set of css
 * custom properties to a given location.
 *
 * Usage considerations:
 *
 * * Part values in `<style>` elements are only applied the first time a given
 * `scopeName` renders. Subsequent changes to parts in style elements will have
 * no effect. Because of this, parts in style elements should only be used for
 * values that will never change, for example parts that set scope-wide theme
 * values or parts which render shared style elements.
 *
 * * Note, due to a limitation of the ShadyDOM polyfill, rendering in a
 * custom element's `constructor` is not supported. Instead rendering should
 * either done asynchronously, for example at microtask timing (for example
 * `Promise.resolve()`), or be deferred until the first time the element's
 * `connectedCallback` runs.
 *
 * Usage considerations when using shimmed custom properties or `@apply`:
 *
 * * Whenever any dynamic changes are made which affect
 * css custom properties, `ShadyCSS.styleElement(element)` must be called
 * to update the element. There are two cases when this is needed:
 * (1) the element is connected to a new parent, (2) a class is added to the
 * element that causes it to match different custom properties.
 * To address the first case when rendering a custom element, `styleElement`
 * should be called in the element's `connectedCallback`.
 *
 * * Shimmed custom properties may only be defined either for an entire
 * shadowRoot (for example, in a `:host` rule) or via a rule that directly
 * matches an element with a shadowRoot. In other words, instead of flowing from
 * parent to child as do native css custom properties, shimmed custom properties
 * flow only from shadowRoots to nested shadowRoots.
 *
 * * When using `@apply` mixing css shorthand property names with
 * non-shorthand names (for example `border` and `border-width`) is not
 * supported.
 */
const render = (result, container, options) => {
    if (!options || typeof options !== 'object' || !options.scopeName) {
        throw new Error('The `scopeName` option is required.');
    }
    const scopeName = options.scopeName;
    const hasRendered = parts.has(container);
    const needsScoping = compatibleShadyCSSVersion &&
        container.nodeType === 11 /* Node.DOCUMENT_FRAGMENT_NODE */ &&
        !!container.host;
    // Handle first render to a scope specially...
    const firstScopeRender = needsScoping && !shadyRenderSet.has(scopeName);
    // On first scope render, render into a fragment; this cannot be a single
    // fragment that is reused since nested renders can occur synchronously.
    const renderContainer = firstScopeRender ? document.createDocumentFragment() : container;
    render$1(result, renderContainer, Object.assign({ templateFactory: shadyTemplateFactory(scopeName) }, options));
    // When performing first scope render,
    // (1) We've rendered into a fragment so that there's a chance to
    // `prepareTemplateStyles` before sub-elements hit the DOM
    // (which might cause them to render based on a common pattern of
    // rendering in a custom element's `connectedCallback`);
    // (2) Scope the template with ShadyCSS one time only for this scope.
    // (3) Render the fragment into the container and make sure the
    // container knows its `part` is the one we just rendered. This ensures
    // DOM will be re-used on subsequent renders.
    if (firstScopeRender) {
        const part = parts.get(renderContainer);
        parts.delete(renderContainer);
        // ShadyCSS might have style sheets (e.g. from `prepareAdoptedCssText`)
        // that should apply to `renderContainer` even if the rendered value is
        // not a TemplateInstance. However, it will only insert scoped styles
        // into the document if `prepareTemplateStyles` has already been called
        // for the given scope name.
        const template = part.value instanceof TemplateInstance ?
            part.value.template :
            undefined;
        prepareTemplateStyles(scopeName, renderContainer, template);
        removeNodes(container, container.firstChild);
        container.appendChild(renderContainer);
        parts.set(container, part);
    }
    // After elements have hit the DOM, update styling if this is the
    // initial render to this container.
    // This is needed whenever dynamic changes are made so it would be
    // safest to do every render; however, this would regress performance
    // so we leave it up to the user to call `ShadyCSS.styleElement`
    // for dynamic changes.
    if (!hasRendered && needsScoping) {
        window.ShadyCSS.styleElement(container.host);
    }
};

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
var _a;
/**
 * Use this module if you want to create your own base class extending
 * [[UpdatingElement]].
 * @packageDocumentation
 */
/*
 * When using Closure Compiler, JSCompiler_renameProperty(property, object) is
 * replaced at compile time by the munged name for object[property]. We cannot
 * alias this function, so we have to use a small shim that has the same
 * behavior when not compiling.
 */
window.JSCompiler_renameProperty =
    (prop, _obj) => prop;
const defaultConverter = {
    toAttribute(value, type) {
        switch (type) {
            case Boolean:
                return value ? '' : null;
            case Object:
            case Array:
                // if the value is `null` or `undefined` pass this through
                // to allow removing/no change behavior.
                return value == null ? value : JSON.stringify(value);
        }
        return value;
    },
    fromAttribute(value, type) {
        switch (type) {
            case Boolean:
                return value !== null;
            case Number:
                return value === null ? null : Number(value);
            case Object:
            case Array:
                // Type assert to adhere to Bazel's "must type assert JSON parse" rule.
                return JSON.parse(value);
        }
        return value;
    }
};
/**
 * Change function that returns true if `value` is different from `oldValue`.
 * This method is used as the default for a property's `hasChanged` function.
 */
const notEqual = (value, old) => {
    // This ensures (old==NaN, value==NaN) always returns false
    return old !== value && (old === old || value === value);
};
const defaultPropertyDeclaration = {
    attribute: true,
    type: String,
    converter: defaultConverter,
    reflect: false,
    hasChanged: notEqual
};
const STATE_HAS_UPDATED = 1;
const STATE_UPDATE_REQUESTED = 1 << 2;
const STATE_IS_REFLECTING_TO_ATTRIBUTE = 1 << 3;
const STATE_IS_REFLECTING_TO_PROPERTY = 1 << 4;
/**
 * The Closure JS Compiler doesn't currently have good support for static
 * property semantics where "this" is dynamic (e.g.
 * https://github.com/google/closure-compiler/issues/3177 and others) so we use
 * this hack to bypass any rewriting by the compiler.
 */
const finalized = 'finalized';
/**
 * Base element class which manages element properties and attributes. When
 * properties change, the `update` method is asynchronously called. This method
 * should be supplied by subclassers to render updates as desired.
 * @noInheritDoc
 */
class UpdatingElement extends HTMLElement {
    constructor() {
        super();
        this.initialize();
    }
    /**
     * Returns a list of attributes corresponding to the registered properties.
     * @nocollapse
     */
    static get observedAttributes() {
        // note: piggy backing on this to ensure we're finalized.
        this.finalize();
        const attributes = [];
        // Use forEach so this works even if for/of loops are compiled to for loops
        // expecting arrays
        this._classProperties.forEach((v, p) => {
            const attr = this._attributeNameForProperty(p, v);
            if (attr !== undefined) {
                this._attributeToPropertyMap.set(attr, p);
                attributes.push(attr);
            }
        });
        return attributes;
    }
    /**
     * Ensures the private `_classProperties` property metadata is created.
     * In addition to `finalize` this is also called in `createProperty` to
     * ensure the `@property` decorator can add property metadata.
     */
    /** @nocollapse */
    static _ensureClassProperties() {
        // ensure private storage for property declarations.
        if (!this.hasOwnProperty(JSCompiler_renameProperty('_classProperties', this))) {
            this._classProperties = new Map();
            // NOTE: Workaround IE11 not supporting Map constructor argument.
            const superProperties = Object.getPrototypeOf(this)._classProperties;
            if (superProperties !== undefined) {
                superProperties.forEach((v, k) => this._classProperties.set(k, v));
            }
        }
    }
    /**
     * Creates a property accessor on the element prototype if one does not exist
     * and stores a PropertyDeclaration for the property with the given options.
     * The property setter calls the property's `hasChanged` property option
     * or uses a strict identity check to determine whether or not to request
     * an update.
     *
     * This method may be overridden to customize properties; however,
     * when doing so, it's important to call `super.createProperty` to ensure
     * the property is setup correctly. This method calls
     * `getPropertyDescriptor` internally to get a descriptor to install.
     * To customize what properties do when they are get or set, override
     * `getPropertyDescriptor`. To customize the options for a property,
     * implement `createProperty` like this:
     *
     * static createProperty(name, options) {
     *   options = Object.assign(options, {myOption: true});
     *   super.createProperty(name, options);
     * }
     *
     * @nocollapse
     */
    static createProperty(name, options = defaultPropertyDeclaration) {
        // Note, since this can be called by the `@property` decorator which
        // is called before `finalize`, we ensure storage exists for property
        // metadata.
        this._ensureClassProperties();
        this._classProperties.set(name, options);
        // Do not generate an accessor if the prototype already has one, since
        // it would be lost otherwise and that would never be the user's intention;
        // Instead, we expect users to call `requestUpdate` themselves from
        // user-defined accessors. Note that if the super has an accessor we will
        // still overwrite it
        if (options.noAccessor || this.prototype.hasOwnProperty(name)) {
            return;
        }
        const key = typeof name === 'symbol' ? Symbol() : `__${name}`;
        const descriptor = this.getPropertyDescriptor(name, key, options);
        if (descriptor !== undefined) {
            Object.defineProperty(this.prototype, name, descriptor);
        }
    }
    /**
     * Returns a property descriptor to be defined on the given named property.
     * If no descriptor is returned, the property will not become an accessor.
     * For example,
     *
     *   class MyElement extends LitElement {
     *     static getPropertyDescriptor(name, key, options) {
     *       const defaultDescriptor =
     *           super.getPropertyDescriptor(name, key, options);
     *       const setter = defaultDescriptor.set;
     *       return {
     *         get: defaultDescriptor.get,
     *         set(value) {
     *           setter.call(this, value);
     *           // custom action.
     *         },
     *         configurable: true,
     *         enumerable: true
     *       }
     *     }
     *   }
     *
     * @nocollapse
     */
    static getPropertyDescriptor(name, key, options) {
        return {
            // tslint:disable-next-line:no-any no symbol in index
            get() {
                return this[key];
            },
            set(value) {
                const oldValue = this[name];
                this[key] = value;
                this
                    .requestUpdateInternal(name, oldValue, options);
            },
            configurable: true,
            enumerable: true
        };
    }
    /**
     * Returns the property options associated with the given property.
     * These options are defined with a PropertyDeclaration via the `properties`
     * object or the `@property` decorator and are registered in
     * `createProperty(...)`.
     *
     * Note, this method should be considered "final" and not overridden. To
     * customize the options for a given property, override `createProperty`.
     *
     * @nocollapse
     * @final
     */
    static getPropertyOptions(name) {
        return this._classProperties && this._classProperties.get(name) ||
            defaultPropertyDeclaration;
    }
    /**
     * Creates property accessors for registered properties and ensures
     * any superclasses are also finalized.
     * @nocollapse
     */
    static finalize() {
        // finalize any superclasses
        const superCtor = Object.getPrototypeOf(this);
        if (!superCtor.hasOwnProperty(finalized)) {
            superCtor.finalize();
        }
        this[finalized] = true;
        this._ensureClassProperties();
        // initialize Map populated in observedAttributes
        this._attributeToPropertyMap = new Map();
        // make any properties
        // Note, only process "own" properties since this element will inherit
        // any properties defined on the superClass, and finalization ensures
        // the entire prototype chain is finalized.
        if (this.hasOwnProperty(JSCompiler_renameProperty('properties', this))) {
            const props = this.properties;
            // support symbols in properties (IE11 does not support this)
            const propKeys = [
                ...Object.getOwnPropertyNames(props),
                ...(typeof Object.getOwnPropertySymbols === 'function') ?
                    Object.getOwnPropertySymbols(props) :
                    []
            ];
            // This for/of is ok because propKeys is an array
            for (const p of propKeys) {
                // note, use of `any` is due to TypeSript lack of support for symbol in
                // index types
                // tslint:disable-next-line:no-any no symbol in index
                this.createProperty(p, props[p]);
            }
        }
    }
    /**
     * Returns the property name for the given attribute `name`.
     * @nocollapse
     */
    static _attributeNameForProperty(name, options) {
        const attribute = options.attribute;
        return attribute === false ?
            undefined :
            (typeof attribute === 'string' ?
                attribute :
                (typeof name === 'string' ? name.toLowerCase() : undefined));
    }
    /**
     * Returns true if a property should request an update.
     * Called when a property value is set and uses the `hasChanged`
     * option for the property if present or a strict identity check.
     * @nocollapse
     */
    static _valueHasChanged(value, old, hasChanged = notEqual) {
        return hasChanged(value, old);
    }
    /**
     * Returns the property value for the given attribute value.
     * Called via the `attributeChangedCallback` and uses the property's
     * `converter` or `converter.fromAttribute` property option.
     * @nocollapse
     */
    static _propertyValueFromAttribute(value, options) {
        const type = options.type;
        const converter = options.converter || defaultConverter;
        const fromAttribute = (typeof converter === 'function' ? converter : converter.fromAttribute);
        return fromAttribute ? fromAttribute(value, type) : value;
    }
    /**
     * Returns the attribute value for the given property value. If this
     * returns undefined, the property will *not* be reflected to an attribute.
     * If this returns null, the attribute will be removed, otherwise the
     * attribute will be set to the value.
     * This uses the property's `reflect` and `type.toAttribute` property options.
     * @nocollapse
     */
    static _propertyValueToAttribute(value, options) {
        if (options.reflect === undefined) {
            return;
        }
        const type = options.type;
        const converter = options.converter;
        const toAttribute = converter && converter.toAttribute ||
            defaultConverter.toAttribute;
        return toAttribute(value, type);
    }
    /**
     * Performs element initialization. By default captures any pre-set values for
     * registered properties.
     */
    initialize() {
        this._updateState = 0;
        this._updatePromise =
            new Promise((res) => this._enableUpdatingResolver = res);
        this._changedProperties = new Map();
        this._saveInstanceProperties();
        // ensures first update will be caught by an early access of
        // `updateComplete`
        this.requestUpdateInternal();
    }
    /**
     * Fixes any properties set on the instance before upgrade time.
     * Otherwise these would shadow the accessor and break these properties.
     * The properties are stored in a Map which is played back after the
     * constructor runs. Note, on very old versions of Safari (<=9) or Chrome
     * (<=41), properties created for native platform properties like (`id` or
     * `name`) may not have default values set in the element constructor. On
     * these browsers native properties appear on instances and therefore their
     * default value will overwrite any element default (e.g. if the element sets
     * this.id = 'id' in the constructor, the 'id' will become '' since this is
     * the native platform default).
     */
    _saveInstanceProperties() {
        // Use forEach so this works even if for/of loops are compiled to for loops
        // expecting arrays
        this.constructor
            ._classProperties.forEach((_v, p) => {
            if (this.hasOwnProperty(p)) {
                const value = this[p];
                delete this[p];
                if (!this._instanceProperties) {
                    this._instanceProperties = new Map();
                }
                this._instanceProperties.set(p, value);
            }
        });
    }
    /**
     * Applies previously saved instance properties.
     */
    _applyInstanceProperties() {
        // Use forEach so this works even if for/of loops are compiled to for loops
        // expecting arrays
        // tslint:disable-next-line:no-any
        this._instanceProperties.forEach((v, p) => this[p] = v);
        this._instanceProperties = undefined;
    }
    connectedCallback() {
        // Ensure first connection completes an update. Updates cannot complete
        // before connection.
        this.enableUpdating();
    }
    enableUpdating() {
        if (this._enableUpdatingResolver !== undefined) {
            this._enableUpdatingResolver();
            this._enableUpdatingResolver = undefined;
        }
    }
    /**
     * Allows for `super.disconnectedCallback()` in extensions while
     * reserving the possibility of making non-breaking feature additions
     * when disconnecting at some point in the future.
     */
    disconnectedCallback() {
    }
    /**
     * Synchronizes property values when attributes change.
     */
    attributeChangedCallback(name, old, value) {
        if (old !== value) {
            this._attributeToProperty(name, value);
        }
    }
    _propertyToAttribute(name, value, options = defaultPropertyDeclaration) {
        const ctor = this.constructor;
        const attr = ctor._attributeNameForProperty(name, options);
        if (attr !== undefined) {
            const attrValue = ctor._propertyValueToAttribute(value, options);
            // an undefined value does not change the attribute.
            if (attrValue === undefined) {
                return;
            }
            // Track if the property is being reflected to avoid
            // setting the property again via `attributeChangedCallback`. Note:
            // 1. this takes advantage of the fact that the callback is synchronous.
            // 2. will behave incorrectly if multiple attributes are in the reaction
            // stack at time of calling. However, since we process attributes
            // in `update` this should not be possible (or an extreme corner case
            // that we'd like to discover).
            // mark state reflecting
            this._updateState = this._updateState | STATE_IS_REFLECTING_TO_ATTRIBUTE;
            if (attrValue == null) {
                this.removeAttribute(attr);
            }
            else {
                this.setAttribute(attr, attrValue);
            }
            // mark state not reflecting
            this._updateState = this._updateState & ~STATE_IS_REFLECTING_TO_ATTRIBUTE;
        }
    }
    _attributeToProperty(name, value) {
        // Use tracking info to avoid deserializing attribute value if it was
        // just set from a property setter.
        if (this._updateState & STATE_IS_REFLECTING_TO_ATTRIBUTE) {
            return;
        }
        const ctor = this.constructor;
        // Note, hint this as an `AttributeMap` so closure clearly understands
        // the type; it has issues with tracking types through statics
        // tslint:disable-next-line:no-unnecessary-type-assertion
        const propName = ctor._attributeToPropertyMap.get(name);
        if (propName !== undefined) {
            const options = ctor.getPropertyOptions(propName);
            // mark state reflecting
            this._updateState = this._updateState | STATE_IS_REFLECTING_TO_PROPERTY;
            this[propName] =
                // tslint:disable-next-line:no-any
                ctor._propertyValueFromAttribute(value, options);
            // mark state not reflecting
            this._updateState = this._updateState & ~STATE_IS_REFLECTING_TO_PROPERTY;
        }
    }
    /**
     * This protected version of `requestUpdate` does not access or return the
     * `updateComplete` promise. This promise can be overridden and is therefore
     * not free to access.
     */
    requestUpdateInternal(name, oldValue, options) {
        let shouldRequestUpdate = true;
        // If we have a property key, perform property update steps.
        if (name !== undefined) {
            const ctor = this.constructor;
            options = options || ctor.getPropertyOptions(name);
            if (ctor._valueHasChanged(this[name], oldValue, options.hasChanged)) {
                if (!this._changedProperties.has(name)) {
                    this._changedProperties.set(name, oldValue);
                }
                // Add to reflecting properties set.
                // Note, it's important that every change has a chance to add the
                // property to `_reflectingProperties`. This ensures setting
                // attribute + property reflects correctly.
                if (options.reflect === true &&
                    !(this._updateState & STATE_IS_REFLECTING_TO_PROPERTY)) {
                    if (this._reflectingProperties === undefined) {
                        this._reflectingProperties = new Map();
                    }
                    this._reflectingProperties.set(name, options);
                }
            }
            else {
                // Abort the request if the property should not be considered changed.
                shouldRequestUpdate = false;
            }
        }
        if (!this._hasRequestedUpdate && shouldRequestUpdate) {
            this._updatePromise = this._enqueueUpdate();
        }
    }
    /**
     * Requests an update which is processed asynchronously. This should
     * be called when an element should update based on some state not triggered
     * by setting a property. In this case, pass no arguments. It should also be
     * called when manually implementing a property setter. In this case, pass the
     * property `name` and `oldValue` to ensure that any configured property
     * options are honored. Returns the `updateComplete` Promise which is resolved
     * when the update completes.
     *
     * @param name {PropertyKey} (optional) name of requesting property
     * @param oldValue {any} (optional) old value of requesting property
     * @returns {Promise} A Promise that is resolved when the update completes.
     */
    requestUpdate(name, oldValue) {
        this.requestUpdateInternal(name, oldValue);
        return this.updateComplete;
    }
    /**
     * Sets up the element to asynchronously update.
     */
    async _enqueueUpdate() {
        this._updateState = this._updateState | STATE_UPDATE_REQUESTED;
        try {
            // Ensure any previous update has resolved before updating.
            // This `await` also ensures that property changes are batched.
            await this._updatePromise;
        }
        catch (e) {
            // Ignore any previous errors. We only care that the previous cycle is
            // done. Any error should have been handled in the previous update.
        }
        const result = this.performUpdate();
        // If `performUpdate` returns a Promise, we await it. This is done to
        // enable coordinating updates with a scheduler. Note, the result is
        // checked to avoid delaying an additional microtask unless we need to.
        if (result != null) {
            await result;
        }
        return !this._hasRequestedUpdate;
    }
    get _hasRequestedUpdate() {
        return (this._updateState & STATE_UPDATE_REQUESTED);
    }
    get hasUpdated() {
        return (this._updateState & STATE_HAS_UPDATED);
    }
    /**
     * Performs an element update. Note, if an exception is thrown during the
     * update, `firstUpdated` and `updated` will not be called.
     *
     * You can override this method to change the timing of updates. If this
     * method is overridden, `super.performUpdate()` must be called.
     *
     * For instance, to schedule updates to occur just before the next frame:
     *
     * ```
     * protected async performUpdate(): Promise<unknown> {
     *   await new Promise((resolve) => requestAnimationFrame(() => resolve()));
     *   super.performUpdate();
     * }
     * ```
     */
    performUpdate() {
        // Abort any update if one is not pending when this is called.
        // This can happen if `performUpdate` is called early to "flush"
        // the update.
        if (!this._hasRequestedUpdate) {
            return;
        }
        // Mixin instance properties once, if they exist.
        if (this._instanceProperties) {
            this._applyInstanceProperties();
        }
        let shouldUpdate = false;
        const changedProperties = this._changedProperties;
        try {
            shouldUpdate = this.shouldUpdate(changedProperties);
            if (shouldUpdate) {
                this.update(changedProperties);
            }
            else {
                this._markUpdated();
            }
        }
        catch (e) {
            // Prevent `firstUpdated` and `updated` from running when there's an
            // update exception.
            shouldUpdate = false;
            // Ensure element can accept additional updates after an exception.
            this._markUpdated();
            throw e;
        }
        if (shouldUpdate) {
            if (!(this._updateState & STATE_HAS_UPDATED)) {
                this._updateState = this._updateState | STATE_HAS_UPDATED;
                this.firstUpdated(changedProperties);
            }
            this.updated(changedProperties);
        }
    }
    _markUpdated() {
        this._changedProperties = new Map();
        this._updateState = this._updateState & ~STATE_UPDATE_REQUESTED;
    }
    /**
     * Returns a Promise that resolves when the element has completed updating.
     * The Promise value is a boolean that is `true` if the element completed the
     * update without triggering another update. The Promise result is `false` if
     * a property was set inside `updated()`. If the Promise is rejected, an
     * exception was thrown during the update.
     *
     * To await additional asynchronous work, override the `_getUpdateComplete`
     * method. For example, it is sometimes useful to await a rendered element
     * before fulfilling this Promise. To do this, first await
     * `super._getUpdateComplete()`, then any subsequent state.
     *
     * @returns {Promise} The Promise returns a boolean that indicates if the
     * update resolved without triggering another update.
     */
    get updateComplete() {
        return this._getUpdateComplete();
    }
    /**
     * Override point for the `updateComplete` promise.
     *
     * It is not safe to override the `updateComplete` getter directly due to a
     * limitation in TypeScript which means it is not possible to call a
     * superclass getter (e.g. `super.updateComplete.then(...)`) when the target
     * language is ES5 (https://github.com/microsoft/TypeScript/issues/338).
     * This method should be overridden instead. For example:
     *
     *   class MyElement extends LitElement {
     *     async _getUpdateComplete() {
     *       await super._getUpdateComplete();
     *       await this._myChild.updateComplete;
     *     }
     *   }
     * @deprecated Override `getUpdateComplete()` instead for forward
     *     compatibility with `lit-element` 3.0 / `@lit/reactive-element`.
     */
    _getUpdateComplete() {
        return this.getUpdateComplete();
    }
    /**
     * Override point for the `updateComplete` promise.
     *
     * It is not safe to override the `updateComplete` getter directly due to a
     * limitation in TypeScript which means it is not possible to call a
     * superclass getter (e.g. `super.updateComplete.then(...)`) when the target
     * language is ES5 (https://github.com/microsoft/TypeScript/issues/338).
     * This method should be overridden instead. For example:
     *
     *   class MyElement extends LitElement {
     *     async getUpdateComplete() {
     *       await super.getUpdateComplete();
     *       await this._myChild.updateComplete;
     *     }
     *   }
     */
    getUpdateComplete() {
        return this._updatePromise;
    }
    /**
     * Controls whether or not `update` should be called when the element requests
     * an update. By default, this method always returns `true`, but this can be
     * customized to control when to update.
     *
     * @param _changedProperties Map of changed properties with old values
     */
    shouldUpdate(_changedProperties) {
        return true;
    }
    /**
     * Updates the element. This method reflects property values to attributes.
     * It can be overridden to render and keep updated element DOM.
     * Setting properties inside this method will *not* trigger
     * another update.
     *
     * @param _changedProperties Map of changed properties with old values
     */
    update(_changedProperties) {
        if (this._reflectingProperties !== undefined &&
            this._reflectingProperties.size > 0) {
            // Use forEach so this works even if for/of loops are compiled to for
            // loops expecting arrays
            this._reflectingProperties.forEach((v, k) => this._propertyToAttribute(k, this[k], v));
            this._reflectingProperties = undefined;
        }
        this._markUpdated();
    }
    /**
     * Invoked whenever the element is updated. Implement to perform
     * post-updating tasks via DOM APIs, for example, focusing an element.
     *
     * Setting properties inside this method will trigger the element to update
     * again after this update cycle completes.
     *
     * @param _changedProperties Map of changed properties with old values
     */
    updated(_changedProperties) {
    }
    /**
     * Invoked when the element is first updated. Implement to perform one time
     * work on the element after update.
     *
     * Setting properties inside this method will trigger the element to update
     * again after this update cycle completes.
     *
     * @param _changedProperties Map of changed properties with old values
     */
    firstUpdated(_changedProperties) {
    }
}
_a = finalized;
/**
 * Marks class as having finished creating properties.
 */
UpdatingElement[_a] = true;

/**
@license
Copyright (c) 2019 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/
/**
 * Whether the current browser supports `adoptedStyleSheets`.
 */
const supportsAdoptingStyleSheets = (window.ShadowRoot) &&
    (window.ShadyCSS === undefined || window.ShadyCSS.nativeShadow) &&
    ('adoptedStyleSheets' in Document.prototype) &&
    ('replace' in CSSStyleSheet.prototype);
const constructionToken = Symbol();
class CSSResult {
    constructor(cssText, safeToken) {
        if (safeToken !== constructionToken) {
            throw new Error('CSSResult is not constructable. Use `unsafeCSS` or `css` instead.');
        }
        this.cssText = cssText;
    }
    // Note, this is a getter so that it's lazy. In practice, this means
    // stylesheets are not created until the first element instance is made.
    get styleSheet() {
        if (this._styleSheet === undefined) {
            // Note, if `supportsAdoptingStyleSheets` is true then we assume
            // CSSStyleSheet is constructable.
            if (supportsAdoptingStyleSheets) {
                this._styleSheet = new CSSStyleSheet();
                this._styleSheet.replaceSync(this.cssText);
            }
            else {
                this._styleSheet = null;
            }
        }
        return this._styleSheet;
    }
    toString() {
        return this.cssText;
    }
}
/**
 * Wrap a value for interpolation in a [[`css`]] tagged template literal.
 *
 * This is unsafe because untrusted CSS text can be used to phone home
 * or exfiltrate data to an attacker controlled site. Take care to only use
 * this with trusted input.
 */
const unsafeCSS = (value) => {
    return new CSSResult(String(value), constructionToken);
};
const textFromCSSResult = (value) => {
    if (value instanceof CSSResult) {
        return value.cssText;
    }
    else if (typeof value === 'number') {
        return value;
    }
    else {
        throw new Error(`Value passed to 'css' function must be a 'css' function result: ${value}. Use 'unsafeCSS' to pass non-literal values, but
            take care to ensure page security.`);
    }
};
/**
 * Template tag which which can be used with LitElement's [[LitElement.styles |
 * `styles`]] property to set element styles. For security reasons, only literal
 * string values may be used. To incorporate non-literal values [[`unsafeCSS`]]
 * may be used inside a template string part.
 */
const css = (strings, ...values) => {
    const cssText = values.reduce((acc, v, idx) => acc + textFromCSSResult(v) + strings[idx + 1], strings[0]);
    return new CSSResult(cssText, constructionToken);
};

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * The main LitElement module, which defines the [[`LitElement`]] base class and
 * related APIs.
 *
 *  LitElement components can define a template and a set of observed
 * properties. Changing an observed property triggers a re-render of the
 * element.
 *
 *  Import [[`LitElement`]] and [[`html`]] from this module to create a
 * component:
 *
 *  ```js
 * import {LitElement, html} from 'lit-element';
 *
 * class MyElement extends LitElement {
 *
 *   // Declare observed properties
 *   static get properties() {
 *     return {
 *       adjective: {}
 *     }
 *   }
 *
 *   constructor() {
 *     this.adjective = 'awesome';
 *   }
 *
 *   // Define the element's template
 *   render() {
 *     return html`<p>your ${adjective} template here</p>`;
 *   }
 * }
 *
 * customElements.define('my-element', MyElement);
 * ```
 *
 * `LitElement` extends [[`UpdatingElement`]] and adds lit-html templating.
 * The `UpdatingElement` class is provided for users that want to build
 * their own custom element base classes that don't use lit-html.
 *
 * @packageDocumentation
 */
// IMPORTANT: do not change the property name or the assignment expression.
// This line will be used in regexes to search for LitElement usage.
// TODO(justinfagnani): inject version number at build time
(window['litElementVersions'] || (window['litElementVersions'] = []))
    .push('2.5.1');
/**
 * Sentinal value used to avoid calling lit-html's render function when
 * subclasses do not implement `render`
 */
const renderNotImplemented = {};
/**
 * Base element class that manages element properties and attributes, and
 * renders a lit-html template.
 *
 * To define a component, subclass `LitElement` and implement a
 * `render` method to provide the component's template. Define properties
 * using the [[`properties`]] property or the [[`property`]] decorator.
 */
class LitElement extends UpdatingElement {
    /**
     * Return the array of styles to apply to the element.
     * Override this method to integrate into a style management system.
     *
     * @nocollapse
     */
    static getStyles() {
        return this.styles;
    }
    /** @nocollapse */
    static _getUniqueStyles() {
        // Only gather styles once per class
        if (this.hasOwnProperty(JSCompiler_renameProperty('_styles', this))) {
            return;
        }
        // Take care not to call `this.getStyles()` multiple times since this
        // generates new CSSResults each time.
        // TODO(sorvell): Since we do not cache CSSResults by input, any
        // shared styles will generate new stylesheet objects, which is wasteful.
        // This should be addressed when a browser ships constructable
        // stylesheets.
        const userStyles = this.getStyles();
        if (Array.isArray(userStyles)) {
            // De-duplicate styles preserving the _last_ instance in the set.
            // This is a performance optimization to avoid duplicated styles that can
            // occur especially when composing via subclassing.
            // The last item is kept to try to preserve the cascade order with the
            // assumption that it's most important that last added styles override
            // previous styles.
            const addStyles = (styles, set) => styles.reduceRight((set, s) => 
            // Note: On IE set.add() does not return the set
            Array.isArray(s) ? addStyles(s, set) : (set.add(s), set), set);
            // Array.from does not work on Set in IE, otherwise return
            // Array.from(addStyles(userStyles, new Set<CSSResult>())).reverse()
            const set = addStyles(userStyles, new Set());
            const styles = [];
            set.forEach((v) => styles.unshift(v));
            this._styles = styles;
        }
        else {
            this._styles = userStyles === undefined ? [] : [userStyles];
        }
        // Ensure that there are no invalid CSSStyleSheet instances here. They are
        // invalid in two conditions.
        // (1) the sheet is non-constructible (`sheet` of a HTMLStyleElement), but
        //     this is impossible to check except via .replaceSync or use
        // (2) the ShadyCSS polyfill is enabled (:. supportsAdoptingStyleSheets is
        //     false)
        this._styles = this._styles.map((s) => {
            if (s instanceof CSSStyleSheet && !supportsAdoptingStyleSheets) {
                // Flatten the cssText from the passed constructible stylesheet (or
                // undetectable non-constructible stylesheet). The user might have
                // expected to update their stylesheets over time, but the alternative
                // is a crash.
                const cssText = Array.prototype.slice.call(s.cssRules)
                    .reduce((css, rule) => css + rule.cssText, '');
                return unsafeCSS(cssText);
            }
            return s;
        });
    }
    /**
     * Performs element initialization. By default this calls
     * [[`createRenderRoot`]] to create the element [[`renderRoot`]] node and
     * captures any pre-set values for registered properties.
     */
    initialize() {
        super.initialize();
        this.constructor._getUniqueStyles();
        this.renderRoot = this.createRenderRoot();
        // Note, if renderRoot is not a shadowRoot, styles would/could apply to the
        // element's getRootNode(). While this could be done, we're choosing not to
        // support this now since it would require different logic around de-duping.
        if (window.ShadowRoot && this.renderRoot instanceof window.ShadowRoot) {
            this.adoptStyles();
        }
    }
    /**
     * Returns the node into which the element should render and by default
     * creates and returns an open shadowRoot. Implement to customize where the
     * element's DOM is rendered. For example, to render into the element's
     * childNodes, return `this`.
     * @returns {Element|DocumentFragment} Returns a node into which to render.
     */
    createRenderRoot() {
        return this.attachShadow(this.constructor.shadowRootOptions);
    }
    /**
     * Applies styling to the element shadowRoot using the [[`styles`]]
     * property. Styling will apply using `shadowRoot.adoptedStyleSheets` where
     * available and will fallback otherwise. When Shadow DOM is polyfilled,
     * ShadyCSS scopes styles and adds them to the document. When Shadow DOM
     * is available but `adoptedStyleSheets` is not, styles are appended to the
     * end of the `shadowRoot` to [mimic spec
     * behavior](https://wicg.github.io/construct-stylesheets/#using-constructed-stylesheets).
     */
    adoptStyles() {
        const styles = this.constructor._styles;
        if (styles.length === 0) {
            return;
        }
        // There are three separate cases here based on Shadow DOM support.
        // (1) shadowRoot polyfilled: use ShadyCSS
        // (2) shadowRoot.adoptedStyleSheets available: use it
        // (3) shadowRoot.adoptedStyleSheets polyfilled: append styles after
        // rendering
        if (window.ShadyCSS !== undefined && !window.ShadyCSS.nativeShadow) {
            window.ShadyCSS.ScopingShim.prepareAdoptedCssText(styles.map((s) => s.cssText), this.localName);
        }
        else if (supportsAdoptingStyleSheets) {
            this.renderRoot.adoptedStyleSheets =
                styles.map((s) => s instanceof CSSStyleSheet ? s : s.styleSheet);
        }
        else {
            // This must be done after rendering so the actual style insertion is done
            // in `update`.
            this._needsShimAdoptedStyleSheets = true;
        }
    }
    connectedCallback() {
        super.connectedCallback();
        // Note, first update/render handles styleElement so we only call this if
        // connected after first update.
        if (this.hasUpdated && window.ShadyCSS !== undefined) {
            window.ShadyCSS.styleElement(this);
        }
    }
    /**
     * Updates the element. This method reflects property values to attributes
     * and calls `render` to render DOM via lit-html. Setting properties inside
     * this method will *not* trigger another update.
     * @param _changedProperties Map of changed properties with old values
     */
    update(changedProperties) {
        // Setting properties in `render` should not trigger an update. Since
        // updates are allowed after super.update, it's important to call `render`
        // before that.
        const templateResult = this.render();
        super.update(changedProperties);
        // If render is not implemented by the component, don't call lit-html render
        if (templateResult !== renderNotImplemented) {
            this.constructor
                .render(templateResult, this.renderRoot, { scopeName: this.localName, eventContext: this });
        }
        // When native Shadow DOM is used but adoptedStyles are not supported,
        // insert styling after rendering to ensure adoptedStyles have highest
        // priority.
        if (this._needsShimAdoptedStyleSheets) {
            this._needsShimAdoptedStyleSheets = false;
            this.constructor._styles.forEach((s) => {
                const style = document.createElement('style');
                style.textContent = s.cssText;
                this.renderRoot.appendChild(style);
            });
        }
    }
    /**
     * Invoked on each update to perform rendering tasks. This method may return
     * any value renderable by lit-html's `NodePart` - typically a
     * `TemplateResult`. Setting properties inside this method will *not* trigger
     * the element to update.
     */
    render() {
        return renderNotImplemented;
    }
}
/**
 * Ensure this class is marked as `finalized` as an optimization ensuring
 * it will not needlessly try to `finalize`.
 *
 * Note this property name is a string to prevent breaking Closure JS Compiler
 * optimizations. See updating-element.ts for more information.
 */
LitElement['finalized'] = true;
/**
 * Reference to the underlying library method used to render the element's
 * DOM. By default, points to the `render` method from lit-html's shady-render
 * module.
 *
 * **Most users will never need to touch this property.**
 *
 * This  property should not be confused with the `render` instance method,
 * which should be overridden to define a template for the element.
 *
 * Advanced users creating a new base class based on LitElement can override
 * this property to point to a custom render method with a signature that
 * matches [shady-render's `render`
 * method](https://lit-html.polymer-project.org/api/modules/shady_render.html#render).
 *
 * @nocollapse
 */
LitElement.render = render;
/** @nocollapse */
LitElement.shadowRootOptions = { mode: 'open' };

var styleCss$6 = css`*,*:before,*:after{box-sizing:border-box}@media(prefers-reduced-motion: reduce){*,*:before,*:after{animation-duration:.01ms !important;animation-iteration-count:1 !important;transition-duration:.01ms !important}}*:focus-visible{outline:0}*:focus-visible{outline:0}:focus:not(:focus-visible){outline:3px solid transparent}:host auro-checkbox-group{margin-bottom:var(--ds-size-400, 2rem)}:host [auro-checkbox]:first-of-type{margin-top:var(--ds-size-100, 0.5rem)}:host [auro-checkbox]:last-of-type{margin-bottom:var(--ds-size-200, 1rem)}:host .selector{margin-top:var(--ds-size-200, 1rem)}:host .finePrint{margin-top:var(--ds-size-200, 1rem);margin-bottom:0;color:var(--ds-color-text-secondary-default, #525252);font-size:var(--ds-text-body-size-xs, 0.75rem);font-style:italic;line-height:var(--ds-text-body-height-xs, 1rem)}:host .applicator{display:none;padding:var(--ds-size-200, 1rem);border:1px solid var(--ds-color-border-secondary-default, #939fad);margin-top:var(--ds-size-200, 1rem);background-color:var(--ds-color-container-secondary-default, #f7f7f7)}`;

// Copyright (c) Alaska Air. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.


class AuroDependencyVersioning {

  /**
   * Generates a unique string to be used for child auro element naming.
   * @private
   * @param {string} baseName - Defines the first part of the unique element name.
   * @param {string} version - Version of the component that will be appended to the baseName.
   * @returns {string} - Unique string to be used for naming.
   */
  generateElementName(baseName, version) {
    let result = baseName;

    result += '-';
    result += version.replace(/[.]/g, '_');

    return result;
  }

  /**
   * Generates a unique string to be used for child auro element naming.
   * @param {string} baseName - Defines the first part of the unique element name.
   * @param {string} version - Version of the component that will be appended to the baseName.
   * @returns {string} - Unique string to be used for naming.
   */
  generateTag(baseName, version, tagClass) {
    const elementName = this.generateElementName(baseName, version);
    const tag = i$6`${o$5(elementName)}`;

    if (!customElements.get(elementName)) {
      customElements.define(elementName, class extends tagClass {});
    }

    return tag;
  }
}

/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t$2=globalThis,e$4=t$2.ShadowRoot&&(void 0===t$2.ShadyCSS||t$2.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,s$4=Symbol(),o$4=new WeakMap;let n$3 = class n{constructor(t,e,o){if(this._$cssResult$=!0,o!==s$4)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e;}get styleSheet(){let t=this.o;const s=this.t;if(e$4&&void 0===t){const e=void 0!==s&&1===s.length;e&&(t=o$4.get(s)),void 0===t&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),e&&o$4.set(s,t));}return t}toString(){return this.cssText}};const r$7=t=>new n$3("string"==typeof t?t:t+"",void 0,s$4),i$5=(t,...e)=>{const o=1===t.length?t[0]:e.reduce(((e,s,o)=>e+(t=>{if(!0===t._$cssResult$)return t.cssText;if("number"==typeof t)return t;throw Error("Value passed to 'css' function must be a 'css' function result: "+t+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(s)+t[o+1]),t[0]);return new n$3(o,t,s$4)},S$1=(s,o)=>{if(e$4)s.adoptedStyleSheets=o.map((t=>t instanceof CSSStyleSheet?t:t.styleSheet));else for(const e of o){const o=document.createElement("style"),n=t$2.litNonce;void 0!==n&&o.setAttribute("nonce",n),o.textContent=e.cssText,s.appendChild(o);}},c$2=e$4?t=>t:t=>t instanceof CSSStyleSheet?(t=>{let e="";for(const s of t.cssRules)e+=s.cssText;return r$7(e)})(t):t;

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{is:i$4,defineProperty:e$3,getOwnPropertyDescriptor:r$6,getOwnPropertyNames:h$1,getOwnPropertySymbols:o$3,getPrototypeOf:n$2}=Object,a$2=globalThis,c$1=a$2.trustedTypes,l$2=c$1?c$1.emptyScript:"",p$1=a$2.reactiveElementPolyfillSupport,d$1=(t,s)=>t,u$2={toAttribute(t,s){switch(s){case Boolean:t=t?l$2:null;break;case Object:case Array:t=null==t?t:JSON.stringify(t);}return t},fromAttribute(t,s){let i=t;switch(s){case Boolean:i=null!==t;break;case Number:i=null===t?null:Number(t);break;case Object:case Array:try{i=JSON.parse(t);}catch(t){i=null;}}return i}},f$1=(t,s)=>!i$4(t,s),y$1={attribute:!0,type:String,converter:u$2,reflect:!1,hasChanged:f$1};Symbol.metadata??=Symbol("metadata"),a$2.litPropertyMetadata??=new WeakMap;class b extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??=[]).push(t);}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,s=y$1){if(s.state&&(s.attribute=!1),this._$Ei(),this.elementProperties.set(t,s),!s.noAccessor){const i=Symbol(),r=this.getPropertyDescriptor(t,i,s);void 0!==r&&e$3(this.prototype,t,r);}}static getPropertyDescriptor(t,s,i){const{get:e,set:h}=r$6(this.prototype,t)??{get(){return this[s]},set(t){this[s]=t;}};return {get(){return e?.call(this)},set(s){const r=e?.call(this);h.call(this,s),this.requestUpdate(t,r,i);},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??y$1}static _$Ei(){if(this.hasOwnProperty(d$1("elementProperties")))return;const t=n$2(this);t.finalize(),void 0!==t.l&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties);}static finalize(){if(this.hasOwnProperty(d$1("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(d$1("properties"))){const t=this.properties,s=[...h$1(t),...o$3(t)];for(const i of s)this.createProperty(i,t[i]);}const t=this[Symbol.metadata];if(null!==t){const s=litPropertyMetadata.get(t);if(void 0!==s)for(const[t,i]of s)this.elementProperties.set(t,i);}this._$Eh=new Map;for(const[t,s]of this.elementProperties){const i=this._$Eu(t,s);void 0!==i&&this._$Eh.set(i,t);}this.elementStyles=this.finalizeStyles(this.styles);}static finalizeStyles(s){const i=[];if(Array.isArray(s)){const e=new Set(s.flat(1/0).reverse());for(const s of e)i.unshift(c$2(s));}else void 0!==s&&i.push(c$2(s));return i}static _$Eu(t,s){const i=s.attribute;return !1===i?void 0:"string"==typeof i?i:"string"==typeof t?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev();}_$Ev(){this._$ES=new Promise((t=>this.enableUpdating=t)),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach((t=>t(this)));}addController(t){(this._$EO??=new Set).add(t),void 0!==this.renderRoot&&this.isConnected&&t.hostConnected?.();}removeController(t){this._$EO?.delete(t);}_$E_(){const t=new Map,s=this.constructor.elementProperties;for(const i of s.keys())this.hasOwnProperty(i)&&(t.set(i,this[i]),delete this[i]);t.size>0&&(this._$Ep=t);}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return S$1(t,this.constructor.elementStyles),t}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach((t=>t.hostConnected?.()));}enableUpdating(t){}disconnectedCallback(){this._$EO?.forEach((t=>t.hostDisconnected?.()));}attributeChangedCallback(t,s,i){this._$AK(t,i);}_$EC(t,s){const i=this.constructor.elementProperties.get(t),e=this.constructor._$Eu(t,i);if(void 0!==e&&!0===i.reflect){const r=(void 0!==i.converter?.toAttribute?i.converter:u$2).toAttribute(s,i.type);this._$Em=t,null==r?this.removeAttribute(e):this.setAttribute(e,r),this._$Em=null;}}_$AK(t,s){const i=this.constructor,e=i._$Eh.get(t);if(void 0!==e&&this._$Em!==e){const t=i.getPropertyOptions(e),r="function"==typeof t.converter?{fromAttribute:t.converter}:void 0!==t.converter?.fromAttribute?t.converter:u$2;this._$Em=e,this[e]=r.fromAttribute(s,t.type),this._$Em=null;}}requestUpdate(t,s,i){if(void 0!==t){if(i??=this.constructor.getPropertyOptions(t),!(i.hasChanged??f$1)(this[t],s))return;this.P(t,s,i);}!1===this.isUpdatePending&&(this._$ES=this._$ET());}P(t,s,i){this._$AL.has(t)||this._$AL.set(t,s),!0===i.reflect&&this._$Em!==t&&(this._$Ej??=new Set).add(t);}async _$ET(){this.isUpdatePending=!0;try{await this._$ES;}catch(t){Promise.reject(t);}const t=this.scheduleUpdate();return null!=t&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(const[t,s]of this._$Ep)this[t]=s;this._$Ep=void 0;}const t=this.constructor.elementProperties;if(t.size>0)for(const[s,i]of t)!0!==i.wrapped||this._$AL.has(s)||void 0===this[s]||this.P(s,this[s],i);}let t=!1;const s=this._$AL;try{t=this.shouldUpdate(s),t?(this.willUpdate(s),this._$EO?.forEach((t=>t.hostUpdate?.())),this.update(s)):this._$EU();}catch(s){throw t=!1,this._$EU(),s}t&&this._$AE(s);}willUpdate(t){}_$AE(t){this._$EO?.forEach((t=>t.hostUpdated?.())),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t);}_$EU(){this._$AL=new Map,this.isUpdatePending=!1;}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return !0}update(t){this._$Ej&&=this._$Ej.forEach((t=>this._$EC(t,this[t]))),this._$EU();}updated(t){}firstUpdated(t){}}b.elementStyles=[],b.shadowRootOptions={mode:"open"},b[d$1("elementProperties")]=new Map,b[d$1("finalized")]=new Map,p$1?.({ReactiveElement:b}),(a$2.reactiveElementVersions??=[]).push("2.0.4");

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t$1=globalThis,i$3=t$1.trustedTypes,s$3=i$3?i$3.createPolicy("lit-html",{createHTML:t=>t}):void 0,e$2="$lit$",h=`lit$${Math.random().toFixed(9).slice(2)}$`,o$2="?"+h,n$1=`<${o$2}>`,r$5=document,l$1=()=>r$5.createComment(""),c=t=>null===t||"object"!=typeof t&&"function"!=typeof t,a$1=Array.isArray,u$1=t=>a$1(t)||"function"==typeof t?.[Symbol.iterator],d="[ \t\n\f\r]",f=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,v=/-->/g,_=/>/g,m=RegExp(`>|${d}(?:([^\\s"'>=/]+)(${d}*=${d}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),p=/'/g,g=/"/g,$=/^(?:script|style|textarea|title)$/i,y=t=>(i,...s)=>({_$litType$:t,strings:i,values:s}),x=y(1),T=Symbol.for("lit-noChange"),E=Symbol.for("lit-nothing"),A=new WeakMap,C=r$5.createTreeWalker(r$5,129);function P(t,i){if(!a$1(t)||!t.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==s$3?s$3.createHTML(i):i}const V=(t,i)=>{const s=t.length-1,o=[];let r,l=2===i?"<svg>":3===i?"<math>":"",c=f;for(let i=0;i<s;i++){const s=t[i];let a,u,d=-1,y=0;for(;y<s.length&&(c.lastIndex=y,u=c.exec(s),null!==u);)y=c.lastIndex,c===f?"!--"===u[1]?c=v:void 0!==u[1]?c=_:void 0!==u[2]?($.test(u[2])&&(r=RegExp("</"+u[2],"g")),c=m):void 0!==u[3]&&(c=m):c===m?">"===u[0]?(c=r??f,d=-1):void 0===u[1]?d=-2:(d=c.lastIndex-u[2].length,a=u[1],c=void 0===u[3]?m:'"'===u[3]?g:p):c===g||c===p?c=m:c===v||c===_?c=f:(c=m,r=void 0);const x=c===m&&t[i+1].startsWith("/>")?" ":"";l+=c===f?s+n$1:d>=0?(o.push(a),s.slice(0,d)+e$2+s.slice(d)+h+x):s+h+(-2===d?i:x);}return [P(t,l+(t[s]||"<?>")+(2===i?"</svg>":3===i?"</math>":"")),o]};class N{constructor({strings:t,_$litType$:s},n){let r;this.parts=[];let c=0,a=0;const u=t.length-1,d=this.parts,[f,v]=V(t,s);if(this.el=N.createElement(f,n),C.currentNode=this.el.content,2===s||3===s){const t=this.el.content.firstChild;t.replaceWith(...t.childNodes);}for(;null!==(r=C.nextNode())&&d.length<u;){if(1===r.nodeType){if(r.hasAttributes())for(const t of r.getAttributeNames())if(t.endsWith(e$2)){const i=v[a++],s=r.getAttribute(t).split(h),e=/([.?@])?(.*)/.exec(i);d.push({type:1,index:c,name:e[2],strings:s,ctor:"."===e[1]?H:"?"===e[1]?I:"@"===e[1]?L:k}),r.removeAttribute(t);}else t.startsWith(h)&&(d.push({type:6,index:c}),r.removeAttribute(t));if($.test(r.tagName)){const t=r.textContent.split(h),s=t.length-1;if(s>0){r.textContent=i$3?i$3.emptyScript:"";for(let i=0;i<s;i++)r.append(t[i],l$1()),C.nextNode(),d.push({type:2,index:++c});r.append(t[s],l$1());}}}else if(8===r.nodeType)if(r.data===o$2)d.push({type:2,index:c});else {let t=-1;for(;-1!==(t=r.data.indexOf(h,t+1));)d.push({type:7,index:c}),t+=h.length-1;}c++;}}static createElement(t,i){const s=r$5.createElement("template");return s.innerHTML=t,s}}function S(t,i,s=t,e){if(i===T)return i;let h=void 0!==e?s._$Co?.[e]:s._$Cl;const o=c(i)?void 0:i._$litDirective$;return h?.constructor!==o&&(h?._$AO?.(!1),void 0===o?h=void 0:(h=new o(t),h._$AT(t,s,e)),void 0!==e?(s._$Co??=[])[e]=h:s._$Cl=h),void 0!==h&&(i=S(t,h._$AS(t,i.values),h,e)),i}class M{constructor(t,i){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=i;}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:i},parts:s}=this._$AD,e=(t?.creationScope??r$5).importNode(i,!0);C.currentNode=e;let h=C.nextNode(),o=0,n=0,l=s[0];for(;void 0!==l;){if(o===l.index){let i;2===l.type?i=new R(h,h.nextSibling,this,t):1===l.type?i=new l.ctor(h,l.name,l.strings,this,t):6===l.type&&(i=new z(h,this,t)),this._$AV.push(i),l=s[++n];}o!==l?.index&&(h=C.nextNode(),o++);}return C.currentNode=r$5,e}p(t){let i=0;for(const s of this._$AV)void 0!==s&&(void 0!==s.strings?(s._$AI(t,s,i),i+=s.strings.length-2):s._$AI(t[i])),i++;}}class R{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,i,s,e){this.type=2,this._$AH=E,this._$AN=void 0,this._$AA=t,this._$AB=i,this._$AM=s,this.options=e,this._$Cv=e?.isConnected??!0;}get parentNode(){let t=this._$AA.parentNode;const i=this._$AM;return void 0!==i&&11===t?.nodeType&&(t=i.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,i=this){t=S(this,t,i),c(t)?t===E||null==t||""===t?(this._$AH!==E&&this._$AR(),this._$AH=E):t!==this._$AH&&t!==T&&this._(t):void 0!==t._$litType$?this.$(t):void 0!==t.nodeType?this.T(t):u$1(t)?this.k(t):this._(t);}O(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t));}_(t){this._$AH!==E&&c(this._$AH)?this._$AA.nextSibling.data=t:this.T(r$5.createTextNode(t)),this._$AH=t;}$(t){const{values:i,_$litType$:s}=t,e="number"==typeof s?this._$AC(t):(void 0===s.el&&(s.el=N.createElement(P(s.h,s.h[0]),this.options)),s);if(this._$AH?._$AD===e)this._$AH.p(i);else {const t=new M(e,this),s=t.u(this.options);t.p(i),this.T(s),this._$AH=t;}}_$AC(t){let i=A.get(t.strings);return void 0===i&&A.set(t.strings,i=new N(t)),i}k(t){a$1(this._$AH)||(this._$AH=[],this._$AR());const i=this._$AH;let s,e=0;for(const h of t)e===i.length?i.push(s=new R(this.O(l$1()),this.O(l$1()),this,this.options)):s=i[e],s._$AI(h),e++;e<i.length&&(this._$AR(s&&s._$AB.nextSibling,e),i.length=e);}_$AR(t=this._$AA.nextSibling,i){for(this._$AP?.(!1,!0,i);t&&t!==this._$AB;){const i=t.nextSibling;t.remove(),t=i;}}setConnected(t){void 0===this._$AM&&(this._$Cv=t,this._$AP?.(t));}}class k{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,i,s,e,h){this.type=1,this._$AH=E,this._$AN=void 0,this.element=t,this.name=i,this._$AM=e,this.options=h,s.length>2||""!==s[0]||""!==s[1]?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=E;}_$AI(t,i=this,s,e){const h=this.strings;let o=!1;if(void 0===h)t=S(this,t,i,0),o=!c(t)||t!==this._$AH&&t!==T,o&&(this._$AH=t);else {const e=t;let n,r;for(t=h[0],n=0;n<h.length-1;n++)r=S(this,e[s+n],i,n),r===T&&(r=this._$AH[n]),o||=!c(r)||r!==this._$AH[n],r===E?t=E:t!==E&&(t+=(r??"")+h[n+1]),this._$AH[n]=r;}o&&!e&&this.j(t);}j(t){t===E?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"");}}class H extends k{constructor(){super(...arguments),this.type=3;}j(t){this.element[this.name]=t===E?void 0:t;}}class I extends k{constructor(){super(...arguments),this.type=4;}j(t){this.element.toggleAttribute(this.name,!!t&&t!==E);}}class L extends k{constructor(t,i,s,e,h){super(t,i,s,e,h),this.type=5;}_$AI(t,i=this){if((t=S(this,t,i,0)??E)===T)return;const s=this._$AH,e=t===E&&s!==E||t.capture!==s.capture||t.once!==s.once||t.passive!==s.passive,h=t!==E&&(s===E||e);e&&this.element.removeEventListener(this.name,this,s),h&&this.element.addEventListener(this.name,this,t),this._$AH=t;}handleEvent(t){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t);}}class z{constructor(t,i,s){this.element=t,this.type=6,this._$AN=void 0,this._$AM=i,this.options=s;}get _$AU(){return this._$AM._$AU}_$AI(t){S(this,t);}}const j=t$1.litHtmlPolyfillSupport;j?.(N,R),(t$1.litHtmlVersions??=[]).push("3.2.1");const B=(t,i,s)=>{const e=s?.renderBefore??i;let h=e._$litPart$;if(void 0===h){const t=s?.renderBefore??null;e._$litPart$=h=new R(i.insertBefore(l$1(),t),t,void 0,s??{});}return h._$AI(t),h};

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let s$2 = class s extends b{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0;}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const i=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=B(i,this.renderRoot,this.renderOptions);}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0);}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1);}render(){return T}};s$2._$litElement$=!0,s$2[("finalized")]=!0,globalThis.litElementHydrateSupport?.({LitElement:s$2});const r$4=globalThis.litElementPolyfillSupport;r$4?.({LitElement:s$2});(globalThis.litElementVersions??=[]).push("4.0.6");

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},e$1=t=>(...e)=>({_$litDirective$:t,values:e});let i$2 = class i{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i;}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}};

/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const e=e$1(class extends i$2{constructor(t$1){if(super(t$1),t$1.type!==t.ATTRIBUTE||"class"!==t$1.name||t$1.strings?.length>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(t){return " "+Object.keys(t).filter((s=>t[s])).join(" ")+" "}update(s,[i]){if(void 0===this.st){this.st=new Set,void 0!==s.strings&&(this.nt=new Set(s.strings.join(" ").split(/\s/).filter((t=>""!==t))));for(const t in i)i[t]&&!this.nt?.has(t)&&this.st.add(t);return this.render(i)}const r=s.element.classList;for(const t of this.st)t in i||(r.remove(t),this.st.delete(t));for(const t in i){const s=!!i[t];s===this.st.has(t)||this.nt?.has(t)||(s?(r.add(t),this.st.add(t)):(r.remove(t),this.st.delete(t)));}return T}});

/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const o$1=o=>o??E;

var styleCss$5 = i$5`*,*:before,*:after{box-sizing:border-box}@media(prefers-reduced-motion: reduce){*,*:before,*:after{animation-duration:.01ms !important;animation-iteration-count:1 !important;transition-duration:.01ms !important}}*:focus-visible{outline:0}*:focus-visible{outline:0}:focus:not(:focus-visible){outline:3px solid transparent}.util_displayInline{display:inline}.util_displayInlineBlock{display:inline-block}.util_displayBlock{display:block}.util_displayFlex{display:flex}.util_displayHidden{display:none}.util_displayHiddenVisually{position:absolute;overflow:hidden;clip:rect(1px, 1px, 1px, 1px);width:1px;height:1px;padding:0;border:0}:host{display:block;--cbxLocation:var(--ds-size-50, $ds-size-50)}fieldset{all:unset}@media screen and (min-width: 576px){.displayFlex slot{display:flex}}.cbxContainer{position:relative;padding-left:var(--ds-size-100, 0.5rem);padding-right:var(--ds-size-100, 0.5rem);line-height:var(--ds-size-400, 2rem)}.cbx--input:disabled+label:hover{cursor:auto}.label{margin-left:var(--ds-size-300, 1.5rem);display:block}.label:hover{cursor:pointer}.label--cbx:after{-webkit-tap-highlight-color:transparent;position:absolute;content:"";top:var(--ds-size-50, 0.25rem);left:var(--cbxLocation);width:calc(var(--ds-size-200, 1rem) + var(--ds-size-50, 0.25rem));height:calc(var(--ds-size-200, 1rem) + var(--ds-size-50, 0.25rem));border-width:1px;border-style:solid;border-radius:var(--ds-border-radius, 0.375rem);outline-style:solid;outline-width:1px;z-index:0}.svg--cbx{position:absolute;top:var(--ds-size-25, 0.125rem);left:var(--ds-size-25, 0.125rem);padding-top:3px;padding-bottom:3px;z-index:1}`;

var colorCss$3 = i$5`:host .label{color:var(--ds-auro-checkbox-label-color)}:host .label--cbx:after{background-color:var(--ds-auro-checkbox-container-color);border-color:var(--ds-auro-checkbox-border-color);outline-color:var(--ds-auro-checkbox-outline-color)}:host .label--cbx:hover{--ds-auro-checkbox-container-color:var(--ds-color-container-ui-secondary-hover-default, rgba(0, 0, 0, 0.03))}:host .svg--cbx{color:var(--ds-auro-checkbox-checkmark-color)}:host(:focus-within){--ds-auro-checkbox-border-color:var(--ds-color-border-ui-active-default, #225296);--ds-auro-checkbox-outline-color:var(--ds-color-border-ui-active-default, #225296)}:host([checked]){--ds-auro-checkbox-border-color:var(--ds-color-border-ui-default-default, #2c67b5);--ds-auro-checkbox-container-color:var(--ds-color-container-ui-primary-default-default, #2c67b5)}:host([checked]):hover{--ds-auro-checkbox-border-color:var(--ds-color-border-ui-hover-default, #193d73);--ds-auro-checkbox-container-color:var(--ds-color-container-ui-primary-hover-default, #193d73)}:host([checked]:focus-within){--ds-auro-checkbox-border-color:var(--ds-color-border-subtle-default, #f0f7fd)}:host([checked]:focus-within):hover{--ds-auro-checkbox-border-color:var(--ds-color-border-subtle-default, #f0f7fd);--ds-auro-checkbox-container-color:var(--ds-color-container-ui-primary-hover-default, #193d73)}:host([disabled]){--ds-auro-checkbox-border-color:var(--ds-color-border-ui-disabled-default, #adadad);--ds-auro-checkbox-container-color:var(--ds-color-container-primary-default, #ffffff);--ds-auro-checkbox-label-color:var(--ds-color-text-ui-disabled-default, #adadad)}:host([disabled]):hover{--ds-auro-checkbox-border-color:var(--ds-color-border-ui-disabled-default, #adadad);--ds-auro-checkbox-container-color:var(--ds-color-container-primary-default, #ffffff)}:host([disabled][checked]){--ds-auro-checkbox-border-color:var(--ds-color-border-ui-disabled-default, #adadad);--ds-auro-checkbox-checkmark-color:var(--ds-color-icon-ui-disabled-default, #adadad);--ds-auro-checkbox-container-color:var(--ds-color-container-primary-default, #ffffff)}:host([disabled][checked]):hover{--ds-auro-checkbox-border-color:var(--ds-color-border-ui-disabled-default, #adadad);--ds-auro-checkbox-container-color:var(--ds-color-container-primary-default, #ffffff)}:host([error]){--ds-auro-checkbox-border-color:var(--ds-color-utility-error-default, #cc1816);--ds-auro-checkbox-container-color:var(--ds-color-container-primary-default, #ffffff)}:host([error]:not([checked]):focus-within){--ds-auro-checkbox-border-color:var(--ds-color-border-ui-active-default, #225296);--ds-auro-checkbox-outline-color:var(--ds-color-border-ui-active-default, #225296)}:host([error][checked]){--ds-auro-checkbox-border-color:var(--ds-color-border-error-default, #cc1816);--ds-auro-checkbox-container-color:var(--ds-color-utility-error-default, #cc1816)}:host([error][checked]):hover{--ds-auro-checkbox-border-color:var(--ds-color-container-error-inverse, #74110e);--ds-auro-checkbox-container-color:var(--ds-color-container-error-inverse, #df0b37)}:host([error][checked]:focus-within){--ds-auro-checkbox-border-color:var(--ds-color-border-subtle-default, #f0f7fd)}:host([error][checked]:focus-within):hover{--ds-auro-checkbox-border-color:var(--ds-color-border-subtle-default, #f0f7fd);--ds-auro-checkbox-container-color:var(--ds-color-utility-error-default, #cc1816)}`;

var tokensCss$4 = i$5`:host{--ds-auro-checkbox-border-color:var(--ds-color-border-primary-default, #585e67);--ds-auro-checkbox-checkmark-color:var(--ds-color-icon-emphasis-inverse, #ffffff);--ds-auro-checkbox-container-color:var(--ds-color-container-primary-default, #ffffff);--ds-auro-checkbox-label-color:var(--ds-color-text-primary-default, #2a2a2a);--ds-auro-checkbox-outline-color:transparent;--ds-auro-checkbox-group-helptext-color:var(--ds-color-text-secondary-default, #525252);--ds-auro-checkbox-group-text-color:var(--ds-color-text-primary-default, #2a2a2a)}`;

var checkLg = {"role":"img","color":"currentColor","title":"","desc":"","width":"var(--auro-size-lg, var(--ds-size-300, 1.5rem))","height":"var(--auro-size-lg, var(--ds-size-300, 1.5rem))","xmlns":"http://www.w3.org/2000/svg","xmlns_xlink":"http://www.w3.org/1999/xlink","viewBox":"0 0 24 24","path":"/icons","style":"ico_squareLarge","type":"icon","name":"check-lg","category":"interface","deprecated":true,"svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" aria-hidden=\"true\" class=\"ico_squareLarge\" data-deprecated=\"true\" role=\"img\" style=\"min-width:var(--auro-size-lg, var(--ds-size-300, 1.5rem));height:var(--auro-size-lg, var(--ds-size-300, 1.5rem));fill:currentColor\" viewBox=\"0 0 24 24\" part=\"svg\"><title/><path d=\"M5.321 12.514a.75.75 0 0 0-1.142.972l4.25 5a.75.75 0 0 0 1.141.001l10.25-12a.75.75 0 1 0-1.14-.975L9 16.844z\"/></svg>"};

// Copyright (c) Alaska Air. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.

// ---------------------------------------------------------------------

/* eslint-disable line-comment-position, no-inline-comments, no-confusing-arrow, no-nested-ternary, implicit-arrow-linebreak */

let AuroLibraryRuntimeUtils$1 = class AuroLibraryRuntimeUtils {

  /* eslint-disable jsdoc/require-param */

  /**
   * This will register a new custom element with the browser.
   * @param {String} name - The name of the custom element.
   * @param {Object} componentClass - The class to register as a custom element.
   * @returns {void}
   */
  registerComponent(name, componentClass) {
    if (!customElements.get(name)) {
      customElements.define(name, class extends componentClass {});
    }
  }

  /**
   * Finds and returns the closest HTML Element based on a selector.
   * @returns {void}
   */
  closestElement(
    selector, // selector like in .closest()
    base = this, // extra functionality to skip a parent
    __Closest = (el, found = el && el.closest(selector)) =>
      !el || el === document || el === window
        ? null // standard .closest() returns null for non-found selectors also
        : found
          ? found // found a selector INside this element
          : __Closest(el.getRootNode().host) // recursion!! break out to parent DOM
  ) {
    return __Closest(base);
  }
  /* eslint-enable jsdoc/require-param */

  /**
   * If the element passed is registered with a different tag name than what is passed in, the tag name is added as an attribute to the element.
   * @param {Object} elem - The element to check.
   * @param {String} tagName - The name of the Auro component to check for or add as an attribute.
   * @returns {void}
   */
  handleComponentTagRename(elem, tagName) {
    const tag = tagName.toLowerCase();
    const elemTag = elem.tagName.toLowerCase();

    if (elemTag !== tag) {
      elem.setAttribute(tag, true);
    }
  }

  /**
   * Validates if an element is a specific Auro component.
   * @param {Object} elem - The element to validate.
   * @param {String} tagName - The name of the Auro component to check against.
   * @returns {Boolean} - Returns true if the element is the specified Auro component.
   */
  elementMatch(elem, tagName) {
    const tag = tagName.toLowerCase();
    const elemTag = elem.tagName.toLowerCase();

    return elemTag === tag || elem.hasAttribute(tag);
  }
};

// Copyright (c) 2020 Alaska Airlines. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.


/**
 * Custom element for the purpose of allowing users to select one or more options of a limited number of choices.
 *
 * @attr {Boolean} checked - If set to true, the checkbox will be filled with a checkmark.
 * @attr {Boolean} disabled - If set to true, the checkbox will not be clickable.
 * @attr {Boolean} error - If set to true, sets an error state on the checkbox.
 * @attr {String} id - Sets the individual `id` per element.
 * @attr {String} name - Accepts any string, `DOMString` representing the value of the input.
 * @attr {String} value - Sets the element's input value.
 * @csspart checkbox - apply css to a specific checkbox.
 * @csspart checkbox-input - apply css to a specific checkbox's input.
 * @csspart checkbox-label - apply css to a specific checkbox's label.
 */

// build the component class
class AuroCheckbox extends s$2 {
  constructor() {
    super();
    this.checked = false;
    this.disabled = false;
    this.error = false;

    /**
     * @private
     */
    this.runtimeUtils = new AuroLibraryRuntimeUtils$1();
  }

  static get styles() {
    return [
      styleCss$5,
      colorCss$3,
      tokensCss$4
    ];
  }

  // function to define props used within the scope of this component
  static get properties() {
    return {
      checked: {
        type: Boolean,
        reflect: true
      },
      disabled: {
        type: Boolean,
        reflect: true
      },
      error: {
        type: Boolean,
        reflect: true
      },
      id:       { type: String },
      name:     { type: String },
      value:    { type: String }
    };
  }

  // This custom event is only for the purpose of supporting IE
  // .addEventListener('change', function() { })
  handleChange(event) {
    this.checked = event.target.checked;
    const customEvent = new CustomEvent(event.type, event);

    this.dispatchEvent(customEvent);
  }

  handleInput(event) {
    this.checked = event.target.checked;

    this.dispatchEvent(new CustomEvent('auroCheckbox-input', {
      bubbles: true,
      cancelable: false,
      composed: true,
    }));
  }

  /**
   * Function to support @focusin event.
   * @private
   * @returns {void}
   */
  handleFocusin() {
    this.dispatchEvent(new CustomEvent('auroCheckbox-focusin', {
      bubbles: true,
      cancelable: false,
      composed: true,
    }));
  }

  /**
   * Function to generate checkmark svg.
   * @private
   * @returns {void}
   */
  generateIconHtml() {
    this.dom = new DOMParser().parseFromString(checkLg.svg, 'text/html');
    this.svg = this.dom.body.firstChild;

    this.svg.classList.add('svg--cbx');

    return this.svg;
  }

  firstUpdated() {
    // Add the tag name as an attribute if it is different than the component name
    this.runtimeUtils.handleComponentTagRename(this, 'auro-checkbox');

    this.addEventListener('click', () => {
      this.handleFocusin();
    });

    this.addEventListener('focusin', () => {
      this.handleFocusin();
    });

    this.addEventListener('focusout', () => {
      this.dispatchEvent(new CustomEvent('auroCheckbox-focusout', {
        bubbles: true,
        cancelable: false,
        composed: true,
      }));
    });
  }

  // function that renders the HTML and CSS into  the scope of the component
  render() {
    const labelClasses = {
      'label': true,
      'label--cbx': true,
      'errorBorder': this.error
    };

    return x`
      <div class="cbxContainer" part="checkbox">
        <input
          class="util_displayHiddenVisually cbx--input"
          part="checkbox-input"
          @change=${this.handleChange}
          @input="${this.handleInput}"
          ?disabled="${this.disabled}"
          .checked="${this.checked}"
          id="${o$1(this.id)}"
          name="${o$1(this.name)}"
          type="checkbox"
          .value="${this.value}"
        />

        <label for="${o$1(this.id)}" class="${e(labelClasses)}" part="checkbox-label">
          ${this.checked ? this.generateIconHtml() : undefined}
          <slot></slot>
        </label>
      </div>
    `;
  }
}

// default internal definition
if (!customElements.get("auro-checkbox")) {
  customElements.define("auro-checkbox", AuroCheckbox);
}

var checkboxVersion = '3.1.0-beta.1';

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let s$1 = class s extends b{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0;}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const i=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=B(i,this.renderRoot,this.renderOptions);}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0);}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1);}render(){return T}};s$1._$litElement$=!0,s$1[("finalized")]=!0,globalThis.litElementHydrateSupport?.({LitElement:s$1});const r$3=globalThis.litElementPolyfillSupport;r$3?.({LitElement:s$1});(globalThis.litElementVersions??=[]).push("4.0.6");

/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const a=Symbol.for(""),o=t=>{if(t?.r===a)return t?._$litStatic$},l=new Map,n=t=>(r,...e)=>{const a=e.length;let s,i;const n=[],u=[];let c,$=0,f=!1;for(;$<a;){for(c=r[$];$<a&&void 0!==(i=e[$],s=o(i));)c+=s+r[++$],f=!0;$!==a&&u.push(i),n.push(c),$++;}if($===a&&n.push(r[a]),f){const t=n.join("$$lit$$");void 0===(r=l.get(t))&&(n.raw=n,l.set(t,r=n)),e=u;}return t(r,...e)},u=n(x);

// Copyright (c) Alaska Air. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.

var styleCss$4 = i$5`*,*:before,*:after{box-sizing:border-box}@media(prefers-reduced-motion: reduce){*,*:before,*:after{animation-duration:.01ms !important;animation-iteration-count:1 !important;transition-duration:.01ms !important}}*:focus-visible{outline:0}*:focus-visible{outline:0}:focus:not(:focus-visible){outline:3px solid transparent}.util_insetNone{padding:0}.util_insetXxxs{padding:.125rem}.util_insetXxxs--stretch{padding:.25rem .125rem}.util_insetXxxs--squish{padding:0 .125rem}.util_insetXxs{padding:.25rem}.util_insetXxs--stretch{padding:.375rem .25rem}.util_insetXxs--squish{padding:.125rem .25rem}.util_insetXs{padding:.5rem}.util_insetXs--stretch{padding:.75rem .5rem}.util_insetXs--squish{padding:.25rem .5rem}.util_insetSm{padding:.75rem}.util_insetSm--stretch{padding:1.125rem .75rem}.util_insetSm--squish{padding:.375rem .75rem}.util_insetMd{padding:1rem}.util_insetMd--stretch{padding:1.5rem 1rem}.util_insetMd--squish{padding:.5rem 1rem}.util_insetLg{padding:1.5rem}.util_insetLg--stretch{padding:2.25rem 1.5rem}.util_insetLg--squish{padding:.75rem 1.5rem}.util_insetXl{padding:2rem}.util_insetXl--stretch{padding:3rem 2rem}.util_insetXl--squish{padding:1rem 2rem}.util_insetXxl{padding:3rem}.util_insetXxl--stretch{padding:4.5rem 3rem}.util_insetXxl--squish{padding:1.5rem 3rem}.util_insetXxxl{padding:4rem}.util_insetXxxl--stretch{padding:6rem 4rem}.util_insetXxxl--squish{padding:2rem 4rem}:host([fluid]) .auro-button,:host([fluid=true]) .auro-button{min-width:auto;width:100%}:host([variant=flat]){display:inline-block;height:var(--ds-size-300, 1.5rem);width:var(--ds-size-300, 1.5rem)}:host([variant=flat]) .auro-button{height:100%;width:100%}::slotted(svg){vertical-align:middle}slot{pointer-events:none}.auro-button{position:relative;padding:0 var(--ds-size-300, 1.5rem);cursor:pointer;border-width:1px;border-style:solid;border-radius:var(--ds-border-radius, 0.375rem);font-family:var(--ds-font-family-default, "AS Circular", Helvetica Neue, Arial, sans-serif);font-size:var(--ds-text-body-size-default, 1rem);font-weight:var(--ds-text-body-default-weight, 500);overflow:hidden;text-overflow:ellipsis;user-select:none;white-space:nowrap;min-height:var(--ds-size-600, 3rem);max-height:var(--ds-size-600, 3rem);display:inline-flex;flex-direction:row;align-items:center;justify-content:center;gap:var(--ds-size-100, 0.5rem);margin:0;-webkit-touch-callout:none;-webkit-user-select:none}.auro-button:active{transform:scale(0.95)}.auro-button:focus-visible:not([variant=secondary]):not([variant=tertiary]):not([variant=flat]):after{display:block;content:"";height:calc(100% - 2px);width:calc(100% - 2px);position:absolute;top:1px;left:1px;border-radius:4px;border-style:solid;border-width:2px}.auro-button:focus-visible[variant=secondary]:after,.auro-button:focus-visible[variant=tertiary]:after{display:block;content:"";height:100%;width:100%;position:absolute;top:0;left:0;border-radius:var(--ds-border-radius, 0.375rem);border-style:solid;border-width:2px}.auro-button.loading{cursor:not-allowed}.auro-button.loading *:not([auro-loader]){visibility:hidden}@media screen and (min-width: 576px){.auro-button{min-width:8.75rem;width:auto}}.auro-button:disabled{cursor:not-allowed;transform:unset}.auro-button[variant=secondary]:disabled{cursor:not-allowed;transform:unset}.auro-button[variant=tertiary]:disabled{cursor:not-allowed;transform:unset}.auro-button[variant=flat]{height:unset;width:unset;min-height:unset;max-height:unset;min-width:unset;max-width:unset;border:0;border-radius:unset;gap:unset;padding:unset}.auro-button[onDark]:disabled{cursor:not-allowed;transform:unset}.auro-button[onDark][variant=secondary]:disabled{cursor:not-allowed;transform:unset}@media(hover: hover){.auro-button[onDark][variant=tertiary]:active,.auro-button[onDark][variant=tertiary]:hover{box-shadow:none}}.auro-button[onDark][variant=tertiary]:active{box-shadow:none}.auro-button[onDark][variant=tertiary]:disabled{cursor:not-allowed;transform:unset}.auro-button--slim{padding:var(--ds-size-100, 0.5rem) var(--ds-size-200, 1rem);font-size:var(--ds-text-body-size-sm, 0.875rem);min-width:unset;min-height:calc(var(--ds-size-500, 2.5rem) - var(--ds-size-50, 0.25rem));max-height:calc(var(--ds-size-500, 2.5rem) - var(--ds-size-50, 0.25rem))}.auro-button--iconOnly{padding:0 var(--ds-size-100, 0.5rem);border-radius:100px;min-width:unset;height:var(--ds-size-600, 3rem);width:var(--ds-size-500, 2.5rem)}.auro-button--iconOnly ::slotted(auro-icon){width:var(--ds-size-300, 1.5rem);height:var(--ds-size-300, 1.5rem)}.auro-button--iconOnlySlim{padding:0 var(--ds-size-50, 0.25rem);height:calc(var(--ds-size-400, 2rem) + var(--ds-size-50, 0.25rem));width:calc(var(--ds-size-300, 1.5rem) + var(--ds-size-50, 0.25rem))}.auro-button--iconOnlySlim ::slotted(auro-icon){width:calc(var(--ds-size-200, 1rem) + var(--ds-size-50, 0.25rem));height:calc(var(--ds-size-200, 1rem) + var(--ds-size-50, 0.25rem))}.auro-button--rounded{border-radius:100px;box-shadow:var(--ds-elevation-300, 0px 0px 15px rgba(0, 0, 0, 0.2));height:var(--ds-size-500, 2.5rem);min-width:unset;transition:all 300ms ease-out}.auro-button--rounded ::slotted(auro-icon){width:var(--ds-size-300, 1.5rem);height:var(--ds-size-300, 1.5rem)}:host([rounded]) .textSlot{transition:opacity 300ms ease-in;opacity:1}:host([rounded][iconOnly]) .textSlot{opacity:0}:host([rounded][iconOnly]) .textWrapper{display:none}:host([rounded][iconOnly]) .auro-button{min-width:unset;padding:unset;width:var(--ds-size-600, 3rem)}[auro-loader]{position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);pointer-events:none}`;

// Copyright (c) Alaska Air. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.

var colorsCss = i$5`auro-loader{color:var(--ds-auro-button-loader-color)}.auro-button{-webkit-tap-highlight-color:var(--ds-auro-button-tap-color);color:var(--ds-auro-button-text-color);background-color:var(--ds-auro-button-container-color);background-image:linear-gradient(var(--ds-auro-button-container-image), var(--ds-auro-button-container-image));border-color:var(--ds-auro-button-border-color)}.auro-button:not([varient=secondary]):not([varient=tertiary]):focus-visible:after{border-color:var(--ds-auro-button-border-inset-color)}.auro-button:not([ondark]):active{--ds-auro-button-container-color: var(--ds-color-container-ui-primary-active-default, #225296);--ds-auro-button-container-image: var(--ds-color-container-ui-primary-hover-default, #193d73);--ds-auro-button-border-color: var(--ds-color-container-ui-primary-active-default, #225296)}.auro-button:not([ondark])[disabled]{--ds-auro-button-container-color: var(--ds-color-container-ui-primary-disabled-default, #a0c9f1);--ds-auro-button-container-image: var(--ds-color-container-ui-primary-disabled-default, #a0c9f1);--ds-auro-button-border-color: var(--ds-color-container-ui-primary-disabled-default, #a0c9f1)}@media(hover: hover){.auro-button:not([ondark]):active:not(:disabled),.auro-button:not([ondark]):hover:not(:disabled){--ds-auro-button-container-color: var(--ds-color-container-ui-primary-hover-default, #193d73);--ds-auro-button-container-image: var(--ds-color-container-ui-primary-hover-default, #193d73);--ds-auro-button-border-color: var(--ds-color-container-ui-primary-hover-default, #193d73)}}.auro-button:not([ondark])[variant=secondary]{--ds-auro-button-container-color: var(--ds-color-container-ui-secondary-default-default, #ffffff);--ds-auro-button-container-image: var(--ds-color-container-ui-secondary-default-default, #ffffff);--ds-auro-button-border-color: var(--ds-color-border-ui-default-default, #2c67b5);--ds-auro-button-text-color: var(--ds-color-text-ui-default-default, #2c67b5)}@media(hover: hover){.auro-button:not([ondark])[variant=secondary]:active:not(:disabled),.auro-button:not([ondark])[variant=secondary]:hover:not(:disabled){--ds-auro-button-container-color: var(--ds-color-container-ui-secondary-hover-default, rgba(0, 0, 0, 0.03));--ds-auro-button-container-image: var(--ds-color-container-ui-secondary-hover-default, rgba(0, 0, 0, 0.03));--ds-auro-button-border-color: var(--ds-color-border-ui-hover-default, #193d73);--ds-auro-button-text-color: var(--ds-color-text-ui-hover-default, #193d73)}}.auro-button:not([ondark])[variant=secondary]:focus-visible{--ds-auro-button-border-inset-color: var(--ds-color-border-ui-focus-default, #2c67b5)}.auro-button:not([ondark])[variant=secondary]:active{--ds-auro-button-container-color: var(--ds-color-container-ui-secondary-active-default, #f0f7fd);--ds-auro-button-container-image: var(--ds-color-container-ui-secondary-active-default, #f0f7fd);--ds-auro-button-border-color: var(--ds-color-border-ui-active-default, #225296);--ds-auro-button-text-color: var(--ds-color-text-ui-hover-default, #193d73)}.auro-button:not([ondark])[variant=secondary]:disabled{--ds-auro-button-container-color: var(--ds-color-container-ui-secondary-disabled-default, #f7f7f7);--ds-auro-button-container-image: var(--ds-color-container-ui-secondary-disabled-default, #f7f7f7);--ds-auro-button-border-color: var(--ds-color-border-ui-disabled-default, #adadad);--ds-auro-button-text-color: var(--ds-color-text-ui-disabled-default, #adadad)}.auro-button:not([ondark])[variant=tertiary]{--ds-auro-button-container-color: var(--ds-color-container-ui-tertiary-default-default, rgba(0, 0, 0, 0.03));--ds-auro-button-container-image: var(--ds-color-container-ui-tertiary-default-default, rgba(0, 0, 0, 0.03));--ds-auro-button-border-color: transparent;--ds-auro-button-text-color: var(--ds-color-text-ui-default-default, #2c67b5)}@media(hover: hover){.auro-button:not([ondark])[variant=tertiary]:active:not(:disabled),.auro-button:not([ondark])[variant=tertiary]:hover:not(:disabled){--ds-auro-button-container-color: var(--ds-color-container-ui-tertiary-hover-default, rgba(0, 0, 0, 0.12));--ds-auro-button-container-image: var(--ds-color-container-ui-tertiary-hover-default, rgba(0, 0, 0, 0.12));--ds-auro-button-border-color: transparent;--ds-auro-button-text-color: var(--ds-color-text-ui-hover-default, #193d73)}}.auro-button:not([ondark])[variant=tertiary]:focus-visible{--ds-auro-button-border-color: var(--ds-color-border-ui-default-default, #2c67b5);--ds-auro-button-border-inset-color: var(--ds-color-border-ui-default-default, #2c67b5)}.auro-button:not([ondark])[variant=tertiary]:active{--ds-auro-button-container-color: var(--ds-color-container-ui-tertiary-active-default, rgba(0, 0, 0, 0.06));--ds-auro-button-container-image: var(--ds-color-container-ui-tertiary-active-default, rgba(0, 0, 0, 0.06));--ds-auro-button-border-color: transparent;--ds-auro-button-text-color: var(--ds-color-text-ui-hover-default, #193d73)}.auro-button:not([ondark])[variant=tertiary]:disabled{--ds-auro-button-container-color: var(--ds-color-container-ui-tertiary-disabled-default, rgba(0, 0, 0, 0.03));--ds-auro-button-container-image: var(--ds-color-container-ui-tertiary-disabled-default, rgba(0, 0, 0, 0.03));--ds-auro-button-border-color: transparent;--ds-auro-button-text-color: var(--ds-color-text-ui-disabled-default, #adadad)}.auro-button:not([ondark])[variant=flat]{color:var(--ds-color-icon-ui-secondary-default-default);background-color:transparent;background-image:none;border-color:transparent}@media(hover: hover){.auro-button:not([ondark])[variant=flat]:active:not(:disabled),.auro-button:not([ondark])[variant=flat]:hover:not(:disabled){color:var(--ds-color-icon-ui-secondary-hover-default);background-color:transparent;background-image:none;border-color:transparent}}.auro-button:not([ondark])[variant=flat]:disabled{color:var(--ds-color-icon-ui-secondary-disabled-default);background-color:transparent;background-image:none;border-color:transparent}.auro-button[ondark]{--ds-auro-button-container-color: var(--ds-color-container-ui-primary-default-inverse, #56bbde);--ds-auro-button-container-image: var(--ds-color-container-ui-primary-default-inverse, #56bbde);--ds-auro-button-border-color: var(--ds-color-container-ui-primary-default-inverse, #56bbde);--ds-auro-button-text-color: var(--ds-color-text-primary-inverse, #ffffff);--ds-auro-button-loader-color: var(--ds-color-text-primary-inverse, #ffffff)}@media(hover: hover){.auro-button[ondark]:active:not(:disabled),.auro-button[ondark]:hover:not(:disabled){--ds-auro-button-container-color: var(--ds-color-container-ui-primary-hover-inverse, #a8e9f7);--ds-auro-button-container-image: var(--ds-color-container-ui-primary-hover-inverse, #a8e9f7);--ds-auro-button-border-color: var(--ds-color-container-ui-primary-hover-inverse, #a8e9f7)}}.auro-button[ondark]:active{--ds-auro-button-container-color: var(--ds-color-container-ui-primary-hover-inverse, #a8e9f7);--ds-auro-button-container-image: var(--ds-color-container-ui-primary-hover-inverse, #a8e9f7);--ds-auro-button-border-color: var(--ds-color-container-ui-primary-hover-inverse, #a8e9f7)}.auro-button[ondark][disabled]{--ds-auro-button-container-color: var(--ds-color-container-ui-primary-disabled-inverse, #275b72);--ds-auro-button-container-image: var(--ds-color-container-ui-primary-disabled-inverse, #275b72);--ds-auro-button-border-color: var(--ds-color-container-ui-primary-disabled-inverse, #275b72)}.auro-button[ondark][variant=secondary]{--ds-auro-button-container-color: var(--ds-color-container-ui-secondary-default-inverse, rgba(255, 255, 255, 0.03));--ds-auro-button-container-image: var(--ds-color-container-ui-secondary-default-inverse, rgba(255, 255, 255, 0.03));--ds-auro-button-border-color: var(--ds-color-border-ui-default-inverse, #56bbde);--ds-auro-button-text-color: var(--ds-color-text-ui-default-inverse, #56bbde)}@media(hover: hover){.auro-button[ondark][variant=secondary]:active,.auro-button[ondark][variant=secondary]:hover{--ds-auro-button-container-color: var(--ds-color-container-ui-secondary-hover-inverse, rgba(255, 255, 255, 0.12));--ds-auro-button-container-image: var(--ds-color-container-ui-secondary-hover-inverse, rgba(255, 255, 255, 0.12));--ds-auro-button-border-color: var(--ds-color-border-ui-hover-inverse, #a8e9f7);--ds-auro-button-text-color: var(--ds-color-text-ui-hover-inverse, #a8e9f7)}}.auro-button[ondark][variant=secondary]:focus-visible{--ds-auro-button-border-inset-color: var(--ds-color-border-ui-focus-inverse, #56bbde)}.auro-button[ondark][variant=secondary]:active{--ds-auro-button-container-color: var(--ds-color-container-ui-secondary-active-inverse, rgba(255, 255, 255, 0.06));--ds-auro-button-container-image: var(--ds-color-container-ui-secondary-active-inverse, rgba(255, 255, 255, 0.06));--ds-auro-button-border-color: var(--ds-color-border-ui-active-inverse, #6ad5ef);--ds-auro-button-text-color: var(--ds-color-text-ui-hover-inverse, #a8e9f7)}.auro-button[ondark][variant=secondary]:disabled{--ds-auro-button-container-color: var(--ds-color-container-ui-secondary-disabled-inverse, rgba(255, 255, 255, 0.12));--ds-auro-button-container-image: var(--ds-color-container-ui-secondary-disabled-inverse, rgba(255, 255, 255, 0.12));--ds-auro-button-border-color: var(--ds-color-border-ui-disabled-inverse, #7e7e7e);--ds-auro-button-text-color: var(--ds-color-text-ui-disabled-inverse, #7e7e7e)}.auro-button[ondark][variant=tertiary]{--ds-auro-button-container-color: var(--ds-color-container-ui-tertiary-default-inverse, rgba(255, 255, 255, 0.12));--ds-auro-button-container-image: var(--ds-color-container-ui-tertiary-default-inverse, rgba(255, 255, 255, 0.12));--ds-auro-button-border-color: transparent;--ds-auro-button-text-color: var(--ds-color-text-ui-default-inverse, #56bbde)}@media(hover: hover){.auro-button[ondark][variant=tertiary]:active:not(:disabled),.auro-button[ondark][variant=tertiary]:hover:not(:disabled){--ds-auro-button-container-color: var(--ds-color-container-ui-tertiary-hover-inverse, rgba(255, 255, 255, 0.03));--ds-auro-button-container-image: var(--ds-color-container-ui-tertiary-hover-inverse, rgba(255, 255, 255, 0.03));--ds-auro-button-border-color: transparent;--ds-auro-button-text-color: var(--ds-color-text-ui-hover-inverse, #a8e9f7)}}.auro-button[ondark][variant=tertiary]:focus-visible{--ds-auro-button-border-color: var(--ds-color-border-ui-default-inverse, #56bbde);--ds-auro-button-border-inset-color: var(--ds-color-border-ui-default-inverse, #56bbde)}.auro-button[ondark][variant=tertiary]:active{--ds-auro-button-container-color: var(--ds-color-container-ui-tertiary-active-inverse, rgba(255, 255, 255, 0.06));--ds-auro-button-container-image: var(--ds-color-container-ui-tertiary-active-inverse, rgba(255, 255, 255, 0.06));--ds-auro-button-border-color: transparent;--ds-auro-button-text-color: var(--ds-color-text-ui-hover-inverse, #a8e9f7)}.auro-button[ondark][variant=tertiary]:disabled{--ds-auro-button-container-color: var(--ds-color-container-ui-tertiary-disabled-inverse, rgba(255, 255, 255, 0.03));--ds-auro-button-container-image: var(--ds-color-container-ui-tertiary-disabled-inverse, rgba(255, 255, 255, 0.03));--ds-auro-button-border-color: transparent;--ds-auro-button-text-color: var(--ds-color-text-ui-disabled-inverse, #7e7e7e)}.auro-button[ondark][variant=flat]{color:var(--ds-color-icon-ui-secondary-default-inverse);background-color:transparent;background-image:none;border-color:transparent}@media(hover: hover){.auro-button[ondark][variant=flat]:active:not(:disabled),.auro-button[ondark][variant=flat]:hover:not(:disabled){color:var(--ds-color-icon-ui-secondary-hover-inverse);background-color:transparent;background-image:none;border-color:transparent}}.auro-button[ondark][variant=flat]:disabled{color:var(--ds-color-icon-ui-disabled-default);background-color:transparent;background-image:none;border-color:transparent}`;

// Copyright (c) Alaska Air. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.

var tokensCss$3 = i$5`:host{--ds-auro-button-border-color: var(--ds-color-container-ui-primary-active-default, $ds-color-container-ui-primary-active-default);--ds-auro-button-container-color: var(--ds-color-container-ui-primary-active-default, $ds-color-container-ui-primary-active-default);--ds-auro-button-container-image: var(--ds-color-container-ui-primary-active-default, $ds-color-container-ui-primary-active-default);--ds-auro-button-text-color: var(--ds-color-text-primary-inverse, $ds-color-text-primary-inverse);--ds-auro-button-border-inset-color: var(--ds-color-border-emphasis-inverse, $ds-color-border-emphasis-inverse);--ds-auro-button-loader-color: var(--ds-color-background-darkest, $ds-color-background-darkest);--ds-auro-button-tap-color: transparent}`;

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class s extends b{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0;}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const i=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=B(i,this.renderRoot,this.renderOptions);}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0);}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1);}render(){return T}}s._$litElement$=!0,s[("finalized")]=!0,globalThis.litElementHydrateSupport?.({LitElement:s});const r$2=globalThis.litElementPolyfillSupport;r$2?.({LitElement:s});(globalThis.litElementVersions??=[]).push("4.0.6");

var styleCss$3 = i$5`*,*:before,*:after{box-sizing:border-box}@media(prefers-reduced-motion: reduce){*,*:before,*:after{animation-duration:.01ms !important;animation-iteration-count:1 !important;transition-duration:.01ms !important}}*:focus-visible{outline:0}*:focus-visible{outline:0}:focus:not(:focus-visible){outline:3px solid transparent}:host,:host>span{position:relative}:host{width:2rem;height:2rem;display:inline-block;font-size:0}:host>span{position:absolute;display:inline-block;float:none;top:0;left:0;width:2rem;height:2rem;border-radius:100%;border-style:solid;border-width:0}:host([xs]),:host([xs])>span{width:1.2rem;height:1.2rem}:host([sm]),:host([sm])>span{width:3rem;height:3rem}:host([md]),:host([md])>span{width:5rem;height:5rem}:host([lg]),:host([lg])>span{width:8rem;height:8rem}:host{--margin:0.375rem;--margin-xs:0.2rem;--margin-sm:0.5rem;--margin-md:0.75rem;--margin-lg:1rem}:host([pulse]),:host([pulse])>span{position:relative}:host([pulse]){width:calc(3rem + var(--margin)*6);height:1.5rem}:host([pulse])>span{width:1rem;height:1rem;margin:var(--margin);animation:pulse 1.5s ease infinite}:host([pulse][xs]){width:calc(2.55rem + var(--margin-xs)*6);height:1.55rem}:host([pulse][xs])>span{margin:var(--margin-xs);width:.65rem;height:.65rem}:host([pulse][sm]){width:calc(6rem + var(--margin-sm)*6);height:2.5rem}:host([pulse][sm])>span{margin:var(--margin-sm);width:2rem;height:2rem}:host([pulse][md]){width:calc(9rem + var(--margin-md)*6);height:3.5rem}:host([pulse][md])>span{margin:var(--margin-md);width:3rem;height:3rem}:host([pulse][lg]){width:calc(15rem + var(--margin-lg)*6);height:5.5rem}:host([pulse][lg])>span{margin:var(--margin-lg);width:5rem;height:5rem}:host([pulse])>span:nth-child(1){animation-delay:-400ms}:host([pulse])>span:nth-child(2){animation-delay:-200ms}:host([pulse])>span:nth-child(3){animation-delay:0ms}@keyframes pulse{0%,100%{opacity:.1;transform:scale(0.9)}50%{opacity:1;transform:scale(1.1)}}:host([orbit]),:host([orbit])>span{opacity:1}:host([orbit])>span{border-width:5px}:host([orbit])>span:nth-child(2){animation:orbit 2s linear infinite}:host([orbit][sm])>span{border-width:8px}:host([orbit][md])>span{border-width:13px}:host([orbit][lg])>span{border-width:21px}@keyframes orbit{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}:host([ringworm])>svg{animation:rotate 2s linear infinite;height:100%;width:100%;stroke:currentcolor;stroke-width:8}:host([ringworm]) .path{stroke-dashoffset:0;animation:ringworm 1.5s ease-in-out infinite;stroke-linecap:round}@keyframes rotate{100%{transform:rotate(360deg)}}@keyframes ringworm{0%{stroke-dasharray:1,200;stroke-dashoffset:0}50%{stroke-dasharray:89,200;stroke-dashoffset:-35px}100%{stroke-dasharray:89,200;stroke-dashoffset:-124px}}:host([laser]){position:static;width:100%;display:block;height:0;overflow:hidden;font-size:unset}:host([laser])>span{position:fixed;width:100%;height:.25rem;border-radius:0;z-index:100}:host([laser])>span:nth-child(1){border-color:currentcolor;opacity:.25}:host([laser])>span:nth-child(2){border-color:currentcolor;animation:laser 2s linear infinite;opacity:1;width:50%}:host([laser][sm])>span:nth-child(2){width:20%}:host([laser][md])>span:nth-child(2){width:30%}:host([laser][lg])>span:nth-child(2){width:50%;animation-duration:1.5s}:host([laser][xl])>span:nth-child(2){width:80%;animation-duration:1.5s}@keyframes laser{0%{left:-100%}100%{left:110%}}:host>.no-animation{display:none}@media(prefers-reduced-motion: reduce){:host{display:flex;align-items:center;justify-content:center;font-size:1rem}:host>span{opacity:1}:host>.loader{display:none}:host>.no-animation{display:block}}`;

var colorCss$2 = i$5`:host{color:var(--ds-auro-loader-color)}:host>span{background-color:var(--ds-auro-loader-background-color);border-color:var(--ds-auro-loader-border-color)}:host([onlight]){--ds-auro-loader-color:var(--ds-color-ui-default-default, #0074c8)}:host([ondark]){--ds-auro-loader-color:var(--ds-color-brand-breeze-300, #00cff0)}:host([white]){--ds-auro-loader-color:var(--ds-color-container-ui-secondary-default-default, #ffffff)}:host([orbit])>span{--ds-auro-loader-background-color:transparent}:host([orbit])>span:nth-child(1){--ds-auro-loader-border-color:currentcolor;opacity:.25}:host([orbit])>span:nth-child(2){--ds-auro-loader-border-color:currentcolor;border-right-color:transparent;border-bottom-color:transparent;border-left-color:transparent}`;

var tokensCss$2 = i$5`:host{--ds-auro-loader-background-color:currentcolor;--ds-auro-loader-border-color:currentcolor;--ds-auro-loader-color:currentcolor}`;

// Copyright (c) 2020 Alaska Airlines. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.


// See https://git.io/JJ6SJ for "How to document your components using JSDoc"
/**
 * The auro-loader element is an easy to use animated loader component.
 *
 * @attr {Boolean} pulse - sets loader type
 * @attr {Boolean} ringworm - sets loader type
 * @attr {Boolean} laser - sets loader type
 * @attr {Boolean} orbit - sets loader type
 * @attr {Boolean} white - sets color of loader to white
 * @attr {Boolean} ondark - sets color of loader to auro-color-ui-default-on-dark
 * @attr {Boolean} onlight - sets color of loader to auro-color-ui-default-on-light
 * @attr {Boolean} xs - sets size to extra small
 * @attr {Boolean} sm - sets size to small
 * @attr {Boolean} md - sets size to medium
 * @attr {Boolean} lg - sets size to large
 * @csspart element - apply style to adjust speed of animation
 */

// build the component class
class AuroLoader extends s {
  constructor() {
    super();

    /**
     * @private
     */
    this.keys = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

    /**
     * @private
     */
    this.mdCount = 3;

    /**
     * @private
     */
    this.smCount = 2;

    this.orbit = false;
    this.ringworm = false;
    this.laser = false;
    this.pulse = false;
  }

  // function to define props used within the scope of this component
  static get properties() {
    return {
      pulse: {
        type: Boolean,
        reflect: true
      },
      orbit: {
        type: Boolean,
        reflect: true
      },
      ringworm: {
        type: Boolean,
        reflect: true
      },
      laser: {
        type: Boolean,
        reflect: true
      }
    };
  }

  static get styles() {
    return [
      i$5`${styleCss$3}`,
      i$5`${colorCss$2}`,
      i$5`${tokensCss$2}`
    ];
  }

  /**
   * If component is registered as a custom name,
   * this function will add an attribute to the element
   * with the default name. This is so that other parent
   * components can still this the element.
   * @private
   * @param {string} name - The default tag name.
   * @param {HTMLElement} elem - The element to add the attribute to.
   * @returns {void}
   */
  handleCustomTagName(name, elem) {
    if (name.toLowerCase() !== elem.tagName.toLowerCase()) {
      elem.setAttribute(name, true);
    }
  }

  connectedCallback() {
    super.connectedCallback();
    this.handleCustomTagName('auro-loader', this);
  }

  /**
   * @private
   * @returns {Array} Numbered array for template map.
   */
  defineTemplate() {
    let nodes = Array.from(Array(this.mdCount).keys());

    if (this.orbit || this.laser) {
      nodes = Array.from(Array(this.smCount).keys());
    } else if (this.ringworm) {
      nodes = Array.from(Array(0).keys());
    }

    return nodes;
  }

  // When using auroElement, use the following attribute and function when hiding content from screen readers.
  // aria-hidden="${this.hideAudible(this.hiddenAudible)}"

  // function that renders the HTML and CSS into  the scope of the component
  render() {
    return x`
      ${this.defineTemplate().map((idx) => x`
        <span part="element" class="loader node-${idx}"></span>
      `)}

      <div class="no-animation">Loading...</div>

      ${this.ringworm ? x`
        <svg  part="element" class="circular" viewBox="25 25 50 50">
          <circle class="path" cx="50" cy="50" r="20" fill="none"/>
        </svg>`
        : ``
      }
    `;
  }
}

// default internal definition
if (!customElements.get("auro-loader")) {
  customElements.define("auro-loader", AuroLoader);
}

var loaderVersion = '2.1.0-beta.2';

// Copyright (c) Alaska Air. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.


/**
 * @attr {Boolean} autofocus - This Boolean attribute lets you specify that the button should have input focus when the page loads, unless overridden by the user
 * @attr {Boolean} disabled - If set to true button will become disabled and not allow for interactions
 * @attr {Boolean} iconOnly - If set to true, the button will contain an icon with no additional content
 * @attr {Boolean} loading - If set to true button text will be replaced with `auro-loader` and become disabled
 * @attr {Boolean} onDark - Set value for on-dark version of auro-button
 * @attr {Boolean} rounded - If set to true, the button will have a rounded shape
 * @attr {Boolean} slim - Set value for slim version of auro-button
 * @attr {Boolean} fluid - Alters the shape of the button to be full width of its parent container
 * @attr {String} arialabel - Populates the `aria-label` attribute that is used to define a string that labels the current element. Use it in cases where a text label is not visible on the screen. If there is visible text labeling the element, use `aria-labelledby` instead.
 * @attr {String} arialabelledby - Populates the `aria-labelledby` attribute that establishes relationships between objects and their label(s), and its value should be one or more element IDs, which refer to elements that have the text needed for labeling. List multiple element IDs in a space delimited fashion.
 * @attr {String} id - Set the unique ID of an element.
 * @attr {String} title - Sets title attribute. The information is most often shown as a tooltip text when the mouse moves over the element.
 * @attr {String} type - The type of the button. Possible values are: `submit`, `reset`, `button`
 * @attr {String} value - Defines the value associated with the button which is submitted with the form data.
 * @attr {String} variant - Sets button variant option. Possible values are: `secondary`, `tertiary`
 * @attr {Boolean} secondary - DEPRECATED
 * @attr {Boolean} tertiary - DEPRECATED
 * @prop {Boolean} ready - When false the component API should not be called.
 * @event auroButton-ready - Notifies that the component has finished initializing.
 * @slot - Default slot for the text of the button.
 * @slot icon - Slot to provide auro-icon for the button.
 * @csspart button - Apply CSS to HTML5 button.
 * @csspart loader - Apply CSS to auro-loader.
 * @csspart text - Apply CSS to text slot.
 * @csspart icon - Apply CSS to icon slot.
 */

/* eslint-disable lit/no-invalid-html, lit/binding-positions */

class AuroButton extends s$1 {

  constructor() {
    super();
    this.autofocus = false;
    this.disabled = false;
    this.iconOnly = false;
    this.loading = false;
    this.onDark = false;
    this.ready = false;
    this.secondary = false;
    this.tertiary = false;
    this.rounded = false;
    this.slim = false;
    this.fluid = false;

    /**
     * Generate unique names for dependency components.
     */
    const versioning = new AuroDependencyVersioning();

    /**
     * @private
     */
    this.loaderTag = versioning.generateTag('auro-loader', loaderVersion, AuroLoader);
  }

  static get styles() {
    return [
      tokensCss$3,
      styleCss$4,
      colorsCss
    ];
  }

  static get properties() {
    return {
      autofocus:        {
        type: Boolean,
        reflect: true
      },
      disabled:         {
        type: Boolean,
        reflect: true
      },
      secondary:         {
        type: Boolean,
        reflect: true
      },
      tertiary:         {
        type: Boolean,
        reflect: true
      },
      fluid:         {
        type: Boolean,
        reflect: true
      },
      iconOnly: {
        type: Boolean,
        reflect: true
      },
      loading:          {
        type: Boolean,
        reflect: true
      },
      onDark:           {
        type: Boolean,
        reflect: true
      },
      rounded: {
        type: Boolean,
        reflect: true
      },
      slim: {
        type: Boolean,
        reflect: true
      },
      arialabel:        {
        type: String,
        reflect: true
      },
      arialabelledby:   {
        type: String,
        reflect: true
      },
      title:            {
        type: String,
        reflect: true
      },
      type:             {
        type: String,
        reflect: true
      },
      value:            {
        type: String,
        reflect: true
      },
      variant:          {
        type: String,
        reflect: true
      },
      ready: { type: Boolean },
    };
  }

  /**
   * Internal method to apply focus to the HTML5 button.
   * @private
   * @returns {void}
   */
  focus() {
    this.renderRoot.querySelector('button').focus();
  }

  /**
   *  Marks the component as ready and sends event.
   * @private
   * @returns {void}
   */
  notifyReady() {
    this.ready = true;

    this.dispatchEvent(new CustomEvent('auroButton-ready', {
      bubbles: true,
      cancelable: false,
      composed: true,
    }));
  }

  updated() {
    // support the old `secondary` and `tertiary` attributes` that are deprecated
    if (this.secondary) {
      this.setAttribute('variant', 'secondary');
    }

    if (this.tertiary) {
      this.setAttribute('variant', 'tertiary');
    }
  }

  firstUpdated() {
    this.notifyReady();
  }

  render() {
    const classes = {
      'util_insetLg--squish': true,
      'auro-button': true,
      'auro-button--rounded': this.rounded,
      'auro-button--slim': this.slim,
      'auro-button--iconOnly': this.iconOnly,
      'auro-button--iconOnlySlim': this.iconOnly && this.slim,
      'loading': this.loading
    };

    return u`
      <button
        part="button"
        aria-label="${o$1(this.arialabel ? this.arialabel : undefined)}"
        aria-labelledby="${o$1(this.arialabelledby ? this.arialabelledby : undefined)}"
        ?autofocus="${this.autofocus}"
        class="${e(classes)}"
        ?disabled="${this.disabled || this.loading}"
        ?onDark="${this.onDark}"
        title="${o$1(this.title ? this.title : undefined)}"
        name="${o$1(this.name ? this.name : undefined)}"
        type="${o$1(this.type ? this.type : undefined)}"
        variant="${o$1(this.variant ? this.variant : undefined)}"
        .value="${o$1(this.value ? this.value : undefined)}"
        @click="${() => {}}"
      >
        ${o$1(this.loading ? u`<${this.loaderTag} pulse part="loader"></${this.loaderTag}>` : undefined)}

        <span class="contentWrapper">
          <span class="textSlot" part="text">
            ${this.iconOnly ? undefined : u`<slot></slot>`}
          </span>

          <span part="icon">
            <slot name="icon"></slot>
          </span>
        </span>
      </button>
    `;
  }
}

// default internal definition
if (!customElements.get("auro-button")) {
  customElements.define("auro-button", AuroButton);
}

var buttonVersion = '7.3.0-beta.6';

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let r$1 = class r extends b{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0;}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const s=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=B(s,this.renderRoot,this.renderOptions);}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0);}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1);}render(){return T}};r$1._$litElement$=!0,r$1["finalized"]=!0,globalThis.litElementHydrateSupport?.({LitElement:r$1});const i$1=globalThis.litElementPolyfillSupport;i$1?.({LitElement:r$1});(globalThis.litElementVersions??=[]).push("4.1.1");

var official200 = {"hidden":"true","category":"restricted","role":"img","color":"currentColor","desc":"Logo image for Alaska Airlines","width":"100%","height":"auto","xmlns":"http://www.w3.org/2000/svg","xmlns_xlink":"http://www.w3.org/1999/xlink","path":"/icons/restricted","style":"","type":"restricted","name":"AS-tagline-200","title":"Alaska Airlines","viewBox":"0 0 83 35","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" aria-labelledby=\"AS-tagline-200__title AS-tagline-200__desc\" role=\"img\" style=\"min-width:100%;height:auto;fill:currentColor\" viewBox=\"0 0 83 35\" part=\"svg\"><title id=\"AS-tagline-200__title\">Alaska Airlines</title><desc id=\"AS-tagline-200__desc\">Logo image for Alaska Airlines</desc><path d=\"M10.2 33.4H7.6l-.5 1.5H5.8l2.4-6.4h1.4l2.4 6.4h-1.3zM8 32.2h1.8l-.9-2.4zM16.5 34.8v-6.4h1.3v6.4zM25 32.4h-.6v2.5h-1.2v-6.4h2.5c1.2 0 2 .9 2 2 0 .9-.5 1.6-1.4 1.8l1.4 2.6h-1.4zm.3-1.1c.6 0 1-.4 1-.9s-.4-.9-1-.9h-1v1.8zM32.6 34.8v-6.4h1.2v5.2h2.8v1.2zM41.6 34.8v-6.4h1.3v6.4zM52.3 34.8l-2.9-4.5v4.5h-1.2v-6.4h1.5l2.6 4.2v-4.2h1.2v6.4zM59 34.8v-6.4h4v1.2h-2.7v1.5h2.5v1.1h-2.5v1.5H63v1.2h-4zM71.3 30.3c-.1-.4-.4-.9-1.2-.9-.6 0-1 .4-1 .8s.2.6.7.7l.9.2c1.2.2 1.8 1 1.8 1.9 0 1-.8 2-2.3 2-1.7 0-2.4-1.1-2.5-2l1.1-.3c.1.6.5 1.2 1.4 1.2.7 0 1-.3 1-.8 0-.4-.3-.7-.8-.8l-.9-.2c-1-.2-1.7-.9-1.7-1.8 0-1.1 1-2 2.2-2 1.5 0 2.1.9 2.3 1.7zM39.7 1l-9.2 15.5c-1 1.6-1.5 3.2-1.6 4.8h-3.6c.2-2 1-3.8 2.6-6.5L34.4 4c1.2-2.3 2.5-3 4.8-3zM39 17.3c-.7.6-2 1.6-3.1 1.6-.8 0-.8-.7-.3-1.7 2-3.7 4-5.7 6.5-5.7h.5zm3.4-8c-4.7 0-7.6 2.7-10.1 8.7-.6 1.5-1 3.4 1.2 3.3 1.2 0 3.3-.7 4.8-1.7-.1.5-.2 1.2-.1 1.6h3.3c.1-1.3.6-2.9 1.7-4.8l4.1-6.9c-1.7-.1-3.3-.2-4.9-.2M72.8 17.3c-.7.6-2 1.6-3.1 1.6-.8 0-.8-.7-.3-1.7 2-3.7 4-5.7 6.5-5.7h.5zm3.4-8c-4.7 0-7.6 2.7-10.1 8.7-.6 1.5-1 3.4 1.2 3.3 1.2 0 3.3-.7 4.8-1.7-.1.5-.2 1.2-.1 1.6h3.3c.1-1.3.6-2.9 1.7-4.8l4-6.8q-2.4-.3-4.8-.3\"/><path d=\"M65.5 24.6h-1.1c-1.4 0-2.6-.9-3-2.3l-1.6-6.2-3.1 5.1h-3.5L63 4.6c1.3-2.1 2.6-2.9 4.9-2.9h.4l-6.5 11 4.9-3.4h3.9L62.4 15zM33.3 0c-3.3 0-5 .9-8.2 3.2l-11 7.9H7c-2 0-3.7.1-4.9 1.3L.3 14.1s5.3-.2 10.2-.4L0 21.2h4.5l10.7-7.7c2.1-.1 3.5-.1 3.5-.1 2.5-.1 3.9-2.3 3.9-2.3h-4.1l8.7-6.3-6.4 10.4c-1.4 2.4-2 4.1-2.3 5.9h3.7c.1-1.6.7-3.2 1.6-4.8l8.8-14.7c.6-1 1.1-1.8 1.1-1.8zM50.7 12.7c0 .3.1.5.7.9l1 .7c1.1.7 1.5 1.8 1.4 2.7-.4 2.5-2.2 4.4-6 4.4-1.7 0-2.4-.1-4.4-.4l1.5-2.5c1.4.2 2.2.4 3.2.4 1.4 0 2-.7 2.1-1.2 0-.3-.1-.7-.8-1.2l-.8-.6c-1.3-.9-1.6-1.6-1.4-2.8.3-2.2 2.8-3.8 6.3-3.8 1.1 0 2.3.1 3.6.2l-1.4 2.4c-.9-.1-2.3-.1-3.2-.1-1 0-1.7.4-1.8.9M80.7 17.7c1 0 1.8.8 1.8 1.9 0 1-.8 1.9-1.8 1.9s-1.8-.8-1.8-1.9c0-1 .8-1.9 1.8-1.9m0 3.4c.8 0 1.4-.6 1.4-1.5 0-.8-.6-1.5-1.4-1.5s-1.4.6-1.4 1.5c0 .8.6 1.5 1.4 1.5m-.2-.5h-.4v-2h.7c.4 0 .7.3.7.6s-.2.5-.4.6l.5.8H81l-.4-.8h-.2v.8zm.2-1.1c.2 0 .4-.1.4-.3s-.1-.3-.4-.3h-.3v.6z\"/></svg>"};

var as200 = {"hidden":"true","category":"restricted","role":"img","color":"currentColor","desc":"Logo image for Alaska Airlines","width":"100%","height":"auto","xmlns":"http://www.w3.org/2000/svg","xmlns_xlink":"http://www.w3.org/1999/xlink","path":"/icons/restricted","style":"","type":"restricted","name":"AS-200","title":"Alaska Airlines","viewBox":"0 0 83 26","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" aria-labelledby=\"AS-200__title AS-200__desc\" role=\"img\" style=\"min-width:100%;height:auto;fill:currentColor\" viewBox=\"0 0 83 26\" part=\"svg\"><title id=\"AS-200__title\">Alaska Airlines</title><desc id=\"AS-200__desc\">Logo image for Alaska Airlines</desc><path d=\"M39.72 1.52 30.44 17a11.3 11.3 0 0 0-1.6 4.8h-3.62a16.5 16.5 0 0 1 2.6-6.51l6.47-10.84c1.29-2.15 2.58-2.93 4.92-2.93zM39.01 17.81a5.7 5.7 0 0 1-3.1 1.6c-.76 0-.79-.74-.27-1.73 1.95-3.74 4-5.72 6.53-5.71h.46zm3.43-7.94c-4.69 0-7.57 2.73-10.11 8.71-.64 1.5-1 3.36 1.17 3.34a10 10 0 0 0 4.75-1.7 5.2 5.2 0 0 0-.14 1.58h3.29c.223-1.697.792-3.33 1.67-4.8l4.11-6.86a47 47 0 0 0-4.74-.27M72.82 17.81a5.66 5.66 0 0 1-3.09 1.6c-.76 0-.79-.74-.28-1.73 1.99-3.74 3.99-5.68 6.54-5.68h.45zm3.42-7.94c-4.69 0-7.57 2.73-10.12 8.71-.63 1.5-1 3.36 1.17 3.34a10 10 0 0 0 4.75-1.7 5.2 5.2 0 0 0-.13 1.58h3.29c.22-1.7.796-3.336 1.69-4.8L81 10.14a47 47 0 0 0-4.76-.27\"/><path d=\"M65.55 25.11h-1.11a3.09 3.09 0 0 1-3-2.28l-1.6-6.17-3.05 5.14h-3.51l9.79-16.56c1.26-2.15 2.57-2.93 4.91-2.93h.36l-6.5 11 4.87-3.36h3.92l-8.19 5.64zM33.26.56c-3.3 0-5 .87-8.24 3.21l-11 7.9h-7c-2 0-3.66.08-4.94 1.29L.3 14.63l10.19-.39L0 21.8h4.53l10.74-7.74c2.08-.08 3.52-.14 3.53-.13a5.15 5.15 0 0 0 3.89-2.26h-4.11l8.67-6.26-6.44 10.44a15.4 15.4 0 0 0-2.27 5.95h3.72A11.34 11.34 0 0 1 23.9 17l8.77-14.61c.61-1 1.15-1.83 1.15-1.83zM50.73 13.23c0 .31.08.5.71.91l1 .66a2.85 2.85 0 0 1 1.4 2.67c-.37 2.46-2.17 4.44-6 4.44a22 22 0 0 1-4.4-.39L44.89 19c1.06.223 2.138.347 3.22.37 1.44 0 2-.66 2.1-1.19 0-.32-.11-.68-.79-1.15l-.8-.57c-1.28-.91-1.61-1.63-1.44-2.76.32-2.18 2.83-3.84 6.32-3.84a34 34 0 0 1 3.6.21l-1.4 2.37a31 31 0 0 0-3.24-.1c-1.02.04-1.66.39-1.73.89M80.69 18.27a1.86 1.86 0 1 1 .06 3.721 1.86 1.86 0 0 1-.06-3.72m0 3.35a1.49 1.49 0 1 0-1.44-1.49 1.45 1.45 0 0 0 1.44 1.49m-.25-.49h-.38v-2h.7a.65.65 0 0 1 .68.64.63.63 0 0 1-.44.6l.45.79h-.44l-.42-.76h-.15zm.28-1.13c.23 0 .35-.11.35-.3s-.12-.3-.35-.3h-.28v.6z\"/></svg>"};

var logoOneworld = {"category":"logos","role":"img","color":"currentColor","title":"Airplane tail image for Oneworld Alliance","desc":"","width":"100%","height":"auto","xmlns":"http://www.w3.org/2000/svg","xmlns_xlink":"http://www.w3.org/1999/xlink","path":"/icons/logos","style":"","type":"logo","name":"oneworld","viewBox":"0 0 24 24","esm":true,"svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" aria-hidden=\"true\" role=\"img\" style=\"min-width:100%;height:auto;fill:currentColor\" viewBox=\"0 0 24 24\" part=\"svg\"><title id=\"oneworld__title\">Airplane tail image for Oneworld Alliance</title><defs><radialGradient id=\"oneworld_svg__a\" cx=\"23.632%\" cy=\"17.875%\" r=\"162.725%\"><stop offset=\"0\" stop-color=\"#fff\" stop-opacity=\".5\"/><stop offset=\".283\" stop-color=\"#adabd3\" stop-opacity=\".595\"/><stop offset=\".58\" stop-color=\"#5c58a8\" stop-opacity=\".695\"/><stop offset=\".791\" stop-color=\"#2a248c\" stop-opacity=\".766\"/><stop offset=\"1\" stop-color=\"#161082\" stop-opacity=\".8\"/></radialGradient><radialGradient id=\"oneworld_svg__b\" cx=\"20.432%\" cy=\"15.711%\" r=\"77.841%\" gradientTransform=\"matrix(.61524 .78834 -1.01126 .78922 .237 -.128)\"><stop offset=\"0\" stop-color=\"#fff\" stop-opacity=\".9\"/><stop offset=\".283\" stop-color=\"#adabd3\" stop-opacity=\".615\"/><stop offset=\".58\" stop-color=\"#5c58a8\" stop-opacity=\".316\"/><stop offset=\".791\" stop-color=\"#2a248c\" stop-opacity=\".104\"/><stop offset=\"1\" stop-color=\"#161082\" stop-opacity=\"0\"/></radialGradient></defs><g fill=\"none\" fill-rule=\"evenodd\" transform=\"translate(1.5 1.5)\"><path fill=\"#fff\" fill-rule=\"nonzero\" d=\"M0 10.483c0 5.78 4.7 10.482 10.483 10.482 5.781 0 10.482-4.7 10.482-10.482C20.965 4.7 16.262 0 10.483 0 4.703 0 0 4.7 0 10.483m1.07 0c0-5.192 4.222-9.414 9.413-9.414s9.412 4.223 9.412 9.414-4.222 9.412-9.412 9.412-9.414-4.222-9.414-9.412z\"/><circle cx=\"10.483\" cy=\"10.483\" r=\"9.902\" fill=\"#161082\"/><circle cx=\"9.952\" cy=\"9.952\" r=\"9.902\" fill=\"url(#oneworld_svg__a)\" opacity=\".5\" transform=\"translate(.531 .531)\"/><circle cx=\"9.952\" cy=\"9.952\" r=\"9.902\" fill=\"url(#oneworld_svg__b)\" transform=\"translate(.531 .531)\"/><path fill=\"#fff\" fill-rule=\"nonzero\" d=\"M7.762 10.571c.044-.266.223-.446.49-.446.268 0 .446.225.446.446zm1.65.402c.044-.758-.357-1.383-1.16-1.383-.67 0-1.204.49-1.204 1.206 0 .757.49 1.203 1.248 1.203.491 0 .982-.224 1.116-.757h-.67q-.132.266-.4.266c-.313 0-.492-.223-.492-.535zm9.233.803c.58 0 .803-.49.803-.981s-.224-.982-.803-.982c-.535 0-.758.49-.758.982s.223.981.758.981m1.071.178h-.268v-.446c-.134.313-.49.491-.803.491-.67 0-1.025-.58-1.025-1.204 0-.625.312-1.205 1.025-1.205.357 0 .669.18.803.49V8.788h.267v3.167M9.546 9.68h.312l.58 1.964.535-1.964h.312l.536 1.964.58-1.964h.356l-.713 2.275h-.313l-.579-1.917-.536 1.917h-.312zm5.532 1.116c0 .669-.358 1.204-1.072 1.204-.713 0-1.07-.535-1.07-1.204s.357-1.205 1.07-1.205c.67.045 1.07.58 1.07 1.206m-1.873 0c0 .49.268.98.803.98.536 0 .803-.49.803-.981s-.267-.982-.803-.982c-.535.045-.803.535-.803.982m2.275-1.116h.268v.536a.87.87 0 0 1 .847-.58v.267c-.49-.044-.847.358-.847.804v1.204h-.267V9.68m1.427-.848h.312v3.122h-.268V8.832zM2.275 10.795c0-.267.09-.625.446-.625s.446.357.446.625-.09.624-.446.624-.446-.312-.446-.624m-.758 0c0 .669.491 1.204 1.204 1.204.714 0 1.205-.49 1.205-1.204 0-.67-.491-1.205-1.206-1.205-.713.045-1.204.535-1.204 1.206m2.811-1.117h.714v.313c.133-.224.446-.357.713-.357.758 0 .803.535.803.892v1.427H5.8v-1.07c0-.313.043-.624-.358-.624-.267 0-.401.223-.401.49V12h-.715V9.677\"/></g></svg>"};

var styleCss$2 = i$5`*,*:before,*:after{box-sizing:border-box}@media(prefers-reduced-motion: reduce){*,*:before,*:after{animation-duration:.01ms !important;animation-iteration-count:1 !important;transition-duration:.01ms !important}}*:focus-visible{outline:0}*:focus-visible{outline:0}:focus:not(:focus-visible){outline:3px solid transparent}.headerLinkBox{display:flex;text-decoration:none}.logoIcon{width:calc(var(--ds-size-800, 4rem)*2);padding-right:var(--ds-size-100, 0.5rem);border-right-width:1px;border-right-style:solid;margin-right:var(--ds-size-100, 0.5rem)}.oneworldLogo{display:flex;width:calc(var(--ds-size-500, 2.5rem) + .1rem);flex-direction:column;justify-content:center;padding-left:var(--ds-size-50, 0.25rem);margin-bottom:var(--ds-size-100, 0.5rem)}.headerTitle{display:flex;flex-direction:column;justify-content:center;padding-left:var(--ds-size-50, 0.25rem)}.headerTitle-title{padding-bottom:var(--ds-size-50, 0.25rem);font-size:var(--ds-size-400, 2rem);line-height:1}.headerTitle-tagline{padding-bottom:var(--ds-size-50, 0.25rem);line-height:1;text-transform:uppercase}`;

var colorCss$1 = i$5`.headerLinkBox{color:var(--ds-auro-lockup-alaska-logo-color)}.logoIcon{border-right-color:var(--ds-auro-lockup-divider-color)}.headerTitle-title{color:var(--ds-auro-lockup-title-color)}.headerTitle-tagline{color:var(--ds-auro-lockup-subtitle-color)}:host([onDark]){--ds-auro-lockup-alaska-logo-color: var(--ds-color-icon-primary-inverse, #f7f7f7);--ds-auro-lockup-divider-color: var(--ds-color-border-divider-inverse, rgba(255, 255, 255, 0.25));--ds-auro-lockup-subtitle-color: var(--ds-color-text-tertiary-inverse, #adadad);--ds-auro-lockup-title-color: var(--ds-color-text-subtle-inverse, #56bbde)}`;

var tokensCss$1 = i$5`:host{--ds-auro-lockup-alaska-logo-color: var(--ds-color-brand-lounge, #01426a);--ds-auro-lockup-divider-color: var(--ds-color-border-divider-default, rgba(0, 0, 0, 0.12));--ds-auro-lockup-subtitle-color: var(--ds-color-text-tertiary-default, #6a717c);--ds-auro-lockup-title-color: var(--ds-color-text-info-default, #326aa5)}`;

// Copyright (c) 2021 Alaska Airlines. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.


// See https://git.io/JJ6SJ for "How to document your components using JSDoc"
/**
 * The auro-lockup element is a standardized custom element for the use in headers of Alaska Airlines extended experiences.
 *
 * @attr {String} path - URL path for lockup link
 * @attr {Boolean} onDark - Toggle onDark UI
 * @slot title - Set title for lockup
 * @slot subtitle - Set sub-title for lockup
 * @attr {boolean} standard - uses the standard Alaska logo in place of the official logo, requires use of `oneWorld` attribute.
 * @attr {boolean} oneworld - replaces product name and tag line with Oneworld logo
 */

// build the component class
class AuroLockup extends r$1 {
  constructor() {
    super();

    this.path = '/';
    this.standard = false;
    this.oneworld = false;

    /**
     * @private
     */
    this.runtimeUtils = new AuroLibraryRuntimeUtils$1();
  }

  // function to define props used within the scope of this component
  static get properties() {
    return {
      // ...super.properties,
      path: {
        type: String
      },
      standard: {
        type: Boolean
      },
      oneworld: {
        type: Boolean
      }
    };
  }

  static get styles() {
    return [
      styleCss$2,
      colorCss$1,
      tokensCss$1
    ];
  }

  /**
   * This will register this element with the browser.
   * @param {string} [name="auro-lockup"] - The name of element that you want to register to.
   *
   * @example
   * AuroLockup.register("custom-lockup") // this will register this element to <custom-lockup/>
   *
   */
  static register(name = "auro-lockup") {
    AuroLibraryRuntimeUtils$1.prototype.registerComponent(name, AuroLockup);
  }

  firstUpdated() {
    // Add the tag name as an attribute if it is different than the component name
    this.runtimeUtils.handleComponentTagRename(this, 'auro-lockup');
  }

  /**
   * @private
   * @param {string} svgContent - The imported svg icon.
   * @returns {TemplateResult} - The html template for the icon.
   */
  generateIconHtml(svgContent) {
    const dom = new DOMParser().parseFromString(svgContent, 'text/html'),
      svg = dom.body.firstChild;

    return x`${svg}`;
  }

  // When using auroElement, use the following attribute and function when hiding content from screen readers.
  // aria-hidden="${this.hideAudible(this.hiddenAudible)}"

  // function that renders the HTML and CSS into  the scope of the component
  render() {
    const classes = {
      'logoIcon': true,
      'logoDivider': !this.oneworld
    };

    return x`
      <a href=${this.path} class="headerLinkBox">
        <div class="${e(classes)}">
          ${o$1(this.standard && this.oneworld
            ? this.generateIconHtml(as200.svg)
            : this.generateIconHtml(official200.svg))
          }
        </div>
        ${o$1(this.oneworld ? x`
          <div class="oneworldLogo">
            ${this.generateIconHtml(logoOneworld.svg)}
          </div>
        ` : x`
          <div class="headerTitle">
            <span class="headerTitle-title">
              <slot name="title"></slot>
            </span>
            <span class="headerTitle-tagline">
              <slot name="subtitle"></slot>
            </span>
          </div>
        `)}
      </a>
    `;
  }
}

var lockupVersion = '4.1.1';

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class r extends b{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0;}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const s=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=B(s,this.renderRoot,this.renderOptions);}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0);}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1);}render(){return T}}r._$litElement$=!0,r["finalized"]=!0,globalThis.litElementHydrateSupport?.({LitElement:r});const i=globalThis.litElementPolyfillSupport;i?.({LitElement:r});(globalThis.litElementVersions??=[]).push("4.1.1");

// Copyright (c) 2020 Alaska Airlines. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.


/**
 * @attr {Boolean} hidden - If present, the component will be hidden both visually and from screen readers
 * @attr {Boolean} hiddenVisually - If present, the component will be hidden visually, but still read by screen readers
 * @attr {Boolean} hiddenAudible - If present, the component will be hidden from screen readers, but seen visually
 */

class AuroElement extends s$6 {

  // function to define props used within the scope of this component
  static get properties() {
    return {
      hidden:         { type: Boolean,
                        reflect: true },
      hiddenVisually: { type: Boolean,
                        reflect: true },
      hiddenAudible:  { type: Boolean,
                        reflect: true },
    };
  }

  /**
   * @private Function that determines state of aria-hidden
   */
  hideAudible(value) {
    if (value) {
      return 'true'
    }

    return 'false'
  }
}

var error = {"role":"img","color":"currentColor","title":"","desc":"Error alert indicator.","width":"var(--auro-size-lg, var(--ds-size-300, 1.5rem))","height":"var(--auro-size-lg, var(--ds-size-300, 1.5rem))","xmlns":"http://www.w3.org/2000/svg","xmlns_xlink":"http://www.w3.org/1999/xlink","viewBox":"0 0 24 24","path":"/icons","style":"ico_squareLarge","type":"icon","name":"error","category":"alert","deprecated":true,"svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" aria-labelledby=\"error__desc\" class=\"ico_squareLarge\" data-deprecated=\"true\" role=\"img\" style=\"min-width:var(--auro-size-lg, var(--ds-size-300, 1.5rem));height:var(--auro-size-lg, var(--ds-size-300, 1.5rem));fill:currentColor\" viewBox=\"0 0 24 24\" part=\"svg\"><title/><desc id=\"error__desc\">Error alert indicator.</desc><path d=\"m13.047 5.599 6.786 11.586A1.207 1.207 0 0 1 18.786 19H5.214a1.207 1.207 0 0 1-1.047-1.815l6.786-11.586a1.214 1.214 0 0 1 2.094 0m-1.165.87a.23.23 0 0 0-.085.085L5.419 17.442a.232.232 0 0 0 .203.35h12.756a.234.234 0 0 0 .203-.35L12.203 6.554a.236.236 0 0 0-.321-.084M12 15.5a.75.75 0 1 1 0 1.5.75.75 0 0 1 0-1.5m-.024-6.22c.325 0 .589.261.589.583v4.434a.586.586 0 0 1-.589.583.586.586 0 0 1-.588-.583V9.863c0-.322.264-.583.588-.583\"/></svg>"};

/* eslint-disable no-underscore-dangle, jsdoc/no-undefined-types, jsdoc/require-param-description */

const _fetchMap = new Map();

/**
 * A callback to parse Response body.
 *
 * @callback ResponseParser
 * @param {Fetch.Response} response
 * @returns {Promise}
 */

/**
 * A minimal in-memory map to de-duplicate Fetch API media requests.
 *
 * @param {String} uri
 * @param {Object} [options={}]
 * @param {ResponseParser} [options.responseParser=(response) => response.text()]
 * @returns {Promise}
 */
const cacheFetch = (uri, options = {}) => {
  const responseParser = options.responseParser || ((response) => response.text());
  if (!_fetchMap.has(uri)) {
    _fetchMap.set(uri, fetch(uri).then(responseParser));
  }
  return _fetchMap.get(uri);
};

var styleCss$1 = i$5`*,*:before,*:after{box-sizing:border-box}@media(prefers-reduced-motion: reduce){*,*:before,*:after{animation-duration:.01ms !important;animation-iteration-count:1 !important;transition-duration:.01ms !important}}*:focus-visible{outline:0}*:focus-visible{outline:0}:focus:not(:focus-visible){outline:3px solid transparent}.util_displayInline{display:inline}.util_displayInlineBlock{display:inline-block}.util_displayBlock,:host{display:block}.util_displayFlex{display:flex}.util_displayHidden,:host([hidden]:not(:focus):not(:active)){display:none}.util_displayHiddenVisually,:host([hiddenVisually]:not(:focus):not(:active)){position:absolute;overflow:hidden;clip:rect(1px, 1px, 1px, 1px);width:1px;height:1px;padding:0;border:0}.ico_squareLarge{fill:currentColor;height:var(--auro-size-lg, var(--ds-size-300, 1.5rem))}.ico_squareSmall{fill:currentColor;height:.6rem}.ico_squareMed{fill:currentColor;height:var(--auro-size-md, var(--ds-size-200, 1rem))}.ico_squareSml{fill:currentColor;height:var(--auro-size-sm, var(--ds-size-150, 0.75rem))}:host{color:currentColor;vertical-align:middle;line-height:1;display:inline-block}:host .logo{color:var(--ds-color-brand-midnight-400, #01426a)}svg{min-width:var(--ds-auro-icon-size, 1.5rem) !important;width:var(--ds-auro-icon-size, 1.5rem) !important;height:var(--ds-auro-icon-size, 1.5rem) !important}.label{display:flex;align-items:flex-start}.label svg{margin:0 var(--ds-size-50, 0.25rem)}.labelContainer{line-height:1.8}`;

// Copyright (c) 2020 Alaska Airlines. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.


// See https://git.io/JJ6SJ for "How to document your components using JSDoc"
/**
 * @attr {Boolean} onDark - Set value for on-dark version of auro-icon
 * @slot - Hidden from visibility, used for a11y if icon description is needed
 */

// build the component class
class BaseIcon extends AuroElement {
  constructor() {
    super();
    this.onDark = false;
  }

  // function to define props used within the scope of this component
  static get properties() {
    return {
      ...super.properties,
      onDark: {
        type: Boolean,
        reflect: true
      },

      /**
       * @private
       */
      svg: {
        attribute: false,
        reflect: true
      }
    };
  }

  static get styles() {
    return i$5`
      ${styleCss$1}
    `;
  }

  /**
   * Async function to fetch requested icon from npm CDN.
   * @private
   * @param {string} category - Icon category.
   * @param {string} name - Icon name.
   * @returns {SVGElement} DOM - Ready HTML to be appended.
   */
  async fetchIcon(category, name) {
    let iconHTML = '';

    if (category === 'logos') {
      iconHTML = await cacheFetch(`${this.uri}/${category}/${name}.svg`);
    } else {
      iconHTML = await cacheFetch(`${this.uri}/icons/${category}/${name}.svg`);
    }

    const dom = new DOMParser().parseFromString(iconHTML, 'text/html');

    return dom.body.querySelector('svg');
  }

  // lifecycle function
  async firstUpdated() {
    if (!this.customSvg) {
      const svg = await this.fetchIcon(this.category, this.name);

      if (svg) {
        this.svg = svg;
      } else if (!svg) {
        const penDOM = new DOMParser().parseFromString(error.svg, 'text/html');

        this.svg = penDOM.body.firstChild;
      }
    }
  }
}

var tokensCss = i$5`:host{--ds-auro-icon-color: var(--ds-color-icon-primary-default, $ds-color-icon-primary-default);--ds-auro-icon-size: var(--ds-size-300, $ds-size-300)}`;

var colorCss = i$5`:host{color:var(--ds-auro-icon-color)}:host([customColor]){color:inherit}:host(:not([onDark])[accent]){--ds-auro-icon-color: var(--ds-color-icon-accent-default, #a2c270)}:host(:not([onDark])[disabled]){--ds-auro-icon-color: var(--ds-color-icon-ui-primary-disabled-default, #adadad)}:host(:not([onDark])[emphasis]){--ds-auro-icon-color: var(--ds-color-icon-emphasis-default, #2a2a2a)}:host(:not([onDark])[error]){--ds-auro-icon-color: var(--ds-color-icon-error-default, #cc1816)}:host(:not([onDark])[info]){--ds-auro-icon-color: var(--ds-color-icon-info-default, #326aa5)}:host(:not([onDark])[secondary]){--ds-auro-icon-color: var(--ds-color-icon-secondary-default, #7e8894)}:host(:not([onDark])[subtle]){--ds-auro-icon-color: var(--ds-color-icon-subtle-default, #a0c9f1)}:host(:not([onDark])[success]){--ds-auro-icon-color: var(--ds-color-icon-success-default, #40a080)}:host(:not([onDark])[tertiary]){--ds-auro-icon-color: var(--ds-color-icon-tertiary-default, #afb9c6)}:host(:not([onDark])[warning]){--ds-auro-icon-color: var(--ds-color-icon-warning-default, #c49432)}:host([onDark]){--ds-auro-icon-color: var(--ds-color-icon-primary-inverse, #f7f7f7)}:host([onDark][accent]){--ds-auro-icon-color: var(--ds-color-icon-accent-inverse, #badd81)}:host([onDark][disabled]){--ds-auro-icon-color: var(--ds-color-icon-ui-primary-disabled-inverse, #7e7e7e)}:host([onDark][emphasis]){--ds-auro-icon-color: var(--ds-color-icon-emphasis-inverse, #ffffff)}:host([onDark][error]){--ds-auro-icon-color: var(--ds-color-icon-error-inverse, #f9aca6)}:host([onDark][info]){--ds-auro-icon-color: var(--ds-color-icon-info-inverse, #89b2d4)}:host([onDark][secondary]){--ds-auro-icon-color: var(--ds-color-icon-secondary-inverse, #ccd2db)}:host([onDark][subtle]){--ds-auro-icon-color: var(--ds-color-icon-subtle-inverse, #326aa5)}:host([onDark][success]){--ds-auro-icon-color: var(--ds-color-icon-success-inverse, #8eceb9)}:host([onDark][tertiary]){--ds-auro-icon-color: var(--ds-color-icon-tertiary-inverse, #939fad)}:host([onDark][warning]){--ds-auro-icon-color: var(--ds-color-icon-warning-inverse, #f2c153)}`;

// Copyright (c) Alaska Air. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.

// ---------------------------------------------------------------------

/* eslint-disable line-comment-position, no-inline-comments, no-confusing-arrow, no-nested-ternary, implicit-arrow-linebreak */

class AuroLibraryRuntimeUtils {

  /* eslint-disable jsdoc/require-param */

  /**
   * This will register a new custom element with the browser.
   * @param {String} name - The name of the custom element.
   * @param {Object} componentClass - The class to register as a custom element.
   * @returns {void}
   */
  registerComponent(name, componentClass) {
    if (!customElements.get(name)) {
      customElements.define(name, class extends componentClass {});
    }
  }

  /**
   * Finds and returns the closest HTML Element based on a selector.
   * @returns {void}
   */
  closestElement(
    selector, // selector like in .closest()
    base = this, // extra functionality to skip a parent
    __Closest = (el, found = el && el.closest(selector)) =>
      !el || el === document || el === window
        ? null // standard .closest() returns null for non-found selectors also
        : found
          ? found // found a selector INside this element
          : __Closest(el.getRootNode().host) // recursion!! break out to parent DOM
  ) {
    return __Closest(base);
  }
  /* eslint-enable jsdoc/require-param */

  /**
   * If the element passed is registered with a different tag name than what is passed in, the tag name is added as an attribute to the element.
   * @param {Object} elem - The element to check.
   * @param {String} tagName - The name of the Auro component to check for or add as an attribute.
   * @returns {void}
   */
  handleComponentTagRename(elem, tagName) {
    const tag = tagName.toLowerCase();
    const elemTag = elem.tagName.toLowerCase();

    if (elemTag !== tag) {
      elem.setAttribute(tag, true);
    }
  }

  /**
   * Validates if an element is a specific Auro component.
   * @param {Object} elem - The element to validate.
   * @param {String} tagName - The name of the Auro component to check against.
   * @returns {Boolean} - Returns true if the element is the specified Auro component.
   */
  elementMatch(elem, tagName) {
    const tag = tagName.toLowerCase();
    const elemTag = elem.tagName.toLowerCase();

    return elemTag === tag || elem.hasAttribute(tag);
  }
}

// Copyright (c) 2020 Alaska Airlines. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.


// See https://git.io/JJ6SJ for "How to document your components using JSDoc"
/**
 * auro-icon provides users a way to use the Auro Icons by simply passing in the category and name.
 *
 * @attr {String} category - The category of the icon you are looking for. See https://auro.alaskaair.com/icons/usage.
 * @attr {String} name - The name of the icon you are looking for without the file extension. See https://auro.alaskaair.com/icons/usage
 * @attr {Boolean} customColor - Removes primary selector.
 * @attr {Boolean} customSvg - When true, auro-icon will render a custom SVG inside the default slot.
 * @attr {Boolean} label - Exposes content in slot as icon label.
 * @attr {Boolean} primary - DEPRECATED: Sets the icon to use the baseline primary icon style.
 * @attr {Boolean} accent - Sets the icon to use the accent style.
 * @attr {Boolean} emphasis - Sets the icon to use the emphasis style.
 * @attr {Boolean} disabled - Sets the icon to use the disabled style.
 * @attr {Boolean} error - Sets the icon to use the error style.
 * @attr {Boolean} info - Sets the icon to use the info style.
 * @attr {Boolean} secondary - Sets the icon to use the secondary style.
 * @attr {Boolean} tertiary - Sets the icon to use the tertiary style.
 * @attr {Boolean} subtle - Sets the icon to use the subtle style.
 * @attr {Boolean} success - Sets the icon to use the success style.
 * @attr {Boolean} warning - Sets the icon to use the warning style.
 * @attr {String} ariaHidden - Set aria-hidden value. Default is `true`. Option is `false`.
 * @attr {String} uri - Set the uri for CDN used when fetching icons
 * @slot - Hidden from visibility, used for a11y if icon description is needed.
 * @slot svg - Used for custom SVG content.
 */

// build the component class
class AuroIcon extends BaseIcon {
  constructor() {
    super();

    this.uri = 'https://cdn.jsdelivr.net/npm/@alaskaairux/icons@latest/dist';

    this.privateDefaults();
  }

  /**
   * Internal Defaults.
   * @private
   * @returns {void}
   */
  privateDefaults() {
    this.accent = false;
    this.customColor = false;
    this.customSvg = false;
    this.disabled = false;
    this.emphasis = false;
    this.error = false;
    this.info = false;
    this.label = false;
    this.primary = false;
    this.secondary = false;
    this.subtle = false;
    this.success = false;
    this.tertiary = false;
    this.warning = false;
    this.runtimeUtils = new AuroLibraryRuntimeUtils();
  }

  // function to define props used within the scope of this component
  static get properties() {
    return {
      ...super.properties,
      accent: {
        type: Boolean,
        reflect: true
      },
      ariaHidden: {
        type: String,
        reflect: true
      },
      category: {
        type: String,
        reflect: true
      },
      customColor: {
        type: Boolean
      },
      customSvg: {
        type: Boolean
      },
      disabled: {
        type: Boolean,
        reflect: true
      },
      emphasis: {
        type: Boolean,
        reflect: true
      },
      error: {
        type: Boolean,
        reflect: true
      },
      info: {
        type: Boolean,
        reflect: true
      },
      label: {
        type: Boolean,
        reflect: true
      },
      name: {
        type: String,
        reflect: true
      },
      primary: {
        type: Boolean,
        reflect: true
      },
      secondary: {
        type: Boolean,
        reflect: true
      },
      subtle: {
        type: Boolean,
        reflect: true
      },
      success: {
        type: Boolean,
        reflect: true
      },
      tertiary: {
        type: Boolean,
        reflect: true
      },
      uri: {
        type: String
      },
      warning: {
        type: Boolean,
        reflect: true
      }
    };
  }

  static get styles() {
    return [
      super.styles,
      i$5`${tokensCss}`,
      i$5`${styleCss$1}`,
      i$5`${colorCss}`
    ];
  }

  /**
   * This will register this element with the browser.
   * @param {string} [name="auro-icon"] - The name of element that you want to register to.
   *
   * @example
   * AuroIcon.register("custom-icon") // this will register this element to <custom-icon/>
   *
   */
  static register(name = "auro-icon") {
    AuroLibraryRuntimeUtils.prototype.registerComponent(name, AuroIcon);
  }

  connectedCallback() {
    super.connectedCallback();

    // Add the tag name as an attribute if it is different than the component name
    this.runtimeUtils.handleComponentTagRename(this, 'auro-icon');
  }

  // function that renders the HTML and CSS into  the scope of the component
  render() {
    const a11y = {
      'labelContainer': true,
      'util_displayHiddenVisually': !this.label
    };

    const classes = {
      'label': this.label
    };

    return x`
      <div
        class="${e(classes)}"
        title="${o$1(this.title || undefined)}">
        <span aria-hidden="${o$1(this.ariaHidden ? this.ariaHidden : true)}" part="svg">
          ${this.customSvg ? x`
              <slot name="svg"></slot>
            ` : x`
              ${this.svg}
            `
          }
        </span>

        <div class="${e(a11y)}">
          <slot></slot>
        </div>
      </div>
    `;
  }
}

var as400 = {"hidden":"true","category":"restricted","role":"img","color":"currentColor","desc":"Logo image for Alaska Airlines","width":"100%","height":"auto","xmlns":"http://www.w3.org/2000/svg","xmlns_xlink":"http://www.w3.org/1999/xlink","path":"/icons/restricted","style":"","type":"restricted","name":"AS-400","title":"Alaska Airlines","viewBox":"0 0 396 121","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" aria-labelledby=\"AS-400__title AS-400__desc\" role=\"img\" style=\"min-width:100%;height:auto;fill:currentColor\" viewBox=\"0 0 396 121\" part=\"svg\"><title id=\"AS-400__title\">Alaska Airlines</title><desc id=\"AS-400__desc\">Logo image for Alaska Airlines</desc><path d=\"m194.18 5-45.2 75.86a55.1 55.1 0 0 0-8 23.3h-17.69c1.2-9.6 5-18.74 12.73-31.83l31.63-53c6.32-10.51 12.62-14.31 24-14.31zM190.75 84.6c-3.32 3.06-9.71 7.68-15.12 7.84-3.72-.16-3.86-3.65-1.36-8.46 9.48-18.29 19.48-27.98 31.9-27.92h2.24zm16.7-38.82c-22.92 0-37 13.35-49.45 42.57-3.11 7.34-4.88 16.44 5.71 16.33 6-.08 16.12-3.38 23.23-8.28a25 25 0 0 0-.66 7.72h16.08c.56-6.27 3-14.08 8.26-23.57L230.67 47a215 215 0 0 0-23.27-1.22zM356.02 84.6c-3.31 3.06-9.71 7.68-15.11 7.84-3.72-.16-3.86-3.65-1.36-8.46 9.54-18.29 19.57-28 31.94-27.92h2.26zm16.73-38.82c-22.92 0-37 13.35-49.44 42.57-3.11 7.34-4.89 16.44 5.71 16.33 6-.08 16.12-3.38 23.22-8.28a25.3 25.3 0 0 0-.66 7.72h16.08c.56-6.27 3-14.08 8.27-23.57L396 47a216 216 0 0 0-23.25-1.22\"/><path d=\"M320.45 120.29h-5.25a15.166 15.166 0 0 1-14.64-11.15l-8-30.15-14.94 25.13h-17.13l47.83-81c6.17-10.51 12.6-14.33 24-14.33h1.75l-31.75 53.7 23.83-16.42h19.13l-40 27.66zM162.61.25c-16.14 0-24.47 4.27-40.31 15.69L68.75 54.57H34.44c-9.92 0-17.85.39-24.11 6.29l-8.87 8.19 49.84-1.92-51.3 37h22.17l52.47-37.88c10.16-.38 17.23-.64 17.29-.62 12.23-.34 19-11.05 19-11.05H90.82L133.21 24l-31.46 51c-6.74 11.72-10 20.1-11.11 29.09h18.21a55.25 55.25 0 0 1 8-23.3l42.9-71.6c3-4.92 5.6-8.94 5.6-8.94zM248.01 62.2c-.22 1.53.41 2.46 3.49 4.45l4.91 3.23c5.32 3.54 7.47 8.76 6.84 13.07-1.79 12-10.61 21.67-29.36 21.68a106 106 0 0 1-21.69-1.89l7.28-12.27c6.78 1.18 10.65 1.79 15.72 1.78 7.06 0 9.88-3.18 10.27-5.79.23-1.55-.51-3.33-3.87-5.65l-3.85-2.76c-6.24-4.45-7.88-8-7.06-13.51 1.57-10.63 13.86-18.76 30.93-18.76 5.877.028 11.748.362 17.59 1l-6.85 11.59a158 158 0 0 0-15.83-.5c-4.97.18-8.16 1.87-8.52 4.33M381.68 96.74a3.76 3.76 0 1 1-3.7 3.76 3.74 3.74 0 0 1 3.7-3.76m0 6.78a3.004 3.004 0 0 0 3.043-3.528 3 3 0 0 0-2.334-2.406 2.998 2.998 0 0 0-3.619 2.934 2.93 2.93 0 0 0 2.91 3m-.47-1h-.77v-4.09h1.41a1.31 1.31 0 0 1 1.39 1.29 1.28 1.28 0 0 1-.9 1.21l.92 1.59h-.89l-.85-1.52h-.31zm.53-2.19c.46 0 .71-.23.71-.6s-.25-.62-.71-.62h-.53v1.22z\"/></svg>"};

var as300 = {"hidden":"true","category":"restricted","role":"img","color":"currentColor","desc":"Logo image for Alaska Airlines","width":"100%","height":"auto","xmlns":"http://www.w3.org/2000/svg","xmlns_xlink":"http://www.w3.org/1999/xlink","path":"/icons/restricted","style":"","type":"restricted","name":"AS-300","title":"Alaska Airlines","viewBox":"0 0 144 45","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" aria-labelledby=\"AS-300__title AS-300__desc\" role=\"img\" style=\"min-width:100%;height:auto;fill:currentColor\" viewBox=\"0 0 144 45\" part=\"svg\"><title id=\"AS-300__title\">Alaska Airlines</title><desc id=\"AS-300__desc\">Logo image for Alaska Airlines</desc><path d=\"M70.61 2.15 54.17 29.74a20.06 20.06 0 0 0-2.9 8.47h-6.44c.44-3.49 1.8-6.81 4.63-11.58l11.5-19.27c2.3-3.82 4.59-5.21 8.75-5.21zM69.34 31.11c-1.2 1.11-3.53 2.79-5.49 2.85-1.36-.06-1.41-1.33-.5-3.07 3.47-6.65 7.12-10.17 11.62-10.16h.82zM75.42 17c-8.34 0-13.46 4.86-18 15.49-1.13 2.67-1.78 6 2.07 5.93a17.74 17.74 0 0 0 8.45-3 9.3 9.3 0 0 0-.24 2.81h5.86a22 22 0 0 1 3-8.57l7.31-12.19a79 79 0 0 0-8.45-.47M129.46 31.11c-1.2 1.11-3.53 2.79-5.49 2.85-1.36-.06-1.41-1.33-.5-3.07 3.47-6.65 7.12-10.17 11.62-10.16h.81zm6.1-14.11c-8.34 0-13.46 4.86-18 15.49-1.14 2.67-1.78 6 2.07 5.93a17.74 17.74 0 0 0 8.45-3 9 9 0 0 0-.24 2.81h5.84a22.1 22.1 0 0 1 3-8.57l7.31-12.19a79 79 0 0 0-8.43-.47\"/><path d=\"M116.56 44.09h-1.91a5.53 5.53 0 0 1-5.36-4.09l-2.91-11-5.43 9.14h-6.23l17.4-29.44c2.24-3.83 4.58-5.21 8.73-5.21h.64l-11.55 19.58 8.66-6h7l-14.61 10.09zM59.13.44c-5.87 0-8.9 1.55-14.66 5.7l-19.48 14H12.56c-3.6 0-6.49.14-8.77 2.29l-3.22 3 18.12-.7L0 38.21h8.06l19.08-13.77c3.7-.14 6.27-.24 6.29-.23 4.45-.12 6.91-4 6.91-4h-7.32L48.44 9.07 37 27.63c-2.45 4.27-3.63 7.31-4 10.58h6.56a20.2 20.2 0 0 1 2.9-8.47l15.61-26c1.08-1.79 2-3.25 2-3.25zM90.18 23c-.08.55.15.89 1.27 1.62l1.79 1.17a5.05 5.05 0 0 1 2.49 4.75c-.65 4.36-3.86 7.88-10.68 7.89-2.647.039-5.29-.192-7.89-.69l2.65-4.46c1.882.392 3.797.606 5.72.64 2.56 0 3.59-1.15 3.73-2.1.08-.56-.19-1.21-1.4-2.06l-1.42-1c-2.27-1.62-2.87-2.9-2.57-4.91.57-3.87 5-6.82 11.25-6.82 2.138.005 4.275.125 6.4.36l-2.49 4.22a56 56 0 0 0-5.76-.18c-1.79.03-2.95.64-3.09 1.57M140.43 34.36a2.067 2.067 0 0 1 2.108 2.429 2.067 2.067 0 0 1-2.813 1.559 2.07 2.07 0 0 1-1.295-1.919 2.07 2.07 0 0 1 2-2.07m0 3.73a1.66 1.66 0 1 0-1.6-1.66 1.61 1.61 0 0 0 1.6 1.66m-.25-.56h-.43v-2.25h.81a.72.72 0 0 1 .532.192.73.73 0 0 1 .228.517.71.71 0 0 1-.49.67l.5.87h-.49l-.47-.84h-.16zm.29-1.21c.25 0 .39-.12.39-.32s-.14-.35-.39-.35h-.29v.67z\"/></svg>"};

var as100 = {"hidden":"true","category":"restricted","role":"img","color":"currentColor","desc":"Logo image for Alaska Airlines","width":"100%","height":"auto","xmlns":"http://www.w3.org/2000/svg","xmlns_xlink":"http://www.w3.org/1999/xlink","path":"/icons/restricted","style":"","type":"restricted","name":"AS-100","title":"Alaska Airlines","viewBox":"0 0 57 17","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" aria-labelledby=\"AS-100__title AS-100__desc\" role=\"img\" style=\"min-width:100%;height:auto;fill:currentColor\" viewBox=\"0 0 57 17\" part=\"svg\"><title id=\"AS-100__title\">Alaska Airlines</title><desc id=\"AS-100__desc\">Logo image for Alaska Airlines</desc><path d=\"M22.21.05c-2.2 0-3.33.58-5.49 2.14L9.41 7.46H4.74c-1.36 0-2.44 0-3.29.86L.24 9.43 7 9.17l-7 5h3l7.16-5.16L12.58 9a3.44 3.44 0 0 0 2.59-1.5h-2.75l5.78-4.22-4.29 7a10.4 10.4 0 0 0-1.51 4h2.48A7.56 7.56 0 0 1 16 11l5.85-9.77c.41-.67.77-1.22.77-1.22zM26.52.69 20.35 11a7.5 7.5 0 0 0-1.08 3.17h-2.42a11.3 11.3 0 0 1 1.74-4.34l4.31-7.19A3.35 3.35 0 0 1 26.18.69zM26 11.55a3.77 3.77 0 0 1-2 1.07c-.5 0-.52-.5-.18-1.15 1.3-2.5 2.67-3.82 4.35-3.81h.31zm2.28-5.29c-3.12 0-5.05 1.82-6.74 5.8-.43 1-.67 2.25.78 2.23a6.6 6.6 0 0 0 3.16-1.13 4 4 0 0 0-.09 1.05h2.2A8.15 8.15 0 0 1 28.75 11l2.75-4.57a31 31 0 0 0-3.18-.17zM48.59 11.55a3.8 3.8 0 0 1-2.06 1.07c-.51 0-.53-.5-.19-1.15 1.3-2.5 2.67-3.82 4.36-3.81h.3zm2.28-5.29c-3.13 0-5 1.82-6.75 5.8-.42 1-.66 2.25.78 2.23a6.64 6.64 0 0 0 3.17-1.13 3.3 3.3 0 0 0-.07 1.05h2.19A8.4 8.4 0 0 1 51.3 11L54 6.43a30 30 0 0 0-3.13-.17\"/><path d=\"M43.74 16.42H43a2.08 2.08 0 0 1-2-1.52l-1.09-4.11-2 3.42h-2.35l6.52-11a3.34 3.34 0 0 1 3.28-1.95h.24l-4.33 7.32 3.25-2.24h2.6l-5.46 3.77zM33.86 8.5c0 .21.06.33.47.61l.67.44a1.89 1.89 0 0 1 .94 1.78c-.25 1.63-1.45 3-4 3-.989-.009-1.974-.12-2.94-.33l1-1.68c.704.15 1.42.233 2.14.25 1 0 1.35-.44 1.4-.79s-.07-.46-.52-.77l-.54-.38c-.85-.61-1.07-1.09-1-1.84.22-1.45 1.89-2.56 4.22-2.56q1.204.01 2.4.14L37.17 8A21 21 0 0 0 35 7.91c-.66.02-1.09.25-1.14.59M55.23 11a1.7 1.7 0 1 1-1.67 1.69A1.69 1.69 0 0 1 55.23 11m0 3.05a1.36 1.36 0 1 0-1.31-1.36A1.32 1.32 0 0 0 55.23 14zm-.23-.5h-.35v-1.84h.64a.58.58 0 0 1 .508.915.57.57 0 0 1-.288.205l.41.72h-.4l-.38-.69H55zm.24-1c.2 0 .32-.1.32-.27s-.12-.28-.32-.28H55v.55z\"/></svg>"};

var official400 = {"hidden":"true","category":"restricted","role":"img","color":"currentColor","desc":"Logo image for Alaska Airlines","width":"100%","height":"auto","xmlns":"http://www.w3.org/2000/svg","xmlns_xlink":"http://www.w3.org/1999/xlink","path":"/icons/restricted","style":"","type":"restricted","name":"AS-tagline-400","title":"Alaska Airlines","viewBox":"0 0 396 171","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" aria-labelledby=\"AS-tagline-400__title AS-tagline-400__desc\" role=\"img\" style=\"min-width:100%;height:auto;fill:currentColor\" viewBox=\"0 0 396 171\" part=\"svg\"><title id=\"AS-tagline-400__title\">Alaska Airlines</title><desc id=\"AS-tagline-400__desc\">Logo image for Alaska Airlines</desc><path d=\"M194.2 4.7 149 80.6c-4.7 7.8-7.3 15.7-8 23.3h-17.7c1.2-9.6 5-18.7 12.7-31.8l31.6-53c6.3-10.5 12.6-14.3 24-14.3h2.6zM190.7 84.3c-3.3 3.1-9.7 7.7-15.1 7.8-3.7-.2-3.9-3.7-1.4-8.5 9.5-18.3 19.6-28 31.9-27.9h2.2zm16.7-38.8c-22.9 0-37 13.4-49.4 42.6-3.1 7.3-4.9 16.4 5.7 16.3 6-.1 16.1-3.4 23.2-8.3-.6 2.4-.9 5.7-.7 7.7h16.1c.6-6.3 3-14.1 8.3-23.6l20.1-33.5c-7.7-.8-15.4-1.2-23.3-1.2M356 84.3c-3.3 3.1-9.7 7.7-15.1 7.8-3.7-.2-3.9-3.7-1.4-8.5 9.5-18.3 19.6-28 31.9-27.9h2.2zm16.7-38.8c-22.9 0-37 13.4-49.4 42.6-3.1 7.3-4.9 16.4 5.7 16.3 6-.1 16.1-3.4 23.2-8.3-.6 2.4-.9 5.7-.7 7.7h16.1c.6-6.3 3-14.1 8.3-23.6L396 46.8c-7.6-.9-15.4-1.3-23.3-1.3\"/><path d=\"M320.5 120h-5.3c-6.8 0-12.8-4.6-14.6-11.1l-8-30.2-14.9 25.1h-17.1l47.8-81c6.2-10.5 12.6-14.3 24-14.3h1.8l-31.8 53.7 23.8-16.4h19.1l-40.1 27.7zM162.6 0c-16.1 0-24.5 4.3-40.3 15.7L68.7 54.3H34.4c-9.9 0-17.9.4-24.1 6.3l-8.9 8.2s25.8-1 49.8-1.9L0 103.9h22.2L74.6 66c10.2-.4 17.2-.6 17.3-.6 12.2-.3 19-11.1 19-11.1H90.8l42.4-30.6-31.5 51.1c-6.7 11.7-10 20.1-11.1 29.1h18.2c.7-7.6 3.3-15.5 8-23.3L159.7 9c3-4.9 5.6-8.9 5.6-8.9zM248 62c-.2 1.5.4 2.5 3.5 4.5l4.9 3.2c5.3 3.5 7.5 8.8 6.8 13.1-1.8 12-10.6 21.7-29.4 21.7-8.2 0-11.9-.3-21.7-1.9l7.3-12.3c6.8 1.2 10.6 1.8 15.7 1.8 7.1 0 9.9-3.2 10.3-5.8.2-1.5-.5-3.3-3.9-5.6l-3.9-2.8c-6.2-4.5-7.9-8-7.1-13.5 1.6-10.6 13.9-18.8 30.9-18.8 5.4 0 11.2.3 17.6 1l-6.9 11.6c-4.2-.3-11-.7-15.8-.5-4.7.1-7.9 1.8-8.3 4.3M381.7 96.5c2.1 0 3.7 1.7 3.7 3.8s-1.7 3.8-3.7 3.8c-2.1 0-3.7-1.7-3.7-3.8s1.6-3.8 3.7-3.8m0 6.8c1.6 0 2.9-1.3 2.9-3s-1.3-3-2.9-3-2.9 1.3-2.9 3 1.3 3 2.9 3m-.5-1h-.8v-4.1h1.4c.8 0 1.4.6 1.4 1.3 0 .6-.4 1-.9 1.2l.9 1.6h-.9l-.9-1.5h-.3v1.5zm.5-2.2c.5 0 .7-.2.7-.6s-.3-.6-.7-.6h-.5v1.2zM49.6 163.1H37l-2.6 7.1H28l11.9-31.1h7l11.9 31.1h-6.6zM39 157.6h8.6l-4.3-11.8zM80.4 170.2v-31.1h6.1v31.1zM122 158.2h-3.2v12h-6.1v-31.1h12.2c6.1 0 9.9 4.2 9.9 9.6 0 4.3-2.5 7.6-6.6 8.8l6.7 12.7h-6.8zm1.7-5.2c3.1 0 4.9-1.8 4.9-4.3 0-2.6-1.8-4.3-4.9-4.3h-4.9v8.7h4.9zM159.3 170.2v-31.1h6.1v25.3h13.9v5.8zM203 170.2v-31.1h6.1v31.1zM255.5 170.2l-14.1-22.1v22.1h-6.1v-31.1h7.6l13 20.6v-20.6h6.1v31.1zM288.1 170.2v-31.1h19.5v5.7h-13.4v7.1h12.2v5.4h-12.2v7.2h13.4v5.7zM348.3 148.2c-.3-1.7-1.7-4.4-5.7-4.4-2.9 0-4.9 1.9-4.9 4 0 1.7 1.1 3.1 3.4 3.5l4.3.8c5.7 1.1 8.7 4.8 8.7 9.2 0 4.8-4 9.6-11.2 9.6-8.3 0-11.9-5.3-12.4-9.8l5.6-1.5c.3 3.1 2.4 5.8 6.8 5.8 3.2 0 5-1.6 5-3.8 0-1.8-1.4-3.2-3.8-3.7l-4.3-.9c-5-1-8.2-4.2-8.2-8.9 0-5.5 5-9.8 10.8-9.8 7.6 0 10.5 4.6 11.2 8.1z\"/></svg>"};

var official300 = {"hidden":"true","category":"restricted","role":"img","color":"currentColor","desc":"Logo image for Alaska Airlines","width":"100%","height":"auto","xmlns":"http://www.w3.org/2000/svg","xmlns_xlink":"http://www.w3.org/1999/xlink","path":"/icons/restricted","style":"","type":"restricted","name":"AS-tagline-300","title":"Alaska Airlines","viewBox":"0 0 144 63","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" aria-labelledby=\"AS-tagline-300__title AS-tagline-300__desc\" role=\"img\" style=\"min-width:100%;height:auto;fill:currentColor\" viewBox=\"0 0 144 63\" part=\"svg\"><title id=\"AS-tagline-300__title\">Alaska Airlines</title><desc id=\"AS-tagline-300__desc\">Logo image for Alaska Airlines</desc><path d=\"M70.6 1.7 54.2 29.3c-1.7 2.8-2.6 5.7-2.9 8.5h-6.4c.4-3.5 1.8-6.8 4.6-11.6L61 6.9c2.3-3.8 4.6-5.2 8.7-5.2zM69.3 30.7c-1.2 1.1-3.5 2.8-5.5 2.9-1.4-.1-1.4-1.3-.5-3.1 3.5-6.7 7.1-10.2 11.6-10.2h.8zm6.1-14.1c-8.3 0-13.5 4.9-18 15.5-1.1 2.7-1.8 6 2.1 5.9 2.2 0 5.9-1.2 8.4-3-.2.9-.3 2.1-.2 2.8h5.8c.2-2.3 1.1-5.1 3-8.6L83.9 17c-2.8-.3-5.6-.4-8.5-.4M129.5 30.7c-1.2 1.1-3.5 2.8-5.5 2.9-1.4-.1-1.4-1.3-.5-3.1 3.5-6.7 7.1-10.2 11.6-10.2h.8zm6-14.1c-8.3 0-13.5 4.9-18 15.5-1.1 2.7-1.8 6 2.1 5.9 2.2 0 5.9-1.2 8.4-3-.2.9-.3 2.1-.2 2.8h5.8c.2-2.3 1.1-5.1 3-8.6L144 17c-2.8-.3-5.6-.4-8.5-.4\"/><path d=\"M116.5 43.6h-1.9c-2.5 0-4.7-1.7-5.3-4.1l-2.9-11-5.4 9.1h-6.2l17.4-29.4c2.2-3.8 4.6-5.2 8.7-5.2h.6l-11.6 19.5 8.7-6h7L111 26.7zM59.1 0c-5.9 0-8.9 1.6-14.7 5.7L25 19.8H12.5c-3.6 0-6.5.1-8.8 2.3l-3.2 3s9.4-.4 18.1-.7L0 37.8h8.1l19-13.8c3.7-.1 6.3-.2 6.3-.2 4.4-.1 6.9-4 6.9-4H33L48.4 8.6 37 27.2c-2.5 4.3-3.6 7.3-4 10.6h6.6c.3-2.8 1.2-5.6 2.9-8.5l15.6-26c1.1-1.8 2-3.3 2-3.3zM90.2 22.5c-.1.6.1.9 1.3 1.6l1.8 1.2c1.9 1.3 2.7 3.2 2.5 4.8-.6 4.4-3.9 7.9-10.7 7.9-3 0-4.3-.1-7.9-.7l2.6-4.5c2.5.4 3.9.7 5.7.6 2.6 0 3.6-1.2 3.7-2.1.1-.6-.2-1.2-1.4-2.1l-1.4-1c-2.3-1.6-2.9-2.9-2.6-4.9.6-3.9 5-6.8 11.2-6.8 1.9 0 4.1.1 6.4.4L99 21.1c-1.5-.1-4-.2-5.8-.2-1.7.1-2.9.7-3 1.6M140.4 33.9c1.1 0 2.1.9 2.1 2.1 0 1.1-.9 2.1-2.1 2.1-1.1 0-2-.9-2-2.1 0-1.1.9-2.1 2-2.1m0 3.7c.9 0 1.6-.7 1.6-1.7 0-.9-.7-1.7-1.6-1.7s-1.6.7-1.6 1.7.7 1.7 1.6 1.7m-.2-.5h-.4v-2.2h.8c.4 0 .8.3.8.7 0 .3-.2.6-.5.7l.5.9h-.5l-.5-.8h-.2zm.3-1.2c.3 0 .4-.1.4-.3s-.1-.3-.4-.3h-.3v.7h.3zM18.1 59.3h-4.6l-.9 2.6h-2.3l4.3-11.3h2.6l4.3 11.3h-2.4zm-3.8-2h3.1L15.8 53zM29.3 61.9V50.6h2.2v11.3zM44.4 57.6h-1.1V62h-2.2V50.6h4.4c2.2 0 3.6 1.5 3.6 3.5 0 1.6-.9 2.8-2.4 3.2l2.4 4.6h-2.5zm.7-1.9c1.1 0 1.8-.6 1.8-1.6s-.7-1.6-1.8-1.6h-1.8v3.1h1.8zM58 61.9V50.6h2.2v9.2h5v2.1zM73.8 61.9V50.6H76v11.3zM92.9 61.9l-5.1-8v8h-2.2V50.6h2.7l4.7 7.5v-7.5h2.2v11.3zM104.8 61.9V50.6h7.1v2.1H107v2.6h4.4v2H107v2.6h4.9V62h-7.1zM126.6 53.9c-.1-.6-.6-1.6-2.1-1.6-1.1 0-1.8.7-1.8 1.4 0 .6.4 1.1 1.2 1.3l1.6.3c2.1.4 3.2 1.7 3.2 3.3 0 1.7-1.5 3.5-4.1 3.5-3 0-4.3-1.9-4.5-3.5l2-.5c.1 1.1.9 2.1 2.5 2.1 1.2 0 1.8-.6 1.8-1.4 0-.7-.5-1.2-1.4-1.3l-1.6-.3c-1.8-.4-3-1.5-3-3.2 0-2 1.8-3.5 3.9-3.5 2.7 0 3.8 1.7 4.1 2.9z\"/></svg>"};

var official100 = {"hidden":"true","category":"restricted","role":"img","color":"currentColor","desc":"Logo image for Alaska Airlines","width":"100%","height":"auto","xmlns":"http://www.w3.org/2000/svg","xmlns_xlink":"http://www.w3.org/1999/xlink","path":"/icons/restricted","style":"","type":"restricted","name":"AS-tagline-100","title":"Alaska Airlines","viewBox":"0 0 57 24","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" aria-labelledby=\"AS-tagline-100__title AS-tagline-100__desc\" role=\"img\" style=\"min-width:100%;height:auto;fill:currentColor\" viewBox=\"0 0 57 24\" part=\"svg\"><title id=\"AS-tagline-100__title\">Alaska Airlines</title><desc id=\"AS-tagline-100__desc\">Logo image for Alaska Airlines</desc><path d=\"M6.8 22.2H5.1l-.4 1h-.9L5.5 19h1L8 23.2h-.8zm-1.4-.7h1.2L6 19.9zM11 23.2V19h.8v4.2zM16.7 21.6h-.4v1.6h-.8V19h1.7c.8 0 1.4.6 1.4 1.3q0 .9-.9 1.2l.9 1.7h-.9zm.2-.7c.4 0 .7-.2.7-.6s-.2-.6-.7-.6h-.7v1.2zM21.7 23.2V19h.8v3.5h1.9v.8h-2.7zM27.7 23.2V19h.8v4.2zM34.9 23.2l-1.9-3v3h-.8V19h1l1.8 2.8V19h.8v4.2zM39.3 23.2V19H42v.8h-1.8v1h1.7v.7h-1.7v1H42v.8h-2.7zM47.5 20.2c0-.2-.2-.6-.8-.6-.4 0-.7.3-.7.5s.1.4.5.5l.6.1c.8.2 1.2.7 1.2 1.2 0 .7-.5 1.3-1.5 1.3-1.1 0-1.6-.7-1.7-1.3l.8-.2c0 .4.3.8.9.8.4 0 .7-.2.7-.5 0-.2-.2-.4-.5-.5l-.6-.1c-.7-.1-1.1-.6-1.1-1.2 0-.8.7-1.3 1.5-1.3 1 0 1.4.6 1.5 1.1zM26.5.6 20.3 11c-.6 1.1-1 2.1-1.1 3.2h-2.4c.2-1.3.7-2.6 1.7-4.3l4.3-7.2c.9-1.4 1.7-2 3.3-2h.4zM26 11.5c-.5.4-1.3 1-2.1 1.1-.5 0-.5-.5-.2-1.2 1.3-2.5 2.7-3.8 4.4-3.8h.3zm2.3-5.3c-3.1 0-5 1.8-6.7 5.8-.4 1-.7 2.2.8 2.2.8 0 2.2-.5 3.2-1.1-.1.3-.1.8-.1 1.1h2.2c.1-.9.4-1.9 1.1-3.2l2.7-4.6c-1.1-.1-2.1-.2-3.2-.2M48.5 11.5c-.5.4-1.3 1-2.1 1.1-.5 0-.5-.5-.2-1.2 1.3-2.5 2.7-3.8 4.4-3.8h.4zm2.3-5.3c-3.1 0-5 1.8-6.7 5.8-.4 1-.7 2.2.8 2.2.8 0 2.2-.5 3.2-1.1-.1.3-.1.8-.1 1.1h2.2c.1-.9.4-1.9 1.1-3.2L54 6.4c-1-.1-2.1-.2-3.2-.2\"/><path d=\"M43.7 16.4H43c-.9 0-1.7-.6-2-1.5l-1.1-4.1-2 3.4h-2.3l6.5-11c.8-1.4 1.7-2 3.3-2h.2l-4.3 7.3 3.2-2.2h2.6L41.6 10zM22.2 0c-2.2 0-3.3.6-5.5 2.1L9.4 7.4H4.7c-1.4 0-2.4.1-3.3.9L.2 9.4s3.5-.1 6.8-.3l-7 5h3L10.2 9c1.4-.1 2.4-.1 2.4-.1 1.7 0 2.6-1.5 2.6-1.5h-2.7l5.8-4.2-4.3 7c-.9 1.6-1.4 2.7-1.5 4H15c.1-1 .4-2.1 1.1-3.2L22 1.2c.2-.7.5-1.2.5-1.2zM33.8 8.4c0 .2.1.3.5.6l.7.5c.7.5 1 1.2.9 1.8-.2 1.6-1.4 3-4 3-1.1 0-1.6 0-3-.3l1-1.7c.9.2 1.5.2 2.1.2 1 0 1.3-.4 1.4-.8 0-.2-.1-.5-.5-.8l-.5-.4c-.9-.6-1.1-1.1-1-1.8.2-1.4 1.9-2.6 4.2-2.6.7 0 1.5 0 2.4.1l-.9 1.6c-.6 0-1.5-.1-2.2-.1-.6.2-1 .4-1.1.7M55.2 10.9c.9 0 1.7.8 1.7 1.7s-.8 1.7-1.7 1.7-1.7-.8-1.7-1.7.8-1.7 1.7-1.7m0 3.1c.7 0 1.3-.6 1.3-1.4s-.6-1.4-1.3-1.4-1.3.6-1.3 1.4.6 1.4 1.3 1.4m-.2-.5h-.3v-1.8h.6c.4 0 .6.3.6.6s-.2.5-.4.5l.4.7h-.4l-.4-.7H55zm.2-1q.3 0 .3-.3t-.3-.3H55v.5h.2z\"/></svg>"};

var styleCss = i$5`.util_displayInline{display:inline}.util_displayInlineBlock{display:inline-block}.util_displayBlock,:host{display:block}.util_displayFlex{display:flex}.util_displayHidden,:host([hidden]:not(:focus):not(:active)){display:none}.util_displayHiddenVisually,:host([hiddenVisually]:not(:focus):not(:active)){position:absolute;overflow:hidden;clip:rect(1px, 1px, 1px, 1px);width:1px;height:1px;padding:0;border:0}:host{display:inline-block;--ds-auro-icon-size: 100%;width:100%;height:100%}:host([onDark]) .logo{color:var(--ds-color-base-white, #ffffff)}`;

// Copyright (c) 2020 Alaska Airlines. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.


// See https://git.io/JJ6SJ for "How to document your components using JSDoc"
/**
 * auro-alaska provides users a way to use the Alaska Airline logos.
 *
 * @attr {Boolean} official - Set value for alaska airlines logo with official tagline
 * @slot - Hidden from visibility, used for a11y if icon description is needed
 */

// build the component class
class AuroAlaska extends BaseIcon {
  constructor() {
    super();

    this.privateDefaults();
  }

  /**
   * Internal defaults.
   * @private
   * @returns {void}
   */
  privateDefaults() {
    this.uri = 'https://cdn.jsdelivr.net/npm/@alaskaairux/icons@latest/dist';
    this.sm = 107;
    this.md = 191;
    this.lg = 527;
    this.alaska = true;
    this.official = false;
    this.runtimeUtils = new AuroLibraryRuntimeUtils();
  }

  // function to define props used within the scope of this component
  static get properties() {
    return {
      ...super.properties,

      /**
       * @private
       */
      alaska: {
        type: Boolean,
        reflect: true
      },
      official: {
        type: Boolean,
        reflect: true
      },
    };
  }

  /**
   * This will register this element with the browser.
   * @param {string} [name="auro-alaska"] - The name of element that you want to register to.
   *
   * @example
   * AuroAlaska.register("custom-alaska") // this will register this element to <custom-alaska/>
   *
   */
  static register(name = "auro-alaska") {
    AuroLibraryRuntimeUtils.prototype.registerComponent(name, AuroAlaska);
  }

  /**
   * Async function to decide which logo to use.
   * @private
   * @param {number} iconWidth - Size of parent icon is in.
   * @returns {void}
   */
  alaskaLogoDef(iconWidth) {
    if (this.alaska) {
      if (iconWidth <= this.sm) {
        this.svg = new DOMParser().parseFromString(as100.svg, 'text/html').body.firstChild;
      } else if (iconWidth > this.sm && iconWidth <= this.md) {
        this.svg = new DOMParser().parseFromString(as200.svg, 'text/html').body.firstChild;
      } else if (iconWidth > this.md && iconWidth <= this.lg) {
        this.svg = new DOMParser().parseFromString(as300.svg, 'text/html').body.firstChild;
      } else {
        this.svg = new DOMParser().parseFromString(as400.svg, 'text/html').body.firstChild;
      }
    }
  }

  /**
   * Async function to decide which logo to use.
   * @private
   * @param {number} iconWidth - Size of parent icon is in.
   * @returns {void}
   */
  alaskaOfficialDef(iconWidth) {
    if (this.official) {
      if (iconWidth <= this.sm) {
        this.svg = new DOMParser().parseFromString(official100.svg, 'text/html').body.firstChild;
      } else if (iconWidth > this.sm && iconWidth <= this.md) {
        this.svg = new DOMParser().parseFromString(official200.svg, 'text/html').body.firstChild;
      } else if (iconWidth > this.md && iconWidth <= this.lg) {
        this.svg = new DOMParser().parseFromString(official300.svg, 'text/html').body.firstChild;
      } else {
        this.svg = new DOMParser().parseFromString(official400.svg, 'text/html').body.firstChild;
      }
    }
  }

  connectedCallback() {
    super.connectedCallback();

    // Add the tag name as an attribute if it is different than the component name
    this.runtimeUtils.handleComponentTagRename(this, 'auro-alaska');
  }

  // lifecycle function for the purpose of
  // displaying the correct Alaska logo
  // with the correct Restricted icon
  firstUpdated() {
    const iconContainer = this.shadowRoot.querySelector('.icon');
    const iconWidth = iconContainer.clientWidth;

    if (this.official) {
      this.alaska = false;
    }

    if (this.alaska) {
      this.alaskaLogoDef(iconWidth);
    } else if (this.official) {
      this.alaskaOfficialDef(iconWidth);
    }
  }

  static get styles() {
    return [
      super.styles,
      i$5`${styleCss}`
    ];
  }

  // function that renders the HTML and CSS into  the scope of the component
  render() {
    const classes = {
      'icon': true,
      'logo': this.alaska || this.official,
    };

    return x`
      <div class="${e(classes)}">
        <div class="util_displayHiddenVisually">
          <slot></slot>
        </div>
        ${this.svg}
      </div>
    `;
  }
}

AuroIcon.register();
AuroAlaska.register();

// Copyright (c) Alaska Air. All right reserved. Licensed under the Apache-2.0 license
// See LICENSE in the project root for license information.


/**
 * @param {{label: string; url: string}[]} themes - The list of supported themes in JSON format.
 * @return {CustomEvent<{themes: {label: string; url: string}[]}>}
 * @constructor
 */
const createThemeSelectionEvent = (themes) => new CustomEvent('theme-selected', {
  detail: {
    themes
  },
  // Allow the event to bubble up through the DOM
  bubbles: true,
  // Allow the event to cross shadow DOM boundaries
  composed: true
});

const ressetThemeSelectionEvent = () => new CustomEvent('theme-reset', {
  // Allow the event to bubble up through the DOM
  bubbles: true,
  // Allow the event to cross shadow DOM boundaries
  composed: true
});

/**
 * @attr {Array} themes - This accepts an array of JSON object outlining the themes to support.
 */

/* eslint-disable max-statements, one-var, no-magic-numbers, max-lines */
class AuroThemeswitcher extends s$6 {

  constructor() {
    super();
    this.themes = [
      {
        label: 'Auro Classic',
        url: 'https://jetstream-rouge.vercel.app/themes/jetstream.css'
      },
      {
        label: 'Hawaiian',
        url: 'https://jetstream-rouge.vercel.app/themes/californian.css'
      },
      {
        label: 'Readiness Test',
        url: 'https://jetstream-rouge.vercel.app/themes/transparent.css'
      }
    ];

    /**
     * @private
     */
    this.disableApply = true;

    /**
     * @private
     */
    this.currentThemes = [];

    /**
     * @private
     */
    this.newTheme = [];

    /**
     * @private
     */
    this.loadedThemes = [];

    this.resetCheckmarks = false;

    /**
     * Generate unique names for dependency components.
     */
    const versioning = new AuroDependencyVersioning();
    this.checkboxTag = versioning.generateTag('auro-checkbox', checkboxVersion, AuroCheckbox);
    this.buttonTag = versioning.generateTag('auro-button', buttonVersion, AuroButton);
    this.lockupTag = versioning.generateTag('auro-lockup', lockupVersion, AuroLockup);
  }

  static get styles() {
    return [styleCss$6];
  }

  static get properties() {
    return {
      themes:        {
        type: Array
      },
      currentThemes: {
        type: Array
      },
      newTheme: {
        type: Array
      },
      disableApply: {
        type: Boolean,
        reflect: true
      },
      resetCheckmarks: {
        type: Array
      }
    };
  }

  /**
   * @private
   * @returns {void} Determines which themes are loaded in the DOM.
   */
  getLoadedThemes() {
    this.loadedThemes = [];
    const stylesheets = document.styleSheets;

    this.themes.forEach((theme) => {
      for (let i = 0; i < stylesheets.length; i++) { // eslint-disable-line id-length, no-plusplus
        if (stylesheets[i].href === theme.url) {
          this.loadedThemes.push(theme);
        }
      }
    });
  }

  /**
   * @private
   * @returns {void} Forces a theme reset.
   */
  resetThemes() {
    this.unloadThemes(true);
    this.disableApply = true;
  }

  /**
   * @private
   * @param {boolean} reset - Determines if the themes should be reset.
   * @returns {void} Removes all loaded themes from the DOM.
   */
  unloadThemes(reset = false) {
    if (reset) {
      this.currentThemes = [];
      this.newTheme = [];
      const checkboxes = this.shadowRoot.querySelectorAll('[auro-checkbox]');

      checkboxes.forEach((checkbox) => {
        checkbox.removeAttribute('checked');
      });
    }

    this.dispatchEvent(ressetThemeSelectionEvent());
  }

  /**
   * @private
   * @returns {void} Loads all selected themes into the DOM.
   */
  loadSelectedthemes() {
    this.currentThemes = this.newTheme;
    this.dispatchEvent(createThemeSelectionEvent(this.currentThemes));
  }

  /**
   * @private
   * @param {Event} evt - Event fired by clicking on the checkbox.
   * @returns {void} Adds or removes the themes from the list to be applied.
   */
  handleCheckboxSelection(evt) {
    if (evt.target.checked) {
      const themeIndex = this.newTheme.indexOf(evt.target.value);

      if (themeIndex === -1) {
        this.newTheme.push(evt.target.value);
      }
    } else {
      const themeIndex = this.newTheme.indexOf(evt.target.value);

      if (themeIndex > -1) {
        this.newTheme.splice(themeIndex, 1);
      }
    }

    this.requestUpdate();
    this.disableApply = false;
  }

  /**
   * @private
   * @returns {void} Applies selected themes.
   */
  applyThemes() {
    this.unloadThemes();
    this.loadSelectedthemes();
    this.disableApply = true;
  }

  /**
   * @param {string[]} urls - The list of theme URLs to mark as selected.
   * @returns {void} Marks all loaded themes as selected in the checkbox group.
   */
  markLoadedthemes(urls) {
    const checkboxes = this.shadowRoot.querySelectorAll('[auro-checkbox]');

    checkboxes.forEach((checkbox) => {
      const optionUrl = JSON.parse(checkbox.getAttribute('value')).url;

      if (urls.includes(optionUrl)) {
        checkbox.setAttribute('checked', true);
      }
    });
  }

  /**
   * @private
   * @returns {void} Toggles display of the themeswitcher dialog.
   */
  toggleThemeSwitcher() {
    const dialog = this.shadowRoot.querySelector('').querySelector('#auroThemeSwitcherDialog');

    dialog.hasAttribute('open') // eslint-disable-line no-unused-expressions
      ? dialog.removeAttribute("open")
      : (dialog.removeAttribute("open"),
      dialog.setAttribute("open", true));
  }

  firstUpdated() {
    this.dropdown = this.shadowRoot.querySelector('#auroThemeSelector');
  }

  render() {
    return n$4`
      <div>
        <${this.lockupTag}>
          <span slot="title">Auro</span>
          <span slot="subtitle">design system</span>
        </${this.lockupTag}>
        <p>
          This utility is a theme switcher for the purpose of validating the look and feel of a page with the chosen theme applied.
        </p>
        <div class="selector">
          <auro-checkbox-group required>
            ${this.themes.map((theme) => n$4`
              <${this.checkboxTag}
                value="${JSON.stringify(theme)}"
                name="${theme.label}"
                id="${theme.label}"
                @auroCheckbox-input="${this.handleCheckboxSelection}">
                ${theme.label}
              </${this.checkboxTag}>
            `)}
          </auro-checkbox-group>
          <${this.buttonTag}
            variant="tertiary"
            @click="${this.resetThemes}"
            class="resetBtn">
            RESET
          </${this.buttonTag}>
          <${this.buttonTag}
            class="applyBtn"
            @click="${this.applyThemes}"
            ?disabled="${this.disableApply}">
            APPLY
          </${this.buttonTag}>
          <p class="finePrint">
            The Readiness Test theme is for use in testing which elements
            on the rendered page are not styled by the theme. Once applied,
            the theme will hide (make transparent) all rendered elements
            that will correctly respond to a published theme.
            Any elements that are still seen on the page
            are using color value that should be updated to the latest
            design token definintions or are Auro components that should
            be updatd to the latest version.
          </p>
        </div>
        ${this.disableApply ? undefined : n$4`
          <div class="applicator">
            ${this.newTheme.length === 0 ? n$4`
              <p>
                No themes are selected. Clicking the APPLY buttton will render the page with no theme styles.
              </p>
            ` : n$4`
              <p>
                Clicking the APPLY button will remove all current applied themes and apply the selected themes in the following order:
              </p>
              <ol>
                ${this.newTheme.map((theme) => n$4`<li>${JSON.parse(theme).label}</li>`)}
              </ol>
            `}
            <${this.buttonTag}
              @click="${this.applyThemes}"
              ?disabled="${this.disableApply}">
              APPLY
            </${this.buttonTag}>
          </div>
        `}
      </div>
    `;
  }
}

// default internal definition
if (!customElements.get("auro-themeswitcher")) {
  customElements.define("auro-themeswitcher", AuroThemeswitcher);
}

/**
 * Register Custom Element.
 * @param {Object} name - Name to use for custom element.
 * @returns {void}
 */
 const registerComponent = (name = 'custom-themeswitcher') => {
  // alias definition
  if (!customElements.get(name)) {
    customElements.define(name, class extends AuroThemeswitcher {});
  }
};

export { registerComponent };
